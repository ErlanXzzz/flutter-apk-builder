import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:app_links/app_links.dart';

import 'landing/landing_page.dart';
import 'landing/login_page.dart';
import 'dashboard/dashboard_page.dart';
import 'dashboard/home_page.dart';
import 'dashboard/seller_page.dart';
import 'dashboard/admin_page.dart';
import 'dashboard/owner_page.dart';
import 'dashboard/theme_provider.dart';
import 'dashboard/control_panel.dart';
import 'tools/jadwal_sholat_page.dart';
import 'tools/kamus_jepang_page.dart';
import 'sistem/maintance_page.dart';
import 'sistem/update_page.dart';
import 'sistem/apiBaseUrl.dart';

// Global Navigator Key untuk deep link
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final Widget initialScreen = await checkInitialScreen();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
      ],
      child: MyApp(initialScreen: initialScreen),
    ),
  );
}

// ================================================================
// CEK VERSI
// ================================================================
bool isUpdateRequired(String currentVersion, String serverVersion) {
  try {
    final currentParts = currentVersion
        .trim()
        .split('.')
        .map((e) => int.parse(e))
        .toList();

    final serverParts = serverVersion
        .trim()
        .split('.')
        .map((e) => int.parse(e))
        .toList();

    final maxLength = currentParts.length > serverParts.length
        ? currentParts.length
        : serverParts.length;

    for (int i = 0; i < maxLength; i++) {
      final current = i < currentParts.length ? currentParts[i] : 0;
      final server = i < serverParts.length ? serverParts[i] : 0;

      if (server > current) return true;
      if (server < current) return false;
    }
    return false;
  } catch (e) {
    debugPrint('❌ Error parsing version: $e');
    return false;
  }
}

// ================================================================
// CEK INITIAL SCREEN (Maintenance → Update → Auto-Login → Landing)
// ================================================================
Future<Widget> checkInitialScreen() async {
  // 1. CEK MAINTENANCE
  try {
    debugPrint('🔍 Mengecek maintenance...');
    final maintenanceUri =
        Uri.parse('$apiBaseUrl/maintance');
    final response =
        await http.get(maintenanceUri).timeout(const Duration(seconds: 7));

    if (response.statusCode != 200) return const MaintancePage();

    dynamic data;
    try {
      data = jsonDecode(response.body);
    } catch (e) {
      return const MaintancePage();
    }

    if (data is! Map<String, dynamic>) return const MaintancePage();

    final status = data['status'];
    if (status == true) return const MaintancePage();
    if (status != false) return const MaintancePage();
  } catch (e) {
    debugPrint('❌ Maintenance server offline/error: $e');
    return const MaintancePage();
  }

  // 2. CEK UPDATE
  try {
    debugPrint('🔍 Mengecek update aplikasi...');
    final packageInfo = await PackageInfo.fromPlatform();
    final String currentAppVersion = packageInfo.version;

    final updateUri = Uri.parse('$apiBaseUrl/update');
    final response =
        await http.get(updateUri).timeout(const Duration(seconds: 7));

    if (response.statusCode == 200) {
      dynamic data;
      try {
        data = jsonDecode(response.body);
      } catch (e) {
        data = null;
      }

      if (data is Map<String, dynamic>) {
        final String latestVersion = (data['version'] ?? '').toString().trim();
        if (latestVersion.isNotEmpty) {
          if (isUpdateRequired(currentAppVersion, latestVersion)) {
            return UpdatePage(
              currentVersion: currentAppVersion,
              latestVersion: latestVersion,
            );
          }
        }
      }
    }
  } catch (e) {
    debugPrint('⚠️ Error pengecekan update: $e');
  }

  // 3. CEK AUTO LOGIN
  try {
    debugPrint('🔍 Mengecek session login...');
    final prefs = await SharedPreferences.getInstance();

    final String? savedUser = prefs.getString('username');
    final String? savedPass = prefs.getString('password');
    final String? savedKey = prefs.getString('key');

    if (savedUser != null &&
        savedUser.isNotEmpty &&
        savedPass != null &&
        savedPass.isNotEmpty &&
        savedKey != null &&
        savedKey.isNotEmpty) {
      debugPrint('🔄 Mencoba auto-login...');

      String androidId = 'unknown_device';
      try {
        final deviceInfo = DeviceInfoPlugin();
        final android = await deviceInfo.androidInfo;
        androidId = android.id.isEmpty ? 'unknown_device' : android.id;
      } catch (e) {
        debugPrint('⚠️ Gagal mendapatkan Android ID: $e');
      }

      final uri = Uri.parse('$apiBaseUrl/myInfo').replace(
        queryParameters: {
          'username': savedUser,
          'password': savedPass,
          'androidId': androidId,
          'key': savedKey,
        },
      );

      final response =
          await http.get(uri).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        dynamic data;
        try {
          data = jsonDecode(response.body);
        } catch (e) {
          data = null;
        }

        if (data is Map<String, dynamic>) {
          if (data['valid'] == true) {
            debugPrint('🟢 Auto-login berhasil.');
            return DashboardPage(
              username: savedUser,
              password: savedPass,
              role: data['role'],
              sessionKey: data['key'] ?? savedKey,
              expiredDate: data['expiredDate'],
              listBug: (data['listBug'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              listDoos: (data['listDoos'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              news: (data['news'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              uid: data['uid'],
            );
          }

          await prefs.remove('username');
          await prefs.remove('password');
          await prefs.remove('key');
        }
      }
    }
  } catch (e) {
    debugPrint('❌ Error pengecekan auto-login: $e');
  }

  // 4. BELUM LOGIN
  return const AppEntryPage();
}

// ================================================================
// APP
// ================================================================
class MyApp extends StatefulWidget {
  final Widget initialScreen;

  const MyApp({
    super.key,
    required this.initialScreen,
  });

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late final AppLinks _appLinks;

  @override
  void initState() {
    super.initState();
    initDeepLinks();
  }

  Future<void> initDeepLinks() async {
    _appLinks = AppLinks();

    try {
      final initialUri = await _appLinks.getInitialAppLink();
      if (initialUri != null) {
        handleIncomingUri(initialUri);
      }
    } catch (e) {
      debugPrint('❌ Error getInitialAppLink: $e');
    }

    _appLinks.uriLinkStream.listen((uri) {
      handleIncomingUri(uri);
    }, onError: (err) {
      debugPrint('❌ Error uriLinkStream: $err');
    });
  }

  void handleIncomingUri(Uri uri) {
    debugPrint('🌐 Deep link diterima: $uri');
    if (uri.pathSegments.isNotEmpty) {
      final targetRoute = '/${uri.pathSegments.first}';
      navigatorKey.currentState?.pushNamed(targetRoute);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey, // ⬅️ pasang navigator key
      debugShowCheckedModeBanner: false,
      title: 'atlas',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: const Color(0xFFCED4DA),
        colorScheme: const ColorScheme.dark().copyWith(
          primary: const Color(0xFF4F46E5),
          secondary: const Color(0xFF6366F1),
          tertiary: const Color(0xFFA5B4FC),
          background: const Color(0xFF1E1B2E),
          surface: const Color(0xFF2A2744),
        ),
        primaryColor: const Color(0xFF4F46E5),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.black,
          foregroundColor: Colors.black87,
          iconTheme: const IconThemeData(color: Colors.black87),
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF4F46E5),
            foregroundColor: Colors.black87,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(foregroundColor: Colors.grey.shade800),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.grey.shade800,
            side: const BorderSide(color: Colors.grey),
          ),
        ),
        floatingActionButtonTheme:
            const FloatingActionButtonThemeData(backgroundColor: Colors.grey),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.black.withOpacity(0.3),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.grey),
            borderRadius: BorderRadius.circular(12),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey.withOpacity(0.6)),
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        snackBarTheme: SnackBarThemeData(
          backgroundColor: Colors.grey.shade800,
          contentTextStyle: const TextStyle(color: Colors.black87),
        ),
      ),

      home: widget.initialScreen, // ⬅️ initial screen dari checkInitialScreen

      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const AppEntryPage());

          case '/landing':
            return MaterialPageRoute(builder: (_) => const LandingPage());

          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          // ⬇️ TAMBAHAN — route maintenance & update (sama seperti main1)
          case '/maintance':
            return MaterialPageRoute(builder: (_) => const MaintancePage());

          case '/update':
            return MaterialPageRoute(builder: (_) => const UpdatePage());

          case '/dashboard':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                sessionKey: args['key'],
                expiredDate: args['expiredDate'],
                listBug:
                    List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listDoos:
                    List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
                uid: args['uid'],
              ),
            );

          case '/home':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => HomePage(
                username: args['username'],
                password: args['password'],
                listBug:
                    List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
            );

          case '/seller':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => SellerPage(keyToken: args['keyToken']),
            );

          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AdminPage(sessionKey: args['sessionKey']),
            );

          case '/owner':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => OwnerPage(
                sessionKey: args['sessionKey'],
                username: args['username'],
              ),
            );

          case '/control_panel':
            return MaterialPageRoute(
              builder: (_) => const ControlPanelPage(),
            );

          case '/jadwal_sholat':
            return MaterialPageRoute(
              builder: (_) => const JadwalSholatPage(),
            );

          case '/kamus_jepang':
            return MaterialPageRoute(
              builder: (_) => const KamusJepangPage(),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => Scaffold(
                body: Center(child: Text("404 - Not Found")),
              ),
            );
        }
      },
    );
  }
}