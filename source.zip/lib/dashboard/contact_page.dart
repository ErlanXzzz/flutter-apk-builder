import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/custom_popup.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  // --- TEMA WARNA MERAH KECOKLATAN ---
  static const Color bgDark = Color(0xFFFBF4EE); // cream hangat
  static const Color primaryRed = Color(0xFFB91C1C); // merah utama
  static const Color deepRed = Color(0xFF7F1D1D); // merah tua
  static const Color brownRed = Color(0xFF7C2D12); // merah kecoklatan
  static const Color accentRed = Color(0xFFDC2626); // merah terang

  Future<void> _launchUrl(BuildContext context, String url) async {
    try {
      final Uri uri = Uri.parse(url);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      if (context.mounted) {
        CustomPopup.display(
          context,
          title: "Gagal",
          message: "Tidak dapat membuka tautan ini.",
          icon: Icons.error_outline,
          iconColor: Colors.redAccent,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: brownRed.withOpacity(0.35),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
           child: IconButton(
             icon: const Icon(Icons.arrow_back_ios_new,
               color: primaryRed, size: 18),
             onPressed: () {
               if (Navigator.of(context).canPop()) {
                 Navigator.of(context).pop();
                   } else {
                SystemNavigator.pop();
                }
              },
            ),
          ),
        ),
        title: const Text(
          "Customer Service",
          style: TextStyle(
            color: Color(0xFF7C2D12), // coklat merah tua
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFFF7F2),
              Color(0xFFF5E1D3),
              Color(0xFFFBF4EE),
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // === HEADER ICON 3D MERAH KECOKLATAN ===
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFFDC2626),
                        Color(0xFF991B1B),
                        Color(0xFF7C2D12),
                      ],
                    ),
                    shape: BoxShape.circle,
                    boxShadow: [
                      // Shadow merah kecoklatan berlapis untuk efek 3D
                      BoxShadow(
                        color: brownRed.withOpacity(0.55),
                        blurRadius: 34,
                        spreadRadius: 4,
                        offset: const Offset(0, 14),
                      ),
                      BoxShadow(
                        color: const Color(0xFFDC2626).withOpacity(0.4),
                        blurRadius: 18,
                        spreadRadius: 1,
                        offset: const Offset(0, 6),
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.95),
                        blurRadius: 10,
                        offset: const Offset(-4, -4),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.support_agent_rounded,
                    size: 64,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 28),
                const Text(
                  "Need Help?",
                  style: TextStyle(
                    color: Color(0xFF7C2D12),
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                    shadows: [
                      Shadow(
                        color: Color(0x33B91C1C),
                        offset: Offset(0, 2),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "Contact us through our social media platforms below.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF8B5A3C),
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 40),

                // === GRID 2x2 ===
                // Baris 1: Developer + Owner
                Row(
                  children: [
                    Expanded(
                      child: _buildContactButton(
                        context: context,
                        label: "Developer",
                        icon: FontAwesomeIcons.telegram,
                        color: const Color(0xFFB91C1C), // merah bata
                        url: "https://t.me/bllackmatchaa",
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _buildContactButton(
                        context: context,
                        label: "Tele Ch",
                        icon: FontAwesomeIcons.telegram,
                        color: const Color(0xFF991B1B), // merah tua
                        url: "https://t.me/maklointel",
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Baris 2: WhatsApp + Channel
                Row(
                  children: [
                    Expanded(
                      child: _buildContactButton(
                        context: context,
                        label: "WhatsApp",
                        icon: FontAwesomeIcons.whatsapp,
                        color: const Color(0xFFDC2626), // merah terang
                        url: "https://wa.me/6289673345251",
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _buildContactButton(
                        context: context,
                        label: "Channel WA",
                        icon: FontAwesomeIcons.whatsapp,
                        color: const Color(0xFFDC2626), // merah kecoklatan
                        url: "https://whatsapp.com/channel/0029Vb8ZqffFCCoPFZTtzs1Q",
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // === TOMBOL 3D HD MERAH KECOKLATAN ===
  Widget _buildContactButton({
    required BuildContext context,
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _launchUrl(context, url),
        borderRadius: BorderRadius.circular(20),
        splashColor: color.withOpacity(0.18),
        highlightColor: color.withOpacity(0.10),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 10),
          decoration: BoxDecoration(
            // Gradient cream hangat supaya nyatu dengan tema merah kecoklatan
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFFFFFBF7),
                Color(0xFFF3E4D6),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white, width: 1.5),
            boxShadow: [
              // Drop shadow utama (merah kecoklatan, efek timbul 3D)
              BoxShadow(
                color: color.withOpacity(0.45),
                blurRadius: 20,
                spreadRadius: 1,
                offset: const Offset(0, 12),
              ),
              // Secondary shadow merah gelap
              BoxShadow(
                color: const Color(0xFF7C2D12).withOpacity(0.25),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
              // Highlight glossy atas (efek HD)
              BoxShadow(
                color: Colors.white.withOpacity(0.95),
                blurRadius: 6,
                offset: const Offset(-3, -3),
              ),
              // Shadow halus bawah
              BoxShadow(
                color: const Color(0xFF7C2D12).withOpacity(0.10),
                blurRadius: 8,
                offset: const Offset(2, 4),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Ikon dengan glow 3D merah kecoklatan
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      color.withOpacity(0.95),
                      Color.lerp(color, const Color(0xFF7C2D12), 0.5)!,
                      const Color(0xFF7C2D12),
                    ],
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.65),
                      blurRadius: 16,
                      spreadRadius: 1,
                      offset: const Offset(0, 7),
                    ),
                    BoxShadow(
                      color: const Color(0xFF7C2D12).withOpacity(0.35),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.75),
                      blurRadius: 6,
                      offset: const Offset(-3, -3),
                    ),
                  ],
                ),
                child: FaIcon(
                  icon,
                  color: Colors.white,
                  size: 28,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                label,
                style: const TextStyle(
                  color: Color(0xFF7C2D12),
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.3,
                  shadows: [
                    Shadow(
                      color: Color(0x22B91C1C),
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}