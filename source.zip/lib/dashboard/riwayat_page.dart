import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../widgets/custom_popup.dart';
import '../sistem/apiBaseUrl.dart';

class RiwayatPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage> {
  // ═══════════════════════════════════════════════════════════════════
  // 🎨 WARNA 3D MERAH KECOKLATAN (konsisten dengan Tools, Info, Profile)
  // ═══════════════════════════════════════════════════════════════════
  static const Color _bgCream      = Color(0xFFF5E6D3);
  static const Color _bgCreamLight = Color(0xFFFFF8F0);
  static const Color _redMain      = Color(0xFFB71C1C);
  static const Color _redDark      = Color(0xFF7F0000);
  static const Color _redDeep      = Color(0xFF4A0000);
  static const Color _brownDark    = Color(0xFF2B0E0E);
  static const Color _brownMid     = Color(0xFF5D2B1F);
  static const Color _gold         = Color(0xFFD4A853);
  static const Color _textDark     = Color(0xFF1A0A0A);
  static const Color _borderDark   = Color(0xFF1A0505);
  static const Color _white        = Colors.white;

  List<ActivityModel> activities = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadActivities();
  }

  Future<void> _loadActivities() async {
    const baseUrl = "$apiBaseUrl";

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/getMyActivity?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid']) {
          List<dynamic> rawList = data['activities'];

          setState(() {
            activities = rawList.map((item) {
              return ActivityModel(
                type: item['type'] ?? 'system',
                title: item['title'] ?? 'Aktivitas',
                description: item['description'] ?? '-',
                timestamp: DateTime.fromMillisecondsSinceEpoch(
                    item['timestamp'] ??
                        DateTime.now().millisecondsSinceEpoch),
              );
            }).toList();
            isLoading = false;
          });
        } else {
          setState(() => isLoading = false);
        }
      } else {
        print("Server Error: ${response.statusCode}");
        setState(() => isLoading = false);
        if (mounted) {
          CustomPopup.display(context,
              title: "Server Error",
              message: "Failed to fetch activities.",
              icon: Icons.error_outline,
              iconColor: Colors.redAccent);
        }
      }
    } catch (e) {
      print("Error fetching history: $e");
      setState(() => isLoading = false);
      if (mounted) {
        CustomPopup.display(context,
            title: "Connection Error",
            message: "Gagal terhubung ke server.",
            icon: Icons.error_outline,
            iconColor: Colors.redAccent);
      }
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _brownDark,
      appBar: AppBar(
        backgroundColor: _brownDark,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_redMain, _redDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _borderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: const Icon(
                Icons.arrow_back_ios_new,
                color: _white,
                size: 16,
              ),
            ),
          ),
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_redMain, _redDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _borderDark, width: 2.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(3, 3),
              ),
              BoxShadow(
                color: Color(0x66000000),
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.history_rounded, color: _white, size: 16),
              SizedBox(width: 8),
              Text(
                "RIWAYAT AKTIVITAS",
                style: TextStyle(
                  color: _white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(
                      color: Color(0xCC000000),
                      blurRadius: 3,
                      offset: Offset(1, 1),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(color: _brownDark),
        child: isLoading
            ? const Center(
                child: CircularProgressIndicator(color: _redMain),
              )
            : activities.isEmpty
                ? _buildEmptyState()
                : RefreshIndicator(
                    onRefresh: _loadActivities,
                    color: _redMain,
                    backgroundColor: _bgCream,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: activities.length + 1,
                      itemBuilder: (context, index) {
                        // Header di paling atas
                        if (index == 0) {
                          return _buildHeader();
                        }
                        final activity = activities[index - 1];
                        return _buildActivityCard(activity);
                      },
                    ),
                  ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HEADER 3D — total aktivitas
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_bgCreamLight, _bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 14,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_redMain, _redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _borderDark, width: 2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: const Icon(Icons.timeline_rounded, color: _white, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "TOTAL AKTIVITAS",
                  style: TextStyle(
                    color: _redDark,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "${activities.length} Record",
                  style: const TextStyle(
                    color: _textDark,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                    shadows: [
                      Shadow(
                        color: Color(0x33000000),
                        blurRadius: 2,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _redMain,
              shape: BoxShape.circle,
              border: Border.all(color: _borderDark, width: 2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: const Icon(Icons.refresh_rounded, color: _white, size: 16),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // EMPTY STATE 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildEmptyState() {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(32),
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_bgCreamLight, _bgCream],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _borderDark, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(5, 5),
            ),
            BoxShadow(
              color: Color(0x88000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_redMain, _redDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                border: Border.all(color: _borderDark, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: Color(0x66000000),
                    blurRadius: 12,
                    offset: Offset(0, 6),
                  ),
                ],
              ),
              child: const Icon(
                Icons.history_toggle_off,
                size: 44,
                color: _white,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Belum ada aktivitas",
              style: TextStyle(
                color: _redDark,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Pastikan server aktif & sudah login",
              style: TextStyle(
                color: _brownMid.withOpacity(0.9),
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ACTIVITY CARD 3D — Extra HD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildActivityCard(ActivityModel activity) {
    Color iconColor;
    IconData iconData;
    String typeLabel;
    Color badgeColor;

    switch (activity.type) {
      case 'login':
        iconColor = const Color(0xFF2E7D32); // hijau tua
        badgeColor = const Color(0xFF4CAF50);
        iconData = Icons.login_rounded;
        typeLabel = "LOGIN";
        break;
      case 'bug':
        iconColor = const Color(0xFFE65100); // orange tua
        badgeColor = const Color(0xFFEF6C00);
        iconData = Icons.bug_report_outlined;
        typeLabel = "ATTACK";
        break;
      case 'create':
        iconColor = const Color(0xFF006064); // cyan tua
        badgeColor = const Color(0xFF00ACC1);
        iconData = Icons.person_add_alt_1_rounded;
        typeLabel = "ACCOUNT";
        break;
      default:
        iconColor = _redDark;
        badgeColor = _redMain;
        iconData = Icons.info_outline;
        typeLabel = "SYSTEM";
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_bgCreamLight, _bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderDark, width: 3),
        boxShadow: const [
          // Solid 3D shadow
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          // Blur depth
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 14,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ═══ ICON 3D ═══
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  iconColor,
                  Color.lerp(iconColor, Colors.black, 0.4)!,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(color: _borderDark, width: 2.5),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
                BoxShadow(
                  color: Color(0x66000000),
                  blurRadius: 10,
                  offset: Offset(0, 5),
                ),
              ],
            ),
            child: Icon(iconData, color: _white, size: 22),
          ),
          const SizedBox(width: 16),

          // ═══ CONTENT ═══
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Title + Badge
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        activity.title,
                        style: const TextStyle(
                          color: _redDark,
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                          shadows: [
                            Shadow(
                              color: Color(0x33000000),
                              blurRadius: 2,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Badge tipe
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            badgeColor,
                            Color.lerp(badgeColor, Colors.black, 0.4)!,
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _borderDark, width: 1.8),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0xAA000000),
                            blurRadius: 0,
                            offset: Offset(2, 2),
                          ),
                        ],
                      ),
                      child: Text(
                        typeLabel,
                        style: const TextStyle(
                          color: _white,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                          fontFamily: 'Orbitron',
                          shadows: [
                            Shadow(
                              color: Color(0x99000000),
                              blurRadius: 3,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 10),

                // Description box
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: _bgCream,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _brownMid.withOpacity(0.3),
                      width: 1.5,
                    ),
                  ),
                  child: Text(
                    activity.description,
                    style: const TextStyle(
                      color: _textDark,
                      fontSize: 12.5,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                      height: 1.4,
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                // Timestamp
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: _redMain.withOpacity(0.1),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _redMain.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: const Icon(
                        Icons.access_time_rounded,
                        size: 10,
                        color: _redDark,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _formatDate(activity.timestamp),
                      style: const TextStyle(
                        color: _redDark,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ActivityModel {
  final String type;
  final String title;
  final String description;
  final DateTime timestamp;

  ActivityModel({
    required this.type,
    required this.title,
    required this.description,
    required this.timestamp,
  });
}