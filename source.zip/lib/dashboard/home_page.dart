// lib/home_page.dart
import 'dart0:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import '../widgets/custom_popup.dart';
import '../sistem/apiBaseUrl.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  late PageController _bugPageController;
  int _selectedBugIndex = 0;
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;

  // ═══════════════════════════════════════════════════════════════════
  // 🚩 VARIABEL BENDERA NEGARA
  // ═══════════════════════════════════════════════════════════════════
  String? _detectedFlag;

  // Mapping Kode Telepon -> Kode Negara (ISO)
  final Map<String, String> _countryDialCodes = {
    '62': 'ID', // Indonesia
    '1': 'US',  // USA / Canada
    '44': 'GB', // UK
    '60': 'MY', // Malaysia
    '65': 'SG', // Singapore
    '63': 'PH', // Philippines
    '66': 'TH', // Thailand
    '81': 'JP', // Japan
    '82': 'KR', // South Korea
    '86': 'CN', // China
    '91': 'IN', // India
    '92': 'PK', // Pakistan
    '93': 'AF', // Afghanistan
    '94': 'LK', // Sri Lanka
    '95': 'MM', // Myanmar
    '98': 'IR', // Iran
    '7': 'RU',  // Russia
    '33': 'FR', // France
    '49': 'DE', // Germany
    '39': 'IT', // Italy
    '34': 'ES', // Spain
    '31': 'NL', // Netherlands
    '55': 'BR', // Brazil
    '52': 'MX', // Mexico
    '54': 'AR', // Argentina
    '61': 'AU', // Australia
    '64': 'NZ', // New Zealand
    '20': 'EG', // Egypt
    '27': 'ZA', // South Africa
    '234': 'NG',// Nigeria
    '966': 'SA',// Saudi Arabia
    '971': 'AE',// UAE
    '90': 'TR', // Turkey
  };

  // Konversi ISO Country Code ke Emoji Bendera
  String _getFlagEmoji(String countryCode) {
    return countryCode.toUpperCase().replaceAllMapped(
          RegExp(r'[A-Z]'),
          (match) => String.fromCharCode(match.group(0)!.codeUnitAt(0) + 127397),
        );
  }

  void _onTargetNumberChanged() {
    String text = targetController.text.trim().replaceAll('+', '');
    if (text.isEmpty) {
      if (_detectedFlag != null) {
        setState(() => _detectedFlag = null);
      }
      return;
    }

    String? foundFlag;
    // Cek dial code dari yang terpanjang (3 digit) ke yang terpendek (1 digit)
    for (int len = 3; len >= 1; len--) {
      if (text.length >= len) {
        String prefix = text.substring(0, len);
        if (_countryDialCodes.containsKey(prefix)) {
          foundFlag = _getFlagEmoji(_countryDialCodes[prefix]!);
          break;
        }
      }
    }

    if (_detectedFlag != foundFlag) {
      setState(() {
        _detectedFlag = foundFlag;
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 WARNA 3D MERAH KECOKLATAN
  // ═══════════════════════════════════════════════════════════════════
  static const Color _bgCream      = Color(0xFFF5E6D3);
  static const Color _bgCreamLight = Color(0xFFFFF8F0);
  static const Color _bgCreamDeep  = Color(0xFFE8D0B0);
  static const Color _redMain      = Color(0xFFB71C1C);
  static const Color _redDark      = Color(0xFF7F0000);
  static const Color _redDeep      = Color(0xFF4A0000);
  static const Color _redHighlight = Color(0xFFE53935);
  static const Color _brownDark    = Color(0xFF2B0E0E);
  static const Color _brownMid     = Color(0xFF5D2B1F);
  static const Color _gold         = Color(0xFFD4A853);
  static const Color _goldLight    = Color(0xFFFFE4A0);
  static const Color _goldDark     = Color(0xFF8B6F1F);
  static const Color _yellowAccent = Color(0xFFFFD54F);
  static const Color _greenBadge   = Color(0xFF4CAF50);
  static const Color _textDark     = Color(0xFF1A0A0A);
  static const Color _borderDark   = Color(0xFF1A0505);
  static const Color _white        = Colors.white;
  static const Color _cardWhite    = Color(0xFFFFFDF8);

  bool get _canUseGlobalSender =>
      widget.role == 'partner' ||
      widget.role == 'pemula';

  // ✅ Fokus BUG NOMOR — filter bug non-group saja
  List<Map<String, dynamic>> _getFilteredBugs() {
    return widget.listBug
        .where((b) => !b['bug_id'].toString().contains('_group'))
        .toList();
  }

  @override
  void initState() {
    super.initState();
    targetController.addListener(_onTargetNumberChanged);
    _bugPageController = PageController(viewportFraction: 0.72);
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _initVideo();

    if (widget.listBug.isNotEmpty) {
      final bugs = _getFilteredBugs();
      if (bugs.isNotEmpty) _selectedBugIndex = 0;
    }
    _fetchSenderStats();
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎬 VIDEO INIT — AUTOPLAY SOUND (TANPA TOMBOL MUTE)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _initVideo() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/bug.mp4');

      await _videoController!.initialize();

      await _videoController!.setLooping(true);
      await _videoController!.setPlaybackSpeed(1.0);
      await _videoController!.setVolume(1.0);

      await _videoController!.play();

      // Force re-set volume setelah play
      await Future.delayed(const Duration(milliseconds: 200));
      if (mounted && _videoController != null) {
        await _videoController!.setVolume(1.0);
      }

      if (!mounted) return;
      setState(() => _videoReady = true);

      debugPrint("✅ Video autoplay sound ON: ${_videoController!.value.duration}");
    } catch (e) {
      debugPrint("❌ Video error: $e");
      if (mounted) setState(() => _videoReady = false);
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "$apiBaseUrl/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error: $e");
    }
  }

  @override
  void dispose() {
    targetController.removeListener(_onTargetNumberChanged);
    _videoController?.dispose();
    _pulseController.dispose();
    _bugPageController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    // ✅ Hanya validasi nomor (group dihapus)
    final target = formatPhoneNumber(rawInput);
    if (target == null || key.isEmpty) {
      _showAlert("Invalid Number",
          "Gunakan nomor internasional (misal: +62, 1, 44).");
      return;
    }

    final bugs = _getFilteredBugs();
    if (bugs.isEmpty) {
      _showAlert("Error", "Tidak ada bug tersedia.");
      return;
    }
    final selectedBugId =
        bugs[_selectedBugIndex.clamp(0, bugs.length - 1)]['bug_id'];

    setState(() => _isSending = true);
    final effectiveSenderMode = _canUseGlobalSender ? _senderMode : 'private';

    try {
      final url = "$apiBaseUrl/sendBug"
          "?key=$key"
          "&target=$rawInput"
          "&bug=$selectedBugId"
          "&senderMode=$effectiveSenderMode";
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert(
            "❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi nanti.");
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, [String? msg]) {
    if (!mounted) return;
    CustomPopup.display(
      context,
      title: title,
      message: msg ?? title,
      icon: title.contains("✅")
          ? Icons.check_circle_outline
          : Icons.error_outline,
      iconColor: title.contains("✅") ? Colors.green : Colors.redAccent,
      confirmText: "Close",
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final bugs = _getFilteredBugs();

    return Scaffold(
      backgroundColor: _brownDark,
      body: Column(
        children: [
          // ═══ HEADER MERAH 3D ═══
          _build3DHeader(),

          Expanded(
            child: Container(
              color: _bgCream,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ═══ VIDEO PLAYER 3D ═══
                    _build3DVideoPlayer(),

                    // ❌ Badge "BUG NOMOR" DIHAPUS
                    // (langsung lanjut ke panel di bawah)

                    const SizedBox(height: 6),

                    // ═══ PANEL MERAH 3D ═══
                    Container(
                      margin: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [_redHighlight, _redMain, _redDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: _borderDark, width: 3),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(5, 5),
                          ),
                          BoxShadow(
                            color: Color(0x88000000),
                            blurRadius: 16,
                            offset: Offset(0, 8),
                          ),
                          BoxShadow(
                            color: Color(0x33FFFFFF),
                            blurRadius: 4,
                            offset: Offset(-2, -2),
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildSectionTitle(
                                Icons.phone_android_rounded, "NOMOR TARGET"),
                            const SizedBox(height: 10),
                            _build3DTextField(),
                            const SizedBox(height: 18),

                            _buildSectionTitle(
                                Icons.bug_report_rounded, "PILIH BUG"),
                            const SizedBox(height: 10),

                            _buildStatusBadges(),
                            const SizedBox(height: 14),

                            if (bugs.isNotEmpty) ...[
                              SizedBox(
                                height: 160,
                                child: PageView.builder(
                                  controller: _bugPageController,
                                  onPageChanged: (i) => setState(
                                      () => _selectedBugIndex = i),
                                  itemCount: bugs.length,
                                  itemBuilder: (_, i) {
                                    final bug = bugs[i];
                                    final isSelected =
                                        i == _selectedBugIndex;
                                    return AnimatedScale(
                                      scale: isSelected ? 1.0 : 0.9,
                                      duration: const Duration(
                                          milliseconds: 250),
                                      child: GestureDetector(
                                        onTap: () {
                                          _bugPageController.animateToPage(
                                            i,
                                            duration: const Duration(
                                                milliseconds: 300),
                                            curve: Curves.easeOut,
                                          );
                                          setState(() =>
                                              _selectedBugIndex = i);
                                        },
                                        child: _build3DBugCard(
                                            bug, isSelected),
                                      ),
                                    );
                                  },
                                ),
                              ),
                              const SizedBox(height: 10),

                              // Dots indicator
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ...List.generate(
                                    bugs.length.clamp(0, 8),
                                    (i) => AnimatedContainer(
                                      duration: const Duration(
                                          milliseconds: 250),
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 3),
                                      width:
                                          i == _selectedBugIndex ? 18 : 6,
                                      height: 6,
                                      decoration: BoxDecoration(
                                        color: i == _selectedBugIndex
                                            ? _gold
                                            : _white.withOpacity(0.4),
                                        borderRadius:
                                            BorderRadius.circular(3),
                                        border: Border.all(
                                            color: _borderDark, width: 1),
                                        boxShadow:
                                            i == _selectedBugIndex
                                                ? [
                                                    BoxShadow(
                                                      color: _gold
                                                          .withOpacity(0.8),
                                                      blurRadius: 8,
                                                      spreadRadius: 1,
                                                    ),
                                                  ]
                                                : null,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ] else
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Text(
                                    "Tidak ada bug tersedia.",
                                    style: TextStyle(
                                        color: _white.withOpacity(0.8)),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // ═══ SENDER MODE PANEL ═══
                    if (_canUseGlobalSender)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: _buildSenderModePanel(),
                      ),

                    const SizedBox(height: 20),

                    // ═══ TOMBOL KIRIM 3D ═══
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: AnimatedBuilder(
                        animation: _pulseController,
                        builder: (_, __) => GestureDetector(
                          onTap: _isSending ? null : _sendBug,
                          child: Container(
                            height: 60,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  _redDeep,
                                  _redMain,
                                  Color.lerp(
                                    _redMain,
                                    _redHighlight,
                                    _pulseController.value * 0.5,
                                  )!,
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(14),
                              border:
                                  Border.all(color: _borderDark, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: _redDeep.withOpacity(
                                      0.5 + 0.3 * _pulseController.value),
                                  blurRadius: 20,
                                  offset: const Offset(0, 6),
                                ),
                                const BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(4, 4),
                                ),
                                const BoxShadow(
                                  color: Color(0x33FFFFFF),
                                  blurRadius: 4,
                                  offset: Offset(-2, -2),
                                ),
                              ],
                            ),
                            child: _isSending
                                ? const Center(
                                    child: SizedBox(
                                      width: 26,
                                      height: 26,
                                      child: CircularProgressIndicator(
                                        color: _white,
                                        strokeWidth: 2.5,
                                      ),
                                    ),
                                  )
                                : const Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.send_rounded,
                                          color: _white, size: 22),
                                      SizedBox(width: 12),
                                      Text(
                                        "KIRIM BUG",
                                        style: TextStyle(
                                          color: _white,
                                          fontFamily: 'Orbitron',
                                          fontWeight: FontWeight.w900,
                                          fontSize: 16,
                                          letterSpacing: 3,
                                          shadows: [
                                            Shadow(
                                              color: Color(0xCC000000),
                                              blurRadius: 4,
                                              offset: Offset(1, 1),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 32),

                    // ═══ FOOTER ═══
                    Center(
                      child: Column(
                        children: [
                          ShaderMask(
                            shaderCallback: (bounds) =>
                                const LinearGradient(
                              colors: [_gold, _goldLight, _goldDark],
                            ).createShader(bounds),
                            child: const Text(
                              "ATLAS TEAM",
                              style: TextStyle(
                                color: _white,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                letterSpacing: 3,
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "We are team solid solid parah",
                            style: TextStyle(
                              color: _redDark.withOpacity(0.6),
                              fontSize: 10,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ❌ Method _buildBugNumberBadge() DIHAPUS (tidak dipakai lagi)

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 3D HEADER
  // ═══════════════════════════════════════════════════════════════════
  Widget _build3DHeader() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [_redDark, _redMain, _redHighlight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(0, 6),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_goldLight, _gold, _goldDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: _borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 8,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.shield_rounded,
                  color: _redDark,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 18, vertical: 8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_redDeep, _redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x33FFFFFF),
                      blurRadius: 4,
                      offset: Offset(-1, -1),
                    ),
                  ],
                ),
                child: ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [_goldLight, _white, _gold],
                  ).createShader(bounds),
                  child: const Text(
                    "ATLAS BUG",
                    style: TextStyle(
                      color: _white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _fetchSenderStats,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_redHighlight, _redMain],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: _borderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(3, 3),
                      ),
                      BoxShadow(
                        color: Color(0x33FFFFFF),
                        blurRadius: 4,
                        offset: Offset(-1, -1),
                      ),
                    ],
                  ),
                  child: const Icon(Icons.refresh_rounded,
                      color: _white, size: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎬 3D VIDEO PLAYER — AUTOPLAY SOUND
  // ═══════════════════════════════════════════════════════════════════
  Widget _build3DVideoPlayer() {
    return Container(
      color: _bgCream,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _borderDark, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(5, 5),
            ),
            BoxShadow(
              color: Color(0x88000000),
              blurRadius: 16,
              offset: Offset(0, 8),
            ),
            BoxShadow(
              color: Color(0x33FFFFFF),
              blurRadius: 4,
              offset: Offset(-2, -2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(17),
          child: AspectRatio(
            aspectRatio: 16 / 9,
            child: _videoReady && _videoController != null
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController!.value.size.width,
                      height: _videoController!.value.size.height,
                      child: VideoPlayer(_videoController!),
                    ),
                  )
                : Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_redDark, _redMain],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.play_arrow_rounded,
                              color: _white, size: 50),
                          SizedBox(height: 8),
                          Text(
                            "ATLAS BUG",
                            style: TextStyle(
                              color: _white,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 📤 SENDER MODE PANEL — PRIBADI (KIRI) & GLOBAL (KANAN)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildSenderModePanel() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_bgCreamLight, _bgCream, _bgCreamDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(5, 5),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
          BoxShadow(
            color: Color(0x55FFFFFF),
            blurRadius: 4,
            offset: Offset(-2, -2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header ──
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_goldLight, _gold, _goldDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: _borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: const Icon(Icons.swap_horiz_rounded,
                    color: _redDark, size: 14),
              ),
              const SizedBox(width: 10),
              const Text(
                "PILIH SENDER",
                style: TextStyle(
                  color: _redDark,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  fontSize: 13,
                  letterSpacing: 1.5,
                ),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _greenBadge.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: _greenBadge.withOpacity(0.5), width: 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _greenBadge,
                        boxShadow: [
                          BoxShadow(
                            color: _greenBadge,
                            blurRadius: 6,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      "${_globalSenderCount + _privateSenderCount} sender online",
                      style: const TextStyle(
                        color: _greenBadge,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // ── Dua card side-by-side ──
          Row(
            children: [
              // ─── PRIBADI (KIRI) ───
              Expanded(
                child: _buildSenderCard(
                  icon: Icons.person_rounded,
                  label: "Pribadi",
                  subtitle: _privateSenderCount > 0
                      ? "$_privateSenderCount sender"
                      : "X Kosong",
                  isActive: _senderMode == 'private',
                  isDisabled: _privateSenderCount == 0,
                  subtitleColor: _privateSenderCount > 0
                      ? _greenBadge
                      : _redMain,
                  onTap: () {
                    if (_privateSenderCount == 0) {
                      _showAlert(
                        "⚠️ Sender Kosong",
                        "Belum ada sender pribadi online. "
                            "Tetap dipilih, tapi pengiriman mungkin gagal.",
                      );
                    }
                    setState(() => _senderMode = 'private');
                  },
                ),
              ),
              const SizedBox(width: 12),
              // ─── GLOBAL (KANAN) ───
              Expanded(
                child: _buildSenderCard(
                  icon: Icons.public_rounded,
                  label: "Global",
                  subtitle: "$_globalSenderCount sender",
                  isActive: _senderMode == 'global',
                  isDisabled: _globalSenderCount == 0,
                  subtitleColor: _brownMid,
                  onTap: () {
                    if (_globalSenderCount == 0) {
                      _showAlert(
                        "⚠️ Sender Kosong",
                        "Belum ada sender global online. "
                            "Tetap dipilih, tapi pengiriman mungkin gagal.",
                      );
                    }
                    setState(() => _senderMode = 'global');
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSenderCard({
    required IconData icon,
    required String label,
    required String subtitle,
    required bool isActive,
    required bool isDisabled,
    required Color subtitleColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isActive
                ? [_bgCreamLight, _bgCream, _bgCreamDeep]
                : [_bgCream, _bgCreamDeep, _bgCream],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isActive ? _redDark : _borderDark,
            width: isActive ? 3 : 2,
          ),
          boxShadow: isActive
              ? const [
                  BoxShadow(
                    color: Color(0xDD000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: Color(0x88000000),
                    blurRadius: 12,
                    offset: Offset(0, 6),
                  ),
                  BoxShadow(
                    color: Color(0x55FFFFFF),
                    blurRadius: 4,
                    offset: Offset(-2, -2),
                  ),
                ]
              : const [
                  BoxShadow(
                    color: Color(0x88000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: Color(0x44000000),
                    blurRadius: 8,
                    offset: Offset(0, 4),
                  ),
                ],
        ),
        child: Opacity(
          opacity: isDisabled ? 0.6 : 1.0,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isActive
                        ? [_redHighlight, _redMain, _redDark]
                        : [_redDark, _redDeep],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: _borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x33FFFFFF),
                      blurRadius: 4,
                      offset: Offset(-1, -1),
                    ),
                  ],
                ),
                child: Icon(icon, color: _white, size: 20),
              ),
              const SizedBox(height: 10),
              Text(
                label,
                style: TextStyle(
                  color: isActive ? _redDark : _brownMid,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3D COMPONENTS
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildSectionTitle(IconData icon, String text) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_goldLight, _gold, _goldDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            border: Border.all(color: _borderDark, width: 2),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: Icon(icon, color: _redDark, size: 14),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: const TextStyle(
            color: _white,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900,
            fontSize: 14,
            letterSpacing: 2,
            shadows: [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 4,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _build3DTextField() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_bgCreamLight, _bgCream, _bgCreamDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
          BoxShadow(
            color: Color(0x33FFFFFF),
            blurRadius: 2,
            offset: Offset(-1, -1),
          ),
        ],
      ),
      child: TextField(
        controller: targetController,
        style: const TextStyle(
          color: _textDark,
          fontSize: 14,
          fontWeight: FontWeight.w700,
          fontFamily: 'ShareTechMono',
        ),
        keyboardType: TextInputType.phone,
        decoration: InputDecoration(
          hintText: "62xxxxxxxxxx",
          hintStyle: TextStyle(
              color: _brownMid.withOpacity(0.5), fontSize: 13),
          prefixIcon: Padding(
            padding: const EdgeInsets.only(left: 10, right: 6),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_detectedFlag != null)
                  Text(
                    _detectedFlag!,
                    style: const TextStyle(fontSize: 20),
                  )
                else
                  const Icon(
                    Icons.language,
                    color: _redDark,
                    size: 18,
                  ),
              ],
            ),
          ),
          prefixIconConstraints: const BoxConstraints(
            minWidth: 40,
            minHeight: 0,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 12, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildStatusBadges() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_bgCreamLight, _bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _borderDark, width: 1.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 6,
                height: 6,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _greenBadge,
                    boxShadow: [
                      BoxShadow(
                        color: _greenBadge,
                        blurRadius: 6,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(width: 5),
              Text(
                "Engine lokal aktif",
                style: TextStyle(
                  color: _redDark,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _white.withOpacity(0.4), width: 1),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.chat,
                  color: _white.withOpacity(0.9), size: 10),
              const SizedBox(width: 4),
              Text(
                "WA belum connect",
                style: TextStyle(
                  color: _white.withOpacity(0.9),
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _build3DBugCard(Map<String, dynamic> bug, bool isSelected) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isSelected
              ? [_goldLight, _yellowAccent, _gold]
              : [_bgCreamLight, _bgCream, _bgCreamDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isSelected ? _redDark : _borderDark,
          width: 3,
        ),
        boxShadow: isSelected
            ? [
                const BoxShadow(
                  color: Color(0xDD000000),
                  blurRadius: 0,
                  offset: Offset(4, 4),
                ),
                BoxShadow(
                  color: _gold.withOpacity(0.6),
                  blurRadius: 16,
                  spreadRadius: 1,
                ),
                const BoxShadow(
                  color: Color(0x33FFFFFF),
                  blurRadius: 4,
                  offset: Offset(-2, -2),
                ),
              ]
            : const [
                BoxShadow(
                  color: Color(0x88000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
                BoxShadow(
                  color: Color(0x44000000),
                  blurRadius: 8,
                  offset: Offset(0, 4),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_redHighlight, _redMain, _redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: _borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.shield_rounded,
                  color: _white,
                  size: 14,
                ),
              ),
              if (isSelected)
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: _greenBadge,
                    shape: BoxShape.circle,
                    border: Border.all(color: _borderDark, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: _greenBadge.withOpacity(0.7),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.check_rounded,
                      color: _white, size: 14),
                ),
            ],
          ),
          const Spacer(),
          Text(
            bug['bug_name'] ?? 'Bug',
            style: const TextStyle(
              color: _redDark,
              fontWeight: FontWeight.w900,
              fontSize: 13,
              fontFamily: 'Orbitron',
              letterSpacing: 0.3,
              shadows: [
                Shadow(
                  color: Color(0x33FFFFFF),
                  blurRadius: 1,
                  offset: Offset(1, 1),
                ),
              ],
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: _redDeep.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: _redDark.withOpacity(0.5),
                width: 1,
              ),
            ),
            child: Text(
              bug['bug_id'] ?? '',
              style: const TextStyle(
                color: _redDark,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
