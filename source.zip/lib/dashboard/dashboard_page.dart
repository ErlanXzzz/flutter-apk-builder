// lib/dashboard_page.dart
import 'dart:convert';
import 'dart:async';
import 'dart:math' as math;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:glaze_nav_bar/glaze_nav_bar.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:http/http.dart' as http;

import '../tools/nik_check.dart';
import 'admin_page.dart';
import 'public_chat_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import '../tools/tools_gateway.dart';
import '../landing/login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'control_panel.dart';
import 'music.dart';
import '../sistem/upgrade_role.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final String? uid;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    this.uid,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  late String? uid;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();
  final GlobalKey<GlazeNavBarState> _navBarKey = GlobalKey();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  int onlineUsers = 0;
  int activeConnections = 0;

  int _quickActionsPage = 0;
  late PageController _quickActionsController;

  // ─── BATTERY & CONNECTIVITY ───
  final Battery _battery = Battery();
  int _batteryLevel = 0;
  BatteryState _batteryState = BatteryState.unknown;
  String _connectionType = 'OFFLINE';
  StreamSubscription<BatteryState>? _batterySub;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;
  Timer? _batteryTimer;
  Timer? _clockTimer;
  DateTime _now = DateTime.now();

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 WARNA 3D MERAH KECOKLATAN
  // ═══════════════════════════════════════════════════════════════════
  static const Color bgCream      = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain      = Color(0xFFB71C1C);
  static const Color redDark      = Color(0xFF7F0000);
  static const Color redDeep      = Color(0xFF4A0000);
  static const Color brownDark    = Color(0xFF2B0E0E);
  static const Color brownMid     = Color(0xFF5D2B1F);
  static const Color gold         = Color(0xFFD4A853);
  static const Color textDark     = Color(0xFF1A0A0A);
  static const Color borderDark   = Color(0xFF1A0505);
  static const Color white        = Colors.white;
  static const Color accentGreen  = Color(0xFF4CAF50);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    uid = widget.uid;

    _quickActionsController = PageController(viewportFraction: 0.88);

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();
    _initAndroidIdAndConnect();
    _loadProfileImage();

    _initBattery();
    _initConnectivity();
    _fetchCnbcNews();

    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  // ─── AMBIL BERITA CNBC INDONESIA ───
  Future<void> _fetchCnbcNews() async {
    try {
      final response = await http
          .get(Uri.parse('https://api-berita-indonesia.vercel.app/cnbc/news'))
          .timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['data'] != null && data['data']['posts'] != null) {
          final posts = data['data']['posts'] as List;
          if (posts.isNotEmpty) {
            setState(() {
              newsList = posts.map((item) {
                return {
                  'title': item['title'] ?? '',
                  'desc': item['description'] ?? '',
                  'image': item['thumbnail'] ?? '',
                  'link': item['link'] ?? 'https://www.cnbcindonesia.com/news',
                };
              }).toList();
              if (_bottomNavIndex == 0) {
                _selectedPage = _buildNewsPage();
              }
            });
          }
        }
      }
    } catch (e) {
      debugPrint("Gagal mengambil berita CNBC, menggunakan fallback default: $e");
    }
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _quickActionsController.dispose();
    _batterySub?.cancel();
    _connectivitySub?.cancel();
    _batteryTimer?.cancel();
    _clockTimer?.cancel();
    super.dispose();
  }

  String getAvatarPath() {
    if (_profileImage != null && _profileImage!.existsSync()) {
      return _profileImage!.path;
    }
    return '';
  }

  Future<void> _initBattery() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      if (mounted) {
        setState(() {
          _batteryLevel = level;
          _batteryState = state;
        });
      }

      _batterySub = _battery.onBatteryStateChanged.listen((state) async {
        final newLevel = await _battery.batteryLevel;
        if (mounted) {
          setState(() {
            _batteryState = state;
            _batteryLevel = newLevel;
          });
        }
      });

      _batteryTimer = Timer.periodic(const Duration(seconds: 30), (_) async {
        final newLevel = await _battery.batteryLevel;
        final newState = await _battery.batteryState;
        if (mounted) {
          setState(() {
            _batteryLevel = newLevel;
            _batteryState = newState;
          });
        }
      });
    } catch (e) {
      debugPrint('Battery error: $e');
    }
  }

  Future<void> _initConnectivity() async {
    try {
      final results = await Connectivity().checkConnectivity();
      if (mounted) {
        setState(() => _connectionType = _parseConnectivity(results));
      }

      _connectivitySub =
          Connectivity().onConnectivityChanged.listen((results) {
        if (mounted) {
          setState(() => _connectionType = _parseConnectivity(results));
        }
      });
    } catch (e) {
      debugPrint('Connectivity error: $e');
    }
  }

  String _parseConnectivity(List<ConnectivityResult> results) {
    if (results.contains(ConnectivityResult.wifi)) return 'WIFI';
    if (results.contains(ConnectivityResult.mobile)) return 'MOBILE';
    if (results.contains(ConnectivityResult.ethernet)) return 'ETHERNET';
    if (results.contains(ConnectivityResult.vpn)) return 'VPN';
    return 'OFFLINE';
  }

  Future<void> _loadProfileImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final imagePath = prefs.getString('profile_image_$username');

      if (imagePath != null && imagePath.isNotEmpty) {
        final file = File(imagePath);
        if (file.existsSync()) {
          if (!mounted) return;
          setState(() => _profileImage = file);
        }
      }
    } catch (e) {
      debugPrint('❌ Error load PP: $e');
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
        Uri.parse('wss://app.atlas-by-erlan.com'));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    }, onError: (e) => debugPrint("WS error: $e"));
  }

  Future<void> _openUrl(String url) async {
    if (url.isEmpty) return;
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      debugPrint("Could not launch $uri");
    }
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0:
          _selectedPage = _buildNewsPage();
          break;
        case 1:
          _selectedPage = HomePage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
          break;
        case 2:
          _selectedPage = ControlPanelPage();
          break;
        case 3:
          _selectedPage = ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
            username: username,
            expiredDate: expiredDate,
            listDoos: listDoos,
          );
          break;
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      switch (index) {
        case 1:
          _selectedPage = SellerPage(keyToken: sessionKey);
          break;
        case 2:
          _selectedPage = AdminPage(sessionKey: sessionKey);
          break;
        case 3:
          _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
          break;
      }
    });
    Navigator.pop(context);
  }

  Widget _buildNewsPage() {
    return Container(
      color: brownDark,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildImageHeader(),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: _buildProfileCard(),
            ),
            const SizedBox(height: 16),

            // ─── QUICK ACTIONS (Row: Global Chat kiri, Add Sender kanan) ───
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: SizedBox(
                height: 90,
                child: Row(
                  children: [
                    Expanded(
                      child: _quickActionCard(
                        icon: Icons.public_rounded,
                        label: "Global Chat",
                        sub: "Chat With All User",
                        gradient: const [redMain, redDark],
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => PublicChatPage(
                              username: username,
                              sessionKey: sessionKey,
                              role: role,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _quickActionCard(
                        icon: Icons.add_link_rounded,
                        label: "Add Sender",
                        sub: "Kelola WA Sender",
                        gradient: const [redMain, redDeep],
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => BugSenderPage(
                              sessionKey: sessionKey,
                              username: username,
                              role: role,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),

            // ─── INFO & PENGUMUMAN DIALOG ───
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: GestureDetector(
                onTap: _showInfoDialog,
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [bgCreamLight, bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: borderDark, width: 3),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(4, 4),
                      ),
                      BoxShadow(
                        color: Color(0x88000000),
                        blurRadius: 14,
                        offset: Offset(0, 7),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [redMain, redDark],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: borderDark, width: 2),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xAA000000),
                              blurRadius: 0,
                              offset: Offset(2, 2),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.info_outline,
                          color: white,
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Info & Pengumuman",
                              style: TextStyle(
                                color: redDark,
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 0.5,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              "Klik untuk melihat info terbaru",
                              style: TextStyle(
                                color: brownMid,
                                fontSize: 10,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(
                        Icons.arrow_forward_ios,
                        color: redDark,
                        size: 14,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // ─── HEADER NEWS & BADGE COUNT (BERITA TERKINI SAMAKAN DENGAN SYAM) ───
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [bgCreamLight, bgCream],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x77000000),
                      blurRadius: 10,
                      offset: Offset(0, 5),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.newspaper_rounded, color: redDark, size: 20),
                        SizedBox(width: 8),
                        Text(
                          "BERITA TERKINI",
                          style: TextStyle(
                            color: redDark,
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [redMain, redDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: borderDark, width: 1.8),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0xAA000000),
                            blurRadius: 0,
                            offset: Offset(2, 2),
                          ),
                        ],
                      ),
                      child: Text(
                        "${newsList.length} Berita",
                        style: const TextStyle(
                          color: white,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          shadows: [
                            Shadow(
                              color: Color(0x99000000),
                              blurRadius: 2,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // ─── NEWS CAROUSEL ───
            if (newsList.isNotEmpty)
              SizedBox(
                height: 200,
                child: PageView.builder(
                  controller: PageController(viewportFraction: 0.88),
                  itemCount: newsList.length,
                  itemBuilder: (ctx, i) {
                    final item = newsList[i];
                    final String targetUrl = item['link'] ??
                        item['url'] ??
                        'https://www.cnbcindonesia.com/news';

                    return GestureDetector(
                      onTap: () => _openUrl(targetUrl),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: bgCream,
                          border: Border.all(color: borderDark, width: 3),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(4, 4),
                            ),
                            BoxShadow(
                              color: Color(0x88000000),
                              blurRadius: 14,
                              offset: Offset(0, 7),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(13),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (item['image'] != null &&
                                  item['image'].toString().isNotEmpty)
                                NewsMedia(url: item['image']),
                              Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      redDeep.withOpacity(0.9),
                                      Colors.transparent,
                                    ],
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                  ),
                                ),
                              ),
                              Positioned(
                                top: 12,
                                left: 12,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [redMain, redDark],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(
                                      color: borderDark,
                                      width: 1.5,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xAA000000),
                                        blurRadius: 0,
                                        offset: Offset(2, 2),
                                      ),
                                    ],
                                  ),
                                  child: const Text(
                                    "NEWS",
                                    style: TextStyle(
                                      color: white,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 1,
                                      shadows: [
                                        Shadow(
                                          color: Color(0x99000000),
                                          blurRadius: 2,
                                          offset: Offset(1, 1),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 14,
                                left: 14,
                                right: 14,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item['title'] ?? '',
                                      style: const TextStyle(
                                        color: white,
                                        fontSize: 13,
                                        fontFamily: 'Orbitron',
                                        fontWeight: FontWeight.w900,
                                        shadows: [
                                          Shadow(
                                            color: Color(0xCC000000),
                                            blurRadius: 6,
                                          ),
                                        ],
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      item['desc'] ?? '',
                                      style: const TextStyle(
                                        color: bgCream,
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 20),
            _buildConnectWithAtlas(),
            const SizedBox(height: 25),
          ],
        ),
      ),
    );
  }

  Widget _buildImageHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 14,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: SizedBox(
          height: 220,
          width: double.infinity,
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                'assets/images/header_bg.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [redDark, redDeep],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 10,
                right: 10,
                child: Image.asset(
                  'assets/images/luffy.png',
                  width: 80,
                  height: 80,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const SizedBox(),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      redDeep.withOpacity(0.4),
                      redDeep.withOpacity(0.95),
                    ],
                    stops: const [0.4, 0.7, 1.0],
                  ),
                ),
              ),
              Positioned(
                left: 20,
                bottom: 24,
                child: ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [gold, bgCreamLight, gold],
                  ).createShader(bounds),
                  child: const Text(
                    "ATLAS",
                    style: TextStyle(
                      color: white,
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PROFILE CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildProfileCard() {
    String formattedExpired = expiredDate;
    try {
      final date = DateTime.parse(expiredDate);
      formattedExpired =
          "${date.day}/${date.month}/${date.year}, ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}:${date.second.toString().padLeft(2, '0')}";
    } catch (_) {}

    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [bgCreamLight, bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(5, 5),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 18,
            offset: Offset(0, 9),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: Stack(
          children: [
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: IgnorePointer(
                child: Image.asset(
                  'assets/images/erlan.png',
                  height: 300,
                  fit: BoxFit.contain,
                  alignment: Alignment.bottomCenter,
                  errorBuilder: (_, __, ___) => const SizedBox(height: 300),
                ),
              ),
            ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      bgCream.withOpacity(0.4),
                      Colors.transparent,
                      redDeep.withOpacity(0.75),
                    ],
                    stops: const [0.0, 0.45, 1.0],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [gold, Color(0xFFB8923A)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          border: Border.all(color: borderDark, width: 2),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(2, 2),
                            ),
                            BoxShadow(
                              color: Color(0x66000000),
                              blurRadius: 12,
                              offset: Offset(0, 5),
                            ),
                          ],
                        ),
                        child: CircleAvatar(
                          radius: 20,
                          backgroundColor: bgCream,
                          backgroundImage: _profileImage != null &&
                                  _profileImage!.existsSync()
                              ? FileImage(_profileImage!) as ImageProvider
                              : null,
                          child: _profileImage == null ||
                                  !_profileImage!.existsSync()
                              ? const Icon(
                                  Icons.verified_user,
                                  color: redDark,
                                  size: 20,
                                )
                              : null,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: redDark.withOpacity(0.9),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                    color: borderDark, width: 1.5),
                              ),
                              child: const Text(
                                "Ahlan Wa Sahlan!!",
                                style: TextStyle(
                                  color: white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              username,
                              style: const TextStyle(
                                color: redDark,
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                                shadows: [
                                  Shadow(
                                    color: Color(0x33000000),
                                    blurRadius: 3,
                                    offset: Offset(2, 2),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 3),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [redMain, redDark],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: borderDark, width: 1.5),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0xAA000000),
                                    blurRadius: 0,
                                    offset: Offset(2, 2),
                                  ),
                                ],
                              ),
                              child: Text(
                                role.toUpperCase(),
                                style: const TextStyle(
                                  color: white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.5,
                                  fontFamily: 'Orbitron',
                                  shadows: [
                                    Shadow(
                                      color: Color(0x99000000),
                                      blurRadius: 2,
                                      offset: Offset(1, 1),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildAnalogClock(),
                    ],
                  ),

                  const SizedBox(height: 16),

                  IntrinsicHeight(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(child: _buildBatteryCard()),
                        const SizedBox(width: 10),
                        Expanded(child: _buildNetworkCard()),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [redMain, redDark],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderDark, width: 2.5),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                        BoxShadow(
                          color: Color(0x66000000),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [gold, bgCreamLight, gold],
                      ).createShader(bounds),
                      child: const Text(
                        "ATLAS DASHBOARD",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: white,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.5,
                          fontFamily: 'Orbitron',
                          shadows: [
                            Shadow(
                              color: Color(0xCC000000),
                              blurRadius: 3,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 70),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildBottomStat(
                        icon: Icons.people,
                        value: "$onlineUsers",
                        label: "Online Users",
                        color: accentGreen,
                        showLive: onlineUsers > 0,
                      ),
                      _buildBottomStat(
                        icon: Icons.link,
                        value: "$activeConnections",
                        label: "Active Connections",
                        color: gold,
                        showLive: false,
                      ),
                      _buildBottomStat(
                        icon: Icons.calendar_today_rounded,
                        value: formattedExpired,
                        label: "Expiration",
                        color: white,
                        showLive: false,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalogClock() {
    final hourAngle = (_now.hour % 12) * 30 * math.pi / 180;
    final minuteAngle = _now.minute * 6 * math.pi / 180;
    final secondAngle = _now.second * 6 * math.pi / 180;

    return Column(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: bgCream,
            border: Border.all(color: borderDark, width: 3),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(3, 3),
              ),
              BoxShadow(
                color: Color(0x66000000),
                blurRadius: 10,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: CustomPaint(
            painter: _ClockPainter(
              hourAngle: hourAngle,
              minuteAngle: minuteAngle,
              secondAngle: secondAngle,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [redMain, redDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderDark, width: 1.8),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.access_time_rounded, color: white, size: 10),
              SizedBox(width: 4),
              Text(
                'WIB',
                style: TextStyle(
                  color: white,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                  shadows: [
                    Shadow(
                      color: Color(0x99000000),
                      blurRadius: 2,
                      offset: Offset(1, 1),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🔋 BATTERY CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBatteryCard() {
    final charging = _batteryState == BatteryState.charging ||
        _batteryState == BatteryState.full;

    Color accent;
    String statusText;
    if (charging) {
      accent = const Color(0xFF29B6F6);
      statusText = "Sedang Mengisi";
    } else if (_batteryLevel >= 80) {
      accent = const Color(0xFF00E676);
      statusText = "Baterai Penuh";
    } else if (_batteryLevel >= 50) {
      accent = const Color(0xFF00E676);
      statusText = "Baterai Normal";
    } else if (_batteryLevel >= 20) {
      accent = const Color(0xFFFFC107);
      statusText = "Baterai Lemah";
    } else {
      accent = const Color(0xFFFF1744);
      statusText = "Segera Charge";
    }

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [redMain, redDark, brownDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: [0.0, 0.55, 1.0],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderDark, width: 2.5),
        boxShadow: [
          const BoxShadow(
            color: Color(0xDD000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: redMain.withOpacity(0.35),
            blurRadius: 16,
            spreadRadius: 1,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.10),
            blurRadius: 2,
            offset: const Offset(-1, -1),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  accent,
                  Color.lerp(accent, brownDark, 0.45)!,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: borderDark, width: 2),
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(0.55),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.20),
                  blurRadius: 2,
                  offset: const Offset(-1, -1),
                ),
              ],
            ),
            child: Icon(
              charging
                  ? Icons.battery_charging_full_rounded
                  : (_batteryLevel >= 50
                      ? Icons.battery_full_rounded
                      : (_batteryLevel >= 20
                          ? Icons.battery_4_bar_rounded
                          : Icons.battery_alert_rounded)),
              color: white,
              size: 24,
              shadows: const [
                Shadow(
                  color: Colors.black87,
                  blurRadius: 3,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "DAYA BATERAI",
                  style: TextStyle(
                    color: bgCream,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 2,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 3),
                ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [gold, bgCreamLight, gold],
                  ).createShader(bounds),
                  child: Text(
                    "$_batteryLevel%",
                    style: const TextStyle(
                      color: white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      height: 1.0,
                      letterSpacing: 0.5,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    const Text(
                      "Status: ",
                      style: TextStyle(
                        color: bgCream,
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'ShareTechMono',
                        shadows: [
                          Shadow(
                            color: Color(0x99000000),
                            blurRadius: 2,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                    Flexible(
                      child: Text(
                        statusText,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: accent,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'ShareTechMono',
                          shadows: [
                            Shadow(
                              color: accent.withOpacity(0.9),
                              blurRadius: 6,
                            ),
                            const Shadow(
                              color: Color(0xCC000000),
                              blurRadius: 2,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 📶 NETWORK CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildNetworkCard() {
    String label;
    IconData icon;
    Color accent;

    switch (_connectionType) {
      case 'WIFI':
        label = "Wi-Fi Terhubung";
        icon = Icons.wifi_rounded;
        accent = const Color(0xFF29B6F6);
        break;
      case 'MOBILE':
        label = "Data Seluler";
        icon = Icons.signal_cellular_alt_rounded;
        accent = const Color(0xFF29B6F6);
        break;
      case 'ETHERNET':
        label = "Ethernet Aktif";
        icon = Icons.settings_ethernet_rounded;
        accent = const Color(0xFF29B6F6);
        break;
      case 'VPN':
        label = "VPN Terhubung";
        icon = Icons.vpn_lock_rounded;
        accent = const Color(0xFF9C27B0);
        break;
      default:
        label = "Tidak Ada Koneksi";
        icon = Icons.wifi_off_rounded;
        accent = const Color(0xFFFF1744);
    }

    final bool online = _connectionType != 'OFFLINE';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [redMain, redDark, brownDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: [0.0, 0.55, 1.0],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderDark, width: 2.5),
        boxShadow: [
          const BoxShadow(
            color: Color(0xDD000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: redMain.withOpacity(0.35),
            blurRadius: 16,
            spreadRadius: 1,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.10),
            blurRadius: 2,
            offset: const Offset(-1, -1),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  accent,
                  Color.lerp(accent, brownDark, 0.45)!,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: borderDark, width: 2),
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(0.55),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(3, 3),
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.20),
                  blurRadius: 2,
                  offset: const Offset(-1, -1),
                ),
              ],
            ),
            child: Icon(
              icon,
              color: white,
              size: 24,
              shadows: const [
                Shadow(
                  color: Colors.black87,
                  blurRadius: 3,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "JARINGAN",
                  style: TextStyle(
                    color: bgCream,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(
                        color: Color(0xCC000000),
                        blurRadius: 2,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 3),
                ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [gold, bgCreamLight, gold],
                  ).createShader(bounds),
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      height: 1.1,
                      letterSpacing: 0.3,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    const Text(
                      "Status: ",
                      style: TextStyle(
                        color: bgCream,
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'ShareTechMono',
                        shadows: [
                          Shadow(
                            color: Color(0x99000000),
                            blurRadius: 2,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      online ? "Online" : "Offline",
                      style: TextStyle(
                        color: online
                            ? const Color(0xFF00E676)
                            : const Color(0xFFFF1744),
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'ShareTechMono',
                        shadows: [
                          Shadow(
                            color: (online
                                    ? const Color(0xFF00E676)
                                    : const Color(0xFFFF1744))
                                .withOpacity(0.9),
                            blurRadius: 6,
                          ),
                          const Shadow(
                            color: Color(0xCC000000),
                            blurRadius: 2,
                            offset: Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomStat({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
    bool showLive = false,
  }) {
    return Column(
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bgCream,
                border: Border.all(color: borderDark, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: Color(0x66000000),
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            if (showLive)
              Positioned(
                top: -2,
                right: -2,
                child: Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accentGreen,
                    border: Border.all(color: borderDark, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: accentGreen.withOpacity(0.8),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: const TextStyle(
            color: redDark,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            shadows: [
              Shadow(
                color: Color(0x33000000),
                blurRadius: 2,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            color: brownMid,
            fontSize: 9,
            fontWeight: FontWeight.w700,
          ),
          textAlign: TextAlign.center,
        ),
        if (showLive)
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Text(
              "LIVE",
              style: TextStyle(
                color: accentGreen,
                fontSize: 8,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ),
      ],
    );
  }

  Widget _roleBadge(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [redMain, redDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: borderDark, width: 1.8),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: white,
          fontSize: 10,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.8,
          fontFamily: 'Orbitron',
          shadows: [
            Shadow(
              color: Color(0x99000000),
              blurRadius: 2,
              offset: Offset(1, 1),
            ),
          ],
        ),
      ),
    );
  }

  Widget _quickActionCard({
    required IconData icon,
    required String label,
    required String sub,
    required List<Color> gradient,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 2),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderDark, width: 2.5),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(3, 3),
            ),
            BoxShadow(
              color: Color(0x88000000),
              blurRadius: 10,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -10,
              bottom: -10,
              child: Icon(
                icon,
                size: 65,
                color: white.withOpacity(0.08),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: white.withOpacity(0.2),
                      shape: BoxShape.circle,
                      border: Border.all(color: borderDark, width: 1.5),
                    ),
                    child: Icon(icon, color: white, size: 20),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          label,
                          style: const TextStyle(
                            color: white,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            shadows: [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 3,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          sub,
                          style: const TextStyle(
                            color: bgCream,
                            fontSize: 9,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'ShareTechMono',
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: white,
                    size: 12,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showInfoDialog() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [bgCreamLight, bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderDark, width: 3.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(6, 6),
              ),
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 24,
                offset: Offset(0, 12),
              ),
            ],
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [redMain, redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: borderDark, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: const Icon(Icons.info_outline, color: white, size: 30),
              ),
              const SizedBox(height: 16),
              const Text(
                "INFO & PENGUMUMAN",
                style: TextStyle(
                  color: redDark,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(
                      color: Color(0x33000000),
                      blurRadius: 3,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: bgCream,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                  ],
                ),
                child: const Text(
                  "Update Terbaru\n\n"
                  "• Penambahan Fitur Story Instagram\n"
                  "• Memperbagus Dashboard 3D\n"
                  "• Tema Merah Kecoklatan HD\n"
                  "• Dan Lain Lain!\n\n"
                  "Terima kasih telah menggunakan ATLAS!",
                  style: TextStyle(
                    color: textDark,
                    height: 1.7,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'ShareTechMono',
                    fontSize: 13,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 30, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [redMain, redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: borderDark, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(3, 3),
                      ),
                    ],
                  ),
                  child: const Text(
                    "TUTUP",
                    style: TextStyle(
                      color: white,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      fontSize: 13,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: Color(0x99000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: brownDark,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [redDark, redDeep],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [gold, Color(0xFFB8923A)],
                      ),
                      border: Border.all(color: borderDark, width: 2.5),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xCC000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                      ],
                    ),
                    child: _profileImage != null &&
                            _profileImage!.existsSync()
                        ? ClipOval(
                            child:
                                Image.file(_profileImage!, fit: BoxFit.cover))
                        : const Icon(Icons.person_rounded,
                            color: redDark, size: 30),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          username,
                          style: const TextStyle(
                            color: white,
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            fontFamily: 'Orbitron',
                            letterSpacing: 0.5,
                            shadows: [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 4,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 4),
                        _roleBadge(role.toUpperCase()),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.only(top: 8),
                children: [
                  if (role == 'reseller')
                    _buildDrawerMenuItem(
                      icon: Icons.storefront_rounded,
                      label: "Seller Page",
                      onTap: () => _onSidebarTabSelected(1),
                    ),
                  if (role == 'partner')
                    _buildDrawerMenuItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: "Admin Page",
                      onTap: () => _onSidebarTabSelected(2),
                    ),
                  if (role == 'pemula')
                    _buildDrawerMenuItem(
                      icon: Icons.workspace_premium_rounded,
                      label: "Owner Page",
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  _buildDrawerMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                            sessionKey: sessionKey,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.lock_outline_rounded,
                    label: "Ganti Password",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChangePasswordPage(
                            username: username,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.add_link_rounded,
                    label: "Add Sender",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BugSenderPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.arrow_upward,
                    label: "Up Role",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => UpgradeRolePage(
                            sessionKey: sessionKey,
                            role: role,
                            username: username,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  _buildDrawerMenuItem(
                    icon: Icons.logout_rounded,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isLogout
              ? [redMain, redDark]
              : [bgCreamLight, bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: isLogout
                ? Colors.black.withOpacity(0.3)
                : redMain.withOpacity(0.15),
            shape: BoxShape.circle,
            border: Border.all(
              color: isLogout ? white : redMain,
              width: 1.8,
            ),
          ),
          child: Icon(
            icon,
            color: isLogout ? white : redDark,
            size: 16,
          ),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? white : redDark,
            fontWeight: FontWeight.w900,
            fontSize: 14,
            fontFamily: 'Orbitron',
            letterSpacing: 0.3,
            shadows: const [
              Shadow(
                color: Color(0x33000000),
                blurRadius: 2,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: isLogout ? white : redDark,
          size: 12,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        dense: true,
        onTap: onTap,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🔗 CONNECT WITH ATLAS (DISAMAKAN UKURAN DAN STRUKTUR DENGAN SYAM)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildConnectWithAtlas() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 0),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 14,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ─── JUDUL ───
              Row(
                children: [
                  Icon(
                    Icons.handshake_rounded,
                    color: const Color(0xFFE91E63),
                    size: 20,
                    shadows: const [
                      Shadow(
                        color: Color(0xFFE91E63),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    "CONNECT WITH ATLAS",
                    style: TextStyle(
                      color: white,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // ─── TOMBOL SOCIAL (PROPORSIONAL DENGAN SYAM) ───
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildSocialCircleBtn(
                    icon: FontAwesomeIcons.paperPlane,
                    label: "Telegram",
                    url: "https://t.me/bllackmatchaa",
                    circleColor: redDark,
                    iconColor: white,
                  ),
                  _buildSocialCircleBtn(
                    icon: FontAwesomeIcons.music,
                    label: "TikTok",
                    url: "https://tiktok.com/@LanxyzMods",
                    circleColor: const Color(0xFF222222),
                    iconColor: white,
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // ─── TAGLINE ───
              const Center(
                child: Text(
                  "Selalu nantikan project terbaru dari TEAM ATLAS",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Tombol bulat social media ───
  Widget _buildSocialCircleBtn({
    required IconData icon,
    required String label,
    required String url,
    required Color circleColor,
    required Color iconColor,
  }) {
    return GestureDetector(
      onTap: url.isEmpty ? null : () => _openUrl(url),
      child: Column(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: circleColor,
              border: Border.all(
                color: Colors.white24,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: circleColor.withOpacity(0.4),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
                const BoxShadow(
                  color: Color(0xCC000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 22,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              color: white,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool hideAppBar = _bottomNavIndex == 1;

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: brownDark,
      extendBodyBehindAppBar: !hideAppBar,

      appBar: hideAppBar
          ? null
          : PreferredSize(
              preferredSize: const Size.fromHeight(70),
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [redMain, redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: const Border(
                    bottom: BorderSide(color: borderDark, width: 3),
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xCC000000),
                      blurRadius: 0,
                      offset: Offset(0, 4),
                    ),
                    BoxShadow(
                      color: Color(0x88000000),
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: SafeArea(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Positioned(
                        left: 8,
                        child: Builder(
                          builder: (ctx) => IconButton(
                            icon: const Icon(Icons.menu,
                                color: white, size: 26),
                            onPressed: () =>
                                _scaffoldKey.currentState?.openDrawer(),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 56,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [redMain, redDark],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: borderDark, width: 2),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(2, 2),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.notifications_rounded,
                                  color: white, size: 13),
                              const SizedBox(width: 5),
                              Text(
                                "Hai $username",
                                style: const TextStyle(
                                  color: white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 12,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 0.5,
                                  shadows: [
                                    Shadow(
                                      color: Color(0x99000000),
                                      blurRadius: 2,
                                      offset: Offset(1, 1),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        right: 16,
                        child: Row(
                          children: [
                            GestureDetector(
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => InfoPage(sessionKey: sessionKey)),
                              ),
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: redDark,
                                  border:
                                      Border.all(color: white, width: 2),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 0,
                                      offset: Offset(2, 2),
                                    ),
                                    BoxShadow(
                                      color: Color(0x66000000),
                                      blurRadius: 8,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.rule_rounded,
                                  color: white,
                                  size: 18,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            GestureDetector(
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => const MusicPage()),
                              ),
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: redDark,
                                  border: Border.all(color: gold, width: 2),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 0,
                                      offset: Offset(2, 2),
                                    ),
                                    BoxShadow(
                                      color: Color(0x66000000),
                                      blurRadius: 8,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.music_note_rounded,
                                  color: gold,
                                  size: 20,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            GestureDetector(
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => const ContactPage()),
                              ),
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: redDark,
                                  border:
                                      Border.all(color: white, width: 2),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 0,
                                      offset: Offset(2, 2),
                                    ),
                                    BoxShadow(
                                      color: Color(0x66000000),
                                      blurRadius: 8,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.headset_mic_outlined,
                                  color: white,
                                  size: 18,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            GestureDetector(
                              onTap: () async {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => ProfilePage(
                                      username: username,
                                      password: password,
                                      role: role,
                                      expiredDate: expiredDate,
                                      sessionKey: sessionKey,
                                      uid: uid,
                                    ),
                                  ),
                                );
                                _loadProfileImage();
                              },
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: _profileImage == null ||
                                          !_profileImage!.existsSync()
                                      ? const LinearGradient(
                                          colors: [
                                            gold,
                                            Color(0xFFB8923A)
                                          ],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        )
                                      : null,
                                  color: _profileImage != null &&
                                          _profileImage!.existsSync()
                                      ? bgCream
                                      : null,
                                  border: Border.all(
                                      color: borderDark, width: 2.5),
                                  image: _profileImage != null &&
                                          _profileImage!.existsSync()
                                      ? DecorationImage(
                                          image:
                                              FileImage(_profileImage!),
                                          fit: BoxFit.cover,
                                        )
                                      : null,
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xCC000000),
                                      blurRadius: 0,
                                      offset: Offset(2, 2),
                                    ),
                                    BoxShadow(
                                      color: Color(0x66000000),
                                      blurRadius: 8,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: _profileImage == null ||
                                        !_profileImage!.existsSync()
                                    ? const Icon(Icons.person_rounded,
                                        color: redDark, size: 20)
                                    : null,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

      drawer: _buildCustomDrawer(),
      body: SafeArea(
        child: FadeTransition(
          opacity: _animation,
          child: _selectedPage,
        ),
      ),
      extendBody: true,
      bottomNavigationBar: Container(
        padding: EdgeInsets.zero,
        decoration: const BoxDecoration(
          color: Colors.transparent,
        ),
        child: GlazeNavBar(
          key: _navBarKey,
          index: _bottomNavIndex,
          backgroundColor: brownDark,
          items: [
            GlazeNavBarItem(
              child: Icon(
                Icons.home_rounded,
                color: _bottomNavIndex == 0 ? gold : bgCream,
                size: 26,
              ),
              label: 'Home',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 0 ? gold : bgCream,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                FontAwesomeIcons.whatsapp,
                color: _bottomNavIndex == 1 ? gold : bgCream,
                size: 26,
              ),
              label: 'WhatsApp',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 1 ? gold : bgCream,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                Icons.settings_remote_rounded,
                color: _bottomNavIndex == 2 ? gold : bgCream,
                size: 26,
              ),
              label: 'Rat',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 2 ? gold : bgCream,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                Icons.build_rounded,
                color: _bottomNavIndex == 3 ? gold : bgCream,
                size: 26,
              ),
              label: 'Tools',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 3 ? gold : bgCream,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
          onTap: (index) => _onBottomNavTapped(index),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// CUSTOM PAINTER JAM ANALOG
// ═══════════════════════════════════════════════════════════════════
class _ClockPainter extends CustomPainter {
  final double hourAngle;
  final double minuteAngle;
  final double secondAngle;

  _ClockPainter({
    required this.hourAngle,
    required this.minuteAngle,
    required this.secondAngle,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final dotPaint = Paint()..color = const Color(0xFF1A0A0A).withOpacity(0.5);
    for (int i = 0; i < 12; i++) {
      final angle = i * 30 * math.pi / 180 - math.pi / 2;
      final dotX = center.dx + (radius - 8) * math.cos(angle);
      final dotY = center.dy + (radius - 8) * math.sin(angle);
      canvas.drawCircle(Offset(dotX, dotY), 1.8, dotPaint);
    }

    final hourPaint = Paint()
      ..color = const Color(0xFF7F0000)
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      center,
      Offset(
        center.dx + (radius * 0.45) * math.cos(hourAngle - math.pi / 2),
        center.dy + (radius * 0.45) * math.sin(hourAngle - math.pi / 2),
      ),
      hourPaint,
    );

    final minutePaint = Paint()
      ..color = const Color(0xFFB71C1C)
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      center,
      Offset(
        center.dx + (radius * 0.7) * math.cos(minuteAngle - math.pi / 2),
        center.dy + (radius * 0.7) * math.sin(minuteAngle - math.pi / 2),
      ),
      minutePaint,
    );

    final secondPaint = Paint()
      ..color = const Color(0xFFD4A853)
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(
        center.dx - (radius * 0.15) * math.cos(secondAngle - math.pi / 2),
        center.dy - (radius * 0.15) * math.sin(secondAngle - math.pi / 2),
      ),
      Offset(
        center.dx + (radius * 0.85) * math.cos(secondAngle - math.pi / 2),
        center.dy + (radius * 0.85) * math.sin(secondAngle - math.pi / 2),
      ),
      secondPaint,
    );

    canvas.drawCircle(
        center, 2.5, Paint()..color = const Color(0xFF7F0000));
  }

  @override
  bool shouldRepaint(covariant _ClockPainter oldDelegate) =>
      oldDelegate.hourAngle != hourAngle ||
      oldDelegate.minuteAngle != minuteAngle ||
      oldDelegate.secondAngle != secondAngle;
}

// ═══════════════════════════════════════════════════════════════════
// NEWS MEDIA WIDGET
// ═══════════════════════════════════════════════════════════════════
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      }
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFFB71C1C)),
      );
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: const Color(0xFF2B0E0E),
        child: const Icon(Icons.error, color: Colors.grey),
      ),
    );
  }
}
