import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import '../widgets/custom_popup.dart';
import '../sistem/apiBaseUrl.dart';

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['partner', 'reseller', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  XFile? _selectedImage;
  String _imageBase64 = '';

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 WARNA 3D MERAH KECOKLATAN (konsisten semua halaman)
  // ═══════════════════════════════════════════════════════════════════
  static const Color bgCream      = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain      = Color(0xFFB71C1C);
  static const Color redDark      = Color(0xFF7F0000);
  static const Color redDeep      = Color(0xFF4A0000);
  static const Color brownDark    = Color(0xFF2B0E0E);
  static const Color brownMid     = Color(0xFF5D2B1F);
  static const Color gold         = Color(0xFFD4A853);
  static const Color textDark     = Color(0xFF1A0A0A);
  static const Color borderDark   = Color(0xFF1A0505);
  static const Color white        = Colors.white;
  static const Color accentGreen  = Color(0xFF4CAF50);
  static const Color accentBlue   = Color(0xFF1976D2);
  static const Color accentAmber  = Color(0xFFF9A825);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$apiBaseUrl/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$apiBaseUrl/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          '$apiBaseUrl/submitPending');
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'username': u,
          'password': p,
          'day': d,
          'role': newUserRole,
          'imageBase64': _imageBase64,
        }),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _alert("Sukses",
            "Permintaan akun dikirim! Tunggu approval Owner di Telegram.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _imageBase64 = '';
        _selectedImage = null;
        newUserRole = 'member';
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengirim permintaan.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          '$apiBaseUrl/editUser?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    CustomPopup.display(
      context,
      title: title,
      message: message,
      icon: title.toLowerCase().contains("sukses")
          ? Icons.check_circle_outline
          : Icons.info_outline,
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // INPUT FIELD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [bgCreamLight, bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: const TextStyle(
          color: textDark,
          fontWeight: FontWeight.w700,
          fontFamily: 'ShareTechMono',
        ),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(
            color: redDark,
            fontSize: 12,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 0.5,
          ),
          prefixIcon: Icon(icon, color: redDark, size: 18),
          filled: true,
          fillColor: Colors.transparent,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PICK IMAGE
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final bytes = await File(image.path).readAsBytes();
      setState(() {
        _selectedImage = image;
        _imageBase64 = base64Encode(bytes);
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP — Dialog Wrapper 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _build3DDialog({
    required Color accentColor,
    required IconData icon,
    required String title,
    required List<Widget> children,
    double iconSize = 30,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [bgCreamLight, bgCream],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: borderDark, width: 3.5),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(6, 6),
            ),
            BoxShadow(
              color: Color(0xAA000000),
              blurRadius: 24,
              offset: Offset(0, 12),
            ),
          ],
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      accentColor,
                      Color.lerp(accentColor, Colors.black, 0.4)!,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: borderDark, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(3, 3),
                    ),
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: Icon(icon, color: white, size: iconSize),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: const TextStyle(
                  color: redDark,
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                  shadows: [
                    Shadow(
                      color: Color(0x33000000),
                      blurRadius: 3,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 22),
              ...children,
            ],
          ),
        ),
      ),
    );
  }

  // ─── Button 3D ───
  Widget _build3DButton({
    required String label,
    required Color color,
    required VoidCallback onTap,
    IconData? icon,
    double height = 50,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, Color.lerp(color, Colors.black, 0.4)!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: borderDark, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Color(0xCC000000),
              blurRadius: 0,
              offset: Offset(4, 4),
            ),
            BoxShadow(
              color: Color(0x88000000),
              blurRadius: 12,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, color: white, size: 18),
              const SizedBox(width: 8),
            ],
            Text(
              label,
              style: const TextStyle(
                color: white,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
                fontFamily: 'Orbitron',
                fontSize: 12,
                shadows: [
                  Shadow(
                    color: Color(0x99000000),
                    blurRadius: 3,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP: STORAGE QR
  // ═══════════════════════════════════════════════════════════════════
  void _showStorageQRPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: _build3DDialog(
          accentColor: accentAmber,
          icon: Icons.qr_code_rounded,
          title: "STOR DISINI 5K",
          children: [
            Container(
              decoration: BoxDecoration(
                color: white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: borderDark, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(8),
              child: Image.network(
                'https://h.top4top.io/p_3874d6tkv1.jpg',
                height: 200,
                width: 200,
                fit: BoxFit.contain,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Scan QR untuk melakukan pembayaran",
              style: TextStyle(
                color: brownMid,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: 'ShareTechMono',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            _build3DButton(
              label: "TUTUP",
              color: redMain,
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP: CREATE ACCOUNT
  // ═══════════════════════════════════════════════════════════════════
  void _showCreateAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
            child: _build3DDialog(
              accentColor: accentGreen,
              icon: FontAwesomeIcons.userPlus,
              title: "CREATE ACCOUNT",
              children: [
                // Tombol pilih foto 3D
                GestureDetector(
                  onTap: () async {
                    await _pickImage();
                    setModalState(() {});
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: _selectedImage == null
                            ? [brownMid, redDeep]
                            : [accentGreen, const Color(0xFF1B5E20)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderDark, width: 2.5),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xAA000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.photo_camera_rounded,
                            color: white, size: 20),
                        const SizedBox(width: 10),
                        Text(
                          _selectedImage == null
                              ? "PILIH FOTO (OPSIONAL)"
                              : "FOTO TERPILIH ✓",
                          style: const TextStyle(
                            color: white,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            fontSize: 11,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Preview foto
                if (_selectedImage != null) ...[
                  Container(
                    height: 100,
                    width: 100,
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      border: Border.all(color: borderDark, width: 3),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xAA000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(9),
                      child: Image.file(
                        File(_selectedImage!.path),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],

                _buildInput(
                  label: "Username",
                  controller: createUsernameController,
                  icon: FontAwesomeIcons.user,
                ),
                _buildInput(
                  label: "Password",
                  controller: createPasswordController,
                  icon: FontAwesomeIcons.lock,
                ),
                _buildInput(
                  label: "Durasi (Hari)",
                  controller: createDayController,
                  icon: FontAwesomeIcons.calendarDay,
                  type: TextInputType.number,
                ),

                // Dropdown Role 3D
                Container(
                  margin: const EdgeInsets.only(bottom: 20),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [bgCreamLight, bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: borderDark, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(3, 3),
                      ),
                    ],
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: newUserRole,
                      dropdownColor: bgCreamLight,
                      isExpanded: true,
                      style: const TextStyle(
                        color: textDark,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                      ),
                      icon: const Icon(Icons.keyboard_arrow_down,
                          color: redDark),
                      items: roleOptions.map((role) {
                        return DropdownMenuItem(
                          value: role,
                          child: Text(role.toUpperCase()),
                        );
                      }).toList(),
                      onChanged: (val) =>
                          setModalState(() => newUserRole = val ?? 'member'),
                    ),
                  ),
                ),

                _build3DButton(
                  label: "KIRIM REQUEST",
                  color: accentGreen,
                  icon: Icons.send_rounded,
                  onTap: () {
                    Navigator.pop(context);
                    _createAccount();
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP: EXTEND DURATION
  // ═══════════════════════════════════════════════════════════════════
  void _showExtendDurationPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: _build3DDialog(
          accentColor: accentBlue,
          icon: FontAwesomeIcons.clock,
          title: "ADD DURATION",
          children: [
            _buildInput(
              label: "Username Target",
              controller: editUsernameController,
              icon: FontAwesomeIcons.userEdit,
            ),
            _buildInput(
              label: "Tambah Hari",
              controller: editDayController,
              icon: FontAwesomeIcons.calendarPlus,
              type: TextInputType.number,
            ),
            const SizedBox(height: 6),
            _build3DButton(
              label: "ADD DAYS",
              color: accentBlue,
              icon: Icons.add_circle_outline_rounded,
              onTap: () {
                Navigator.pop(context);
                _editUser();
              },
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // POPUP: DELETE ACCOUNT
  // ═══════════════════════════════════════════════════════════════════
  void _showDeleteAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: _build3DDialog(
          accentColor: redMain,
          icon: FontAwesomeIcons.userSlash,
          title: "DELETE ACCOUNT",
          children: [
            _buildInput(
              label: "Username Target",
              controller: deleteController,
              icon: FontAwesomeIcons.user,
            ),
            const SizedBox(height: 6),
            _build3DButton(
              label: "DELETE",
              color: redMain,
              icon: Icons.delete_forever_rounded,
              onTap: () {
                Navigator.pop(context);
                _deleteUser();
              },
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TOMBOL BESAR 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildTopButton({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [bgCreamLight, bgCream],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderDark, width: 3),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
              BoxShadow(
                color: Color(0x77000000),
                blurRadius: 12,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, Color.lerp(color, Colors.black, 0.4)!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(icon, color: white, size: 20),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: redDark,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                  height: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // USER ITEM 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [bgCreamLight, bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x77000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [redMain, redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(color: borderDark, width: 2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: const Icon(Icons.person_rounded, color: white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'].toString(),
                  style: const TextStyle(
                    color: redDark,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    fontFamily: 'Orbitron',
                    shadows: [
                      Shadow(
                        color: Color(0x33000000),
                        blurRadius: 2,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()}  |  EXP: ${user['expiredDate']}",
                  style: const TextStyle(
                    color: brownMid,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              deleteController.text = user['username'];
              _showDeleteAccountPopup();
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [redMain, redDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                border: Border.all(color: borderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.delete_outline_rounded,
                  color: white, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PAGINATION 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              gradient: isSelected
                  ? const LinearGradient(
                      colors: [redMain, redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : const LinearGradient(
                      colors: [bgCreamLight, bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: borderDark, width: 2.5),
              boxShadow: const [
                BoxShadow(
                  color: Color(0xAA000000),
                  blurRadius: 0,
                  offset: Offset(2, 2),
                ),
              ],
            ),
            child: Text(
              "$page",
              style: TextStyle(
                color: isSelected ? white : redDark,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: brownDark,
      body: SafeArea(
        child: isLoading && fullUserList.isEmpty
            ? const Center(child: CircularProgressIndicator(color: redMain))
            : SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(
                    horizontal: 20, vertical: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // ─── HEADER 3D ───
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [gold, Color(0xFFB8923A)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            shape: BoxShape.circle,
                            border: Border.all(color: borderDark, width: 2.5),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: const Icon(Icons.workspace_premium_rounded,
                              color: redDark, size: 26),
                        ),
                        const SizedBox(width: 12),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "OWNER PANEL",
                              style: TextStyle(
                                color: bgCreamLight,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                                shadows: [
                                  Shadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 4,
                                    offset: Offset(1, 1),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              "Management Dashboard",
                              style: TextStyle(
                                color: gold,
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // ─── TOMBOL STOR DISINI 5K ───
                    _build3DButton(
                      label: "STOR DISINI 5K",
                      color: accentAmber,
                      icon: Icons.qr_code_rounded,
                      height: 50,
                      onTap: _showStorageQRPopup,
                    ),
                    const SizedBox(height: 20),

                    // ─── 3 BUTTON ROW ───
                    Row(
                      children: [
                        _buildTopButton(
                          title: "BUAT\nAKUN",
                          icon: FontAwesomeIcons.userPlus,
                          color: accentGreen,
                          onTap: _showCreateAccountPopup,
                        ),
                        const SizedBox(width: 12),
                        _buildTopButton(
                          title: "ADD\nDURASI",
                          icon: FontAwesomeIcons.clock,
                          color: accentBlue,
                          onTap: _showExtendDurationPopup,
                        ),
                        const SizedBox(width: 12),
                        _buildTopButton(
                          title: "HAPUS\nAKUN",
                          icon: FontAwesomeIcons.userSlash,
                          color: redMain,
                          onTap: _showDeleteAccountPopup,
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),

                    // ─── USER DIRECTORY ───
                    Row(
                      children: [
                        Container(
                          width: 5,
                          height: 18,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [redMain, redDark],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                            borderRadius: BorderRadius.circular(3),
                            border: Border.all(color: borderDark, width: 1.5),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xAA000000),
                                blurRadius: 0,
                                offset: Offset(2, 2),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          "USER DIRECTORY",
                          style: TextStyle(
                            color: gold,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1.5,
                            shadows: [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 4,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // ─── ROLE FILTER DROPDOWN 3D ───
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [bgCreamLight, bgCream],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: borderDark, width: 2.5),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0xCC000000),
                            blurRadius: 0,
                            offset: Offset(3, 3),
                          ),
                          BoxShadow(
                            color: Color(0x77000000),
                            blurRadius: 10,
                            offset: Offset(0, 5),
                          ),
                        ],
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: bgCreamLight,
                          isExpanded: true,
                          style: const TextStyle(
                            color: redDark,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 0.5,
                          ),
                          icon: const Icon(Icons.keyboard_arrow_down_rounded,
                              color: redDark),
                          items: roleOptions.map((role) {
                            return DropdownMenuItem(
                              value: role,
                              child: Text(role.toUpperCase()),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() {
                                selectedRole = val;
                                _filterAndPaginate();
                              });
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // ─── LOADING / EMPTY STATE ───
                    if (isLoading && fullUserList.isNotEmpty)
                      const Center(
                        child: Padding(
                          padding: EdgeInsets.all(20),
                          child:
                              CircularProgressIndicator(color: redMain),
                        ),
                      ),

                    if (filteredList.isEmpty && !isLoading)
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 40),
                          child: Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [bgCreamLight, bgCream],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: borderDark, width: 3),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xAA000000),
                                      blurRadius: 0,
                                      offset: Offset(3, 3),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.person_off_rounded,
                                  color: redDark,
                                  size: 40,
                                ),
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                "Belum ada user di kategori ini.",
                                style: TextStyle(
                                  color: gold,
                                  fontSize: 12,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                    // ─── USER LIST ───
                    ..._getCurrentPageData()
                        .map((u) => _buildUserItem(u))
                        .toList(),

                    const SizedBox(height: 20),
                    Center(child: _buildPagination()),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
      ),
    );
  }
}