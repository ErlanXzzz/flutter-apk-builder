// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'audio_service.dart';

// ── Tema MERAH DARAH ─────────────────────────────────────────────────────────
const Color _cRed = Color(0xFFD32F2F);
const Color _cRedDark = Color(0xFFB71C1C);
const Color _cRedMid = Color(0xFFC62828);
const Color _cBg = Color(0xFF141820);
const Color _cBgCard = Color(0xFF1C2230);
const Color _cBgSidebar = Color(0xFF1A1F2C);
const Color _cBgCardHi = Color(0xFF2A3242); // ⬅️ tambahan untuk gradient 3D
const String _font = "Rajdhani";

// ── ENDPOINT API ────────────────────────────────────────────────────────────
const String _kSearchEndpoint = "https://api.deezer.com/search";
const String _kTopChartEndpoint = "https://api.deezer.com/chart/0/tracks?limit=25";

class MusicPage extends StatefulWidget {
  const MusicPage({super.key});

  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> with TickerProviderStateMixin {
  final TextEditingController _searchCtrl = TextEditingController();
  final FocusNode _searchFocus = FocusNode();
  final AudioService _audioService = AudioService();

  List<_Track> _searchResults = [];
  List<_Track> _topTracks = [];

  bool _isSearching = false;
  bool _hasSearched = false;
  bool _isLoadingTop = true;
  String? _topError;
  String? _searchError;

  String? _currentlyPlayingId;
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _currentDuration = Duration.zero;
  _Track? _currentTrack;

  List<_Track> _currentPlaylist = [];

  Timer? _debounce;

  late AnimationController _entryAnim;

  @override
  void initState() {
    super.initState();

    _entryAnim = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    )..forward();

    _fetchTopTracks();

    _searchCtrl.addListener(() => _onSearchChanged(_searchCtrl.text));

    _audioService.player.onPlayerComplete.listen((_) {
      if (!mounted) return;
      _playNextAuto();
    });
    _audioService.player.onDurationChanged.listen((d) {
      if (!mounted) return;
      setState(() => _currentDuration = d);
    });
    _audioService.player.onPositionChanged.listen((p) {
      if (!mounted) return;
      setState(() => _currentPosition = p);
    });
    _audioService.player.onPlayerStateChanged.listen((state) {
      if (!mounted) return;
      setState(() => _isPlaying = state == PlayerState.playing);
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _entryAnim.dispose();
    _searchCtrl.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  Future<void> _fetchTopTracks() async {
    setState(() {
      _isLoadingTop = true;
      _topError = null;
    });
    try {
      final res = await http
          .get(Uri.parse(_kTopChartEndpoint))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = (body['data'] as List?) ?? const [];
        final list = raw
            .whereType<Map<String, dynamic>>()
            .map(_Track.fromDeezer)
            .where((t) => t.previewUrl.isNotEmpty)
            .toList();
        if (mounted) {
          setState(() {
            _topTracks = list;
            _isLoadingTop = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isLoadingTop = false;
            _topError = "Gagal memuat (HTTP ${res.statusCode})";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingTop = false;
          _topError = "Gagal memuat: $e";
        });
      }
    }
  }

  Future<void> _searchMusic(String query) async {
    final q = query.trim();
    if (q.isEmpty) {
      setState(() {
        _searchResults = [];
        _isSearching = false;
        _hasSearched = false;
        _searchError = null;
      });
      return;
    }

    setState(() {
      _isSearching = true;
      _hasSearched = true;
      _searchError = null;
    });

    try {
      final uri = Uri.parse(
          "$_kSearchEndpoint?q=${Uri.encodeQueryComponent(q)}&limit=40");
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = (body['data'] as List?) ?? const [];
        final list = raw
            .whereType<Map<String, dynamic>>()
            .map(_Track.fromDeezer)
            .toList();
        if (mounted) {
          setState(() {
            _searchResults = list;
            _isSearching = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isSearching = false;
            _searchError = "Gagal mencari (HTTP ${res.statusCode})";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _searchError = "Gagal mencari: $e";
        });
      }
    }
  }

  void _onSearchChanged(String q) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () => _searchMusic(q));
  }

  Future<void> _togglePlay(_Track track) async {
    if (track.previewUrl.isEmpty) {
      _showSnack("Preview audio tidak tersedia untuk lagu ini.");
      return;
    }
    try {
      if (_currentlyPlayingId == track.id && _audioService.isPlaying) {
        await _audioService.pause();
        if (mounted) setState(() => _isPlaying = false);
        return;
      }
      if (_currentlyPlayingId == track.id && !_audioService.isPlaying) {
        await _audioService.player.resume();
        if (mounted) setState(() => _isPlaying = true);
        return;
      }

      _currentPlaylist = _hasSearched && _searchResults.contains(track)
          ? List.from(_searchResults)
          : List.from(_topTracks);

      await _audioService.play(track.previewUrl, track.id);
      if (mounted) {
        setState(() {
          _currentlyPlayingId = track.id;
          _currentTrack = track;
          _isPlaying = true;
        });
      }
    } catch (e) {
      _showSnack("Gagal memutar: $e");
    }
  }

  Future<void> _playNextAuto() async {
    if (_currentPlaylist.isEmpty || _currentTrack == null) {
      if (mounted) {
        setState(() {
          _isPlaying = false;
          _currentlyPlayingId = null;
          _currentTrack = null;
          _currentPosition = Duration.zero;
        });
      }
      return;
    }

    final idx = _currentPlaylist.indexWhere((t) => t.id == _currentTrack!.id);
    if (idx < 0) return;

    final nextIdx = (idx + 1) % _currentPlaylist.length;
    if (nextIdx == idx) return;

    final next = _currentPlaylist[nextIdx];

    if (next.previewUrl.isEmpty) {
      if (nextIdx == idx) return;
      _currentTrack = next;
      _playNextAuto();
      return;
    }

    try {
      await _audioService.play(next.previewUrl, next.id);
      if (mounted) {
        setState(() {
          _currentlyPlayingId = next.id;
          _currentTrack = next;
          _isPlaying = true;
        });
      }
    } catch (e) {
      debugPrint('Auto-next error: $e');
    }
  }

  Future<void> _playPrevAuto() async {
    if (_currentPlaylist.isEmpty || _currentTrack == null) return;
    final idx = _currentPlaylist.indexWhere((t) => t.id == _currentTrack!.id);
    if (idx < 0) return;

    final prevIdx = (idx - 1 + _currentPlaylist.length) % _currentPlaylist.length;
    final prev = _currentPlaylist[prevIdx];

    if (prev.previewUrl.isEmpty) return;

    try {
      await _audioService.play(prev.previewUrl, prev.id);
      if (mounted) {
        setState(() {
          _currentlyPlayingId = prev.id;
          _currentTrack = prev;
          _isPlaying = true;
        });
      }
    } catch (e) {
      debugPrint('Prev error: $e');
    }
  }

  Future<void> _stopPlayer() async {
    await _audioService.stop();
    if (mounted) {
      setState(() {
        _isPlaying = false;
        _currentlyPlayingId = null;
        _currentTrack = null;
        _currentPosition = Duration.zero;
      });
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _cBgCard,
        content: Text(
          msg,
          style: const TextStyle(color: Colors.white, fontFamily: _font),
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFF000000), width: 2),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _cBg,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [_cBg, Color(0xFF0E1118), _cBg],
              ),
            ),
          ),
          Positioned(
            top: -40,
            left: -40,
            child: Opacity(
              opacity: 0.12,
              child: _MusicHexPattern(size: 220, color: _cRed.withOpacity(0.4)),
            ),
          ),
          Positioned(
            bottom: -50,
            right: -50,
            child: Opacity(
              opacity: 0.10,
              child: _MusicHexPattern(size: 260, color: _cRed.withOpacity(0.4)),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                _buildSearchBar(),
                Expanded(
                  child: FadeTransition(
                    opacity: CurvedAnimation(
                        parent: _entryAnim, curve: Curves.easeOut),
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.only(bottom: 120),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (_hasSearched) ...[
                            _buildSectionHeader(
                              icon: Icons.search_rounded,
                              title: "HASIL PENCARIAN",
                              count: _searchResults.length,
                            ),
                            const SizedBox(height: 8),
                            _buildResultsList(_searchResults,
                                isLoading: _isSearching,
                                error: _searchError,
                                emptyMsg:
                                    "Tidak ada hasil untuk \"${_searchCtrl.text}\""),
                            const SizedBox(height: 24),
                          ],
                          _buildSectionHeader(
                            icon: Icons.local_fire_department_rounded,
                            title: "MUSIK TERPOPULER",
                            count: _topTracks.length,
                            iconColor: Colors.orangeAccent,
                          ),
                          const SizedBox(height: 8),
                          _buildResultsList(_topTracks,
                              isLoading: _isLoadingTop,
                              error: _topError,
                              emptyMsg: "Belum ada data."),
                          const SizedBox(height: 12),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (_currentTrack != null)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _buildMiniPlayer(),
            ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).maybePop(),
            child: Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_cBgCardHi, _cBgCard],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.black.withOpacity(0.85), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 0,
                    offset: const Offset(3, 3),
                  ),
                  BoxShadow(
                    color: _cRed.withOpacity(0.18),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: Colors.white, size: 22),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_cRedDark, _cRed],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.black.withOpacity(0.85), width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.7),
                  blurRadius: 0,
                  offset: const Offset(3, 3),
                ),
                BoxShadow(color: _cRed.withOpacity(0.65), blurRadius: 14),
                BoxShadow(color: _cRed.withOpacity(0.35), blurRadius: 24),
              ],
            ),
            child: const Icon(Icons.music_note_rounded,
                color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "MUSIC",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: _font,
                    letterSpacing: 2.5,
                    shadows: [
                      Shadow(color: Color(0xCC000000), blurRadius: 4, offset: Offset(1, 1)),
                    ],
                  ),
                ),
                Text(
                  "Cari & putar musik favoritmu",
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 11,
                    fontFamily: _font,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _fetchTopTracks,
            child: Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_cBgCardHi, _cBgCard],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _cRed.withOpacity(0.6), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 0,
                    offset: const Offset(3, 3),
                  ),
                  BoxShadow(color: _cRed.withOpacity(0.35), blurRadius: 12),
                ],
              ),
              child: const Icon(Icons.refresh_rounded, color: _cRed, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 6, 16, 14),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_cBgCard, _cBg],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _cRed.withOpacity(0.55), width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            blurRadius: 0,
            offset: const Offset(4, 4),
          ),
          BoxShadow(color: _cRed.withOpacity(0.22), blurRadius: 18),
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.search_rounded, color: _cRed, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _searchCtrl,
              focusNode: _searchFocus,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14.5,
                fontFamily: _font,
              ),
              cursorColor: _cRed,
              decoration: const InputDecoration(
                isDense: true,
                border: InputBorder.none,
                hintText: "Cari judul lagu, artis, atau album...",
                hintStyle: TextStyle(
                  color: Colors.white38,
                  fontSize: 13.5,
                  fontFamily: _font,
                ),
              ),
              onChanged: _onSearchChanged,
              onSubmitted: (value) {
                _debounce?.cancel();
                _searchMusic(value);
              },
              textInputAction: TextInputAction.search,
            ),
          ),
          if (_searchCtrl.text.isNotEmpty)
            GestureDetector(
              onTap: () {
                _searchCtrl.clear();
                _onSearchChanged('');
              },
              child: const Padding(
                padding: EdgeInsets.all(6),
                child: Icon(Icons.close_rounded,
                    color: Colors.white60, size: 18),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader({
    required IconData icon,
    required String title,
    required int count,
    Color iconColor = _cRed,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  iconColor.withOpacity(0.35),
                  iconColor.withOpacity(0.15),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(
                color: Colors.black.withOpacity(0.7),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 0,
                  offset: const Offset(2, 2),
                ),
                BoxShadow(
                  color: iconColor.withOpacity(0.4),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Icon(icon, color: iconColor, size: 16),
          ),
          const SizedBox(width: 10),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w900,
              fontFamily: _font,
              letterSpacing: 1.6,
              shadows: [
                Shadow(color: Color(0xCC000000), blurRadius: 3, offset: Offset(1, 1)),
              ],
            ),
          ),
          const Spacer(),
          if (count > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_cRedDark, _cRed],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Colors.black.withOpacity(0.75),
                  width: 1.8,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    blurRadius: 0,
                    offset: const Offset(2, 2),
                  ),
                  BoxShadow(color: _cRed.withOpacity(0.5), blurRadius: 10),
                ],
              ),
              child: Text(
                "$count",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: _font,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildResultsList(
    List<_Track> tracks, {
    required bool isLoading,
    String? error,
    String emptyMsg = "Tidak ada data.",
  }) {
    if (isLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: Column(
            children: [
              SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation(_cRed),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                "Memuat...",
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 12,
                  fontFamily: _font,
                ),
              ),
            ],
          ),
        ),
      );
    }
    if (error != null) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.red.withOpacity(0.15),
                Colors.red.withOpacity(0.05),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.red.withOpacity(0.55), width: 2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 0,
                offset: const Offset(3, 3),
              ),
              BoxShadow(
                color: Colors.red.withOpacity(0.3),
                blurRadius: 12,
              ),
            ],
          ),
          child: Row(
            children: [
              const Icon(Icons.error_outline_rounded,
                  color: Colors.redAccent, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  error,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12.5,
                    fontFamily: _font,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }
    if (tracks.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 16),
        child: Center(
          child: Text(
            emptyMsg,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 13,
              fontFamily: _font,
            ),
          ),
        ),
      );
    }
    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      itemCount: tracks.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) => _buildTrackCard(tracks[i]),
    );
  }

  Widget _buildTrackCard(_Track t) {
    final bool isActive = _currentlyPlayingId == t.id;
    final bool playing = isActive && _isPlaying;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isActive
              ? [_cRedDark.withOpacity(0.65), _cBgCard, _cBg]
              : [_cBgCardHi, _cBgCard, _cBg],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isActive
              ? _cRed.withOpacity(0.85)
              : Colors.black.withOpacity(0.75),
          width: isActive ? 2.4 : 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            blurRadius: 0,
            offset: const Offset(4, 4),
          ),
          BoxShadow(
            color: isActive
                ? _cRed.withOpacity(0.45)
                : Colors.black.withOpacity(0.5),
            blurRadius: isActive ? 22 : 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _togglePlay(t),
            splashColor: _cRed.withOpacity(0.2),
            highlightColor: _cRed.withOpacity(0.05),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.black.withOpacity(0.8),
                            width: 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.7),
                              blurRadius: 0,
                              offset: const Offset(2, 2),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: t.thumbnail.isEmpty
                              ? Container(
                                  width: 64,
                                  height: 64,
                                  color: _cBgSidebar,
                                  child: const Icon(Icons.music_note_rounded,
                                      color: Colors.white24, size: 28),
                                )
                              : Image.network(
                                  t.thumbnail,
                                  width: 64,
                                  height: 64,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    width: 64,
                                    height: 64,
                                    color: _cBgSidebar,
                                    child: const Icon(
                                        Icons.broken_image_rounded,
                                        color: Colors.white24,
                                        size: 28),
                                  ),
                                ),
                        ),
                      ),
                      if (isActive)
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.black.withOpacity(0.5),
                            ),
                            alignment: Alignment.center,
                            child: Icon(
                              playing
                                  ? Icons.equalizer_rounded
                                  : Icons.pause_rounded,
                              color: _cRed,
                              size: 26,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: isActive ? _cRed : Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            fontFamily: _font,
                            shadows: const [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 3,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          t.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontFamily: _font,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            const Icon(Icons.access_time_rounded,
                                color: Colors.white38, size: 11),
                            const SizedBox(width: 3),
                            Text(
                              _fmtDuration(t.duration),
                              style: const TextStyle(
                                color: Colors.white54,
                                fontSize: 10.5,
                                fontFamily: _font,
                              ),
                            ),
                            if (t.album.isNotEmpty) ...[
                              const SizedBox(width: 8),
                              Container(
                                  width: 3,
                                  height: 3,
                                  decoration: const BoxDecoration(
                                      color: Colors.white24,
                                      shape: BoxShape.circle)),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  t.album,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white54,
                                    fontSize: 10.5,
                                    fontFamily: _font,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () => _togglePlay(t),
                    child: Container(
                      width: 46,
                      height: 46,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [_cRed, _cRedDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(
                          color: Colors.black.withOpacity(0.85),
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.75),
                            blurRadius: 0,
                            offset: const Offset(3, 3),
                          ),
                          BoxShadow(
                              color: _cRed.withOpacity(0.7),
                              blurRadius: 14,
                              spreadRadius: 1),
                          BoxShadow(
                              color: _cRed.withOpacity(0.35),
                              blurRadius: 24),
                        ],
                      ),
                      child: Icon(
                        playing
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMiniPlayer() {
    final t = _currentTrack!;
    final pos = _currentPosition.inMilliseconds.toDouble();
    final dur = _currentDuration.inMilliseconds <= 0
        ? 1.0
        : _currentDuration.inMilliseconds.toDouble();
    final progress = (pos / dur).clamp(0.0, 1.0);

    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_cBgCardHi, _cBgSidebar, _cBg],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            border: Border(
              top: BorderSide(color: _cRed.withOpacity(0.65), width: 2),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                blurRadius: 0,
                offset: const Offset(0, -3),
              ),
              BoxShadow(color: _cRed.withOpacity(0.30), blurRadius: 22),
              BoxShadow(color: Colors.black.withOpacity(0.7), blurRadius: 18),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Colors.black.withOpacity(0.85),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _cRed.withOpacity(0.5),
                          blurRadius: 10,
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          blurRadius: 0,
                          offset: const Offset(2, 2),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: t.thumbnail.isEmpty
                          ? Container(
                              width: 44,
                              height: 44,
                              color: _cBgCard,
                              child: const Icon(Icons.music_note,
                                  color: Colors.white24, size: 20))
                          : Image.network(t.thumbnail,
                              width: 44,
                              height: 44,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                  width: 44,
                                  height: 44,
                                  color: _cBgCard,
                                  child: const Icon(Icons.music_note,
                                      color: Colors.white24, size: 20))),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            fontFamily: _font,
                            shadows: [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 3,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 1),
                        Text(
                          t.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white60,
                            fontSize: 11,
                            fontFamily: _font,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.skip_previous_rounded,
                        color: Colors.white70, size: 28),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: _playPrevAuto,
                  ),
                  const SizedBox(width: 4),
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.black.withOpacity(0.85),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _cRed.withOpacity(0.6),
                          blurRadius: 14,
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          blurRadius: 0,
                          offset: const Offset(2, 2),
                        ),
                      ],
                    ),
                    child: IconButton(
                      icon: Icon(
                        _isPlaying
                            ? Icons.pause_circle_filled_rounded
                            : Icons.play_circle_filled_rounded,
                        color: _cRed,
                        size: 34,
                      ),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () => _togglePlay(t),
                    ),
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    icon: const Icon(Icons.skip_next_rounded,
                        color: Colors.white70, size: 28),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: _playNextAuto,
                  ),
                  const SizedBox(width: 6),
                  IconButton(
                    icon: const Icon(Icons.close_rounded,
                        color: Colors.white60, size: 22),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: _stopPlayer,
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: Colors.black.withOpacity(0.7),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 0,
                      offset: const Offset(1, 1),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 4,
                    backgroundColor: Colors.white12,
                    valueColor: AlwaysStoppedAnimation(_cRed),
                  ),
                ),
              ),
              const SizedBox(height: 5),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _fmtMs(_currentPosition),
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 10,
                      fontFamily: _font,
                    ),
                  ),
                  Text(
                    _fmtMs(_currentDuration),
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 10,
                      fontFamily: _font,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _fmtDuration(int seconds) {
    if (seconds <= 0) return "--:--";
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return "$m:${s.toString().padLeft(2, '0')}";
  }

  String _fmtMs(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return "$m:${s.toString().padLeft(2, '0')}";
  }
}

class _Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String thumbnail;
  final String previewUrl;
  final int duration;
  final int rank;

  _Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.thumbnail,
    required this.previewUrl,
    required this.duration,
    required this.rank,
  });

  factory _Track.fromDeezer(Map<String, dynamic> json) {
    final artistMap = json['artist'];
    final albumMap = json['album'];
    String thumb = '';
    if (albumMap is Map) {
      thumb = (albumMap['cover_xl'] ??
              albumMap['cover_big'] ??
              albumMap['cover_medium'] ??
              albumMap['cover'] ??
              '')
          .toString();
    }
    return _Track(
      id: (json['id'] ?? '').toString(),
      title: (json['title_short'] ?? json['title'] ?? '').toString(),
      artist: (artistMap is Map ? (artistMap['name'] ?? '') : '').toString(),
      album: (albumMap is Map ? (albumMap['title'] ?? '') : '').toString(),
      thumbnail: thumb,
      previewUrl: (json['preview'] ?? '').toString(),
      duration: (json['duration'] is int)
          ? json['duration'] as int
          : int.tryParse((json['duration'] ?? '0').toString()) ?? 0,
      rank: (json['rank'] is int)
          ? json['rank'] as int
          : int.tryParse((json['rank'] ?? '0').toString()) ?? 0,
    );
  }
}

class _MusicHexPattern extends StatelessWidget {
  final double size;
  final Color color;
  const _MusicHexPattern({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _MusicHexPainter(color: color)),
    );
  }
}

class _MusicHexPainter extends CustomPainter {
  final Color color;
  _MusicHexPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    const double r = 16;
    final double w = math.sqrt(3) * r;
    final double h = 2 * r;
    final double vert = h * 3 / 4;

    for (double y = -h; y < size.height + h; y += vert) {
      bool offset = ((y / vert).round() % 2) == 1;
      for (double x = -w; x < size.width + w; x += w) {
        final double cx = x + (offset ? w / 2 : 0);
        _drawHex(canvas, Offset(cx, y), r, paint);
      }
    }
  }

  void _drawHex(Canvas canvas, Offset c, double r, Paint paint) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final a = (math.pi / 3) * i + math.pi / 6;
      final p = Offset(c.dx + r * math.cos(a), c.dy + r * math.sin(a));
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}