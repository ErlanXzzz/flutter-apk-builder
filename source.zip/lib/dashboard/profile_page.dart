import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/services.dart';
import 'change_password_page.dart';

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String? uid;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    this.uid,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 WARNA 3D MERAH KECOKLATAN (sama kayak Tools & Info)
  // ═══════════════════════════════════════════════════════════════════
  static const Color _bgCream      = Color(0xFFF5E6D3);
  static const Color _bgCreamLight = Color(0xFFFFF8F0);
  static const Color _redMain      = Color(0xFFB71C1C);
  static const Color _redDark      = Color(0xFF7F0000);
  static const Color _redDeep      = Color(0xFF4A0000);
  static const Color _brownDark    = Color(0xFF2B0E0E);
  static const Color _brownMid     = Color(0xFF5D2B1F);
  static const Color _gold         = Color(0xFFD4A853);
  static const Color _textDark     = Color(0xFF1A0A0A);
  static const Color _borderDark   = Color(0xFF1A0505);
  static const Color _white        = Colors.white;
  static const Color _highlight    = Color(0xFFFFF0D8);   // highlight cream

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    _loadProfileImage();
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: _bgCreamLight,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: _borderDark, width: 3),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: _brownMid.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "GANTI FOTO PROFIL",
                style: TextStyle(
                  color: _redDark,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 20),
              _buildSheetOption(
                icon: Icons.camera_alt_rounded,
                title: "KAMERA",
                subtitle: "Ambil foto sekarang",
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              const SizedBox(height: 10),
              _buildSheetOption(
                icon: Icons.photo_library_rounded,
                title: "GALERI",
                subtitle: "Pilih dari galeri",
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSheetOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_bgCream, _bgCreamLight],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _borderDark, width: 2.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(3, 3),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_redMain, _redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(icon, color: _white, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: _redDark,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: _brownMid.withOpacity(0.9),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios_rounded,
                color: _redDark,
                size: 14,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
            'profile_image_${widget.username}', imageFile.path);
        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 ROLE BADGE 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildRoleBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_redMain, _redDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: _gold,
              shape: BoxShape.circle,
              border: Border.all(color: _borderDark, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: _gold.withOpacity(0.8),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            widget.role.toUpperCase(),
            style: const TextStyle(
              color: _white,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
              shadows: [
                Shadow(
                  color: Color(0xCC000000),
                  blurRadius: 3,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 INFO CARD 3D — Extra HD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInfoCard({
    required IconData icon,
    required String label,
    required String value,
    bool fullWidth = false,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: fullWidth ? 16 : 14,
        vertical: 14,
      ),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_bgCreamLight, _bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _borderDark, width: 2.5),
        boxShadow: const [
          // Solid shadow (efek 3D utama)
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          // Blur shadow (depth)
          BoxShadow(
            color: Color(0x77000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Icon 3D
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_redMain, _redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: Icon(icon, color: _white, size: 14),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: _redDark,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _bgCream,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: _brownMid.withOpacity(0.3),
                width: 1.5,
              ),
            ),
            child: Text(
              value,
              style: const TextStyle(
                color: _textDark,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.5,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 CHANGE PASSWORD BUTTON 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildChangePasswordButton() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return Container(
          width: double.infinity,
          height: 58,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_redMain, _redDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _borderDark, width: 3),
            boxShadow: [
              // Solid 3D shadow
              const BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
              // Glow depth
              BoxShadow(
                color: _redMain.withOpacity(_glowAnimation.value * 0.4),
                blurRadius: 25,
                spreadRadius: 2,
              ),
              // Blur depth
              const BoxShadow(
                color: Color(0x77000000),
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(
                      username: widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                );
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      shape: BoxShape.circle,
                      border: Border.all(color: _borderDark, width: 1.5),
                    ),
                    child: const Icon(
                      Icons.lock_reset_rounded,
                      color: _gold,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Text(
                    "CHANGE PASSWORD",
                    style: TextStyle(
                      color: _white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 4,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 UID CARD 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildUidCard() {
    final String uid = widget.uid ?? 'Tidak ada UID';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_bgCreamLight, _bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
          BoxShadow(
            color: Color(0x77000000),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [_redMain, _redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xAA000000),
                      blurRadius: 0,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.badge_rounded,
                  color: _white,
                  size: 14,
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  "UID / ID",
                  style: TextStyle(
                    color: _redDark,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              // Tombol salin 3D
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: uid));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('✅ UID berhasil disalin!'),
                      duration: const Duration(seconds: 2),
                      backgroundColor: _redMain,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: const BorderSide(
                          color: _borderDark,
                          width: 2,
                        ),
                      ),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_redMain, _redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _borderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.copy_rounded, color: _white, size: 12),
                      SizedBox(width: 4),
                      Text(
                        "SALIN",
                        style: TextStyle(
                          color: _white,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: _bgCream,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: _brownMid.withOpacity(0.3),
                width: 1.5,
              ),
            ),
            child: Text(
              uid,
              style: const TextStyle(
                color: _redDark,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.5,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _brownDark,
      appBar: AppBar(
        backgroundColor: _brownDark,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_redMain, _redDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _borderDark, width: 2),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: const Icon(
                Icons.arrow_back_ios_new,
                color: _white,
                size: 16,
              ),
            ),
          ),
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(
              horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_redMain, _redDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _borderDark, width: 2.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xCC000000),
                blurRadius: 0,
                offset: Offset(3, 3),
              ),
              BoxShadow(
                color: Color(0x66000000),
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: const Text(
            "MY PROFILE",
            style: TextStyle(
              color: _white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 13,
              letterSpacing: 2,
              shadows: [
                Shadow(
                  color: Color(0xCC000000),
                  blurRadius: 3,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          children: [
            const SizedBox(height: 8),

            // ═══════════════════════════════════════════════════════════
            // AVATAR 3D dengan glow
            // ═══════════════════════════════════════════════════════════
            Center(
              child: GestureDetector(
                onTap: _showImageSourceDialog,
                child: Stack(
                  children: [
                    AnimatedBuilder(
                      animation: _glowAnimation,
                      builder: (context, _) {
                        return Container(
                          width: 120,
                          height: 120,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [_redMain, _redDark],
                            ),
                            border: Border.all(color: _borderDark, width: 3.5),
                            boxShadow: [
                              // Solid 3D shadow
                              const BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(4, 4),
                              ),
                              // Red glow
                              BoxShadow(
                                color: _redMain.withOpacity(
                                    _glowAnimation.value * 0.5),
                                blurRadius: 30,
                                spreadRadius: 4,
                              ),
                              // Blur depth
                              const BoxShadow(
                                color: Color(0x88000000),
                                blurRadius: 18,
                                offset: Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(4),
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _bgCream,
                                border: Border.all(
                                  color: _borderDark,
                                  width: 2,
                                ),
                              ),
                              child: ClipOval(
                                child: _profileImage != null
                                    ? Image.file(
                                        _profileImage!,
                                        fit: BoxFit.cover,
                                      )
                                    : Center(
                                        child: Icon(
                                          FontAwesomeIcons.userAstronaut,
                                          size: 44,
                                          color: _redDark.withOpacity(0.5),
                                        ),
                                      ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    // Kamera badge 3D
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [_gold, Color(0xFFB8923A)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          shape: BoxShape.circle,
                          border: Border.all(color: _borderDark, width: 2.5),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(2, 2),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.camera_alt_rounded,
                          size: 16,
                          color: _textDark,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 22),

            // ═══════════════════════════════════════════════════════════
            // USERNAME 3D
            // ═══════════════════════════════════════════════════════════
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_bgCreamLight, _bgCream],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _borderDark, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(3, 3),
                  ),
                  BoxShadow(
                    color: Color(0x66000000),
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Text(
                widget.username,
                style: const TextStyle(
                  color: _redDark,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                  shadows: [
                    Shadow(
                      color: Color(0x33000000),
                      blurRadius: 3,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 14),

            // ═══════════════════════════════════════════════════════════
            // ROLE BADGE
            // ═══════════════════════════════════════════════════════════
            _buildRoleBadge(),

            const SizedBox(height: 32),

            // ═══════════════════════════════════════════════════════════
            // SECTION TITLE 3D
            // ═══════════════════════════════════════════════════════════
            _buildSectionTitle("ACCOUNT DATA"),

            const SizedBox(height: 14),

            // ROW 1: Username + Password
            Row(
              children: [
                Expanded(
                  child: _buildInfoCard(
                    icon: Icons.person_outline,
                    label: "USERNAME",
                    value: _censorText(widget.username),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildInfoCard(
                    icon: Icons.lock_outline,
                    label: "PASSWORD",
                    value: _censorText(widget.password, isPassword: true),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // ROW 2: Role + Expired
            Row(
              children: [
                Expanded(
                  child: _buildInfoCard(
                    icon: Icons.verified_user_outlined,
                    label: "ROLE",
                    value: widget.role.toUpperCase(),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildInfoCard(
                    icon: Icons.calendar_today_outlined,
                    label: "EXPIRED",
                    value: widget.expiredDate,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // ROW 3: Session Key
            _buildInfoCard(
              icon: Icons.vpn_key_rounded,
              label: "SESSION KEY",
              value: widget.sessionKey.length > 8
                  ? "${widget.sessionKey.substring(0, 8)}..."
                  : widget.sessionKey,
              fullWidth: true,
            ),

            const SizedBox(height: 12),

            // ROW 4: UID
            _buildUidCard(),

            const SizedBox(height: 40),

            // ═══════════════════════════════════════════════════════════
            // CHANGE PASSWORD BUTTON
            // ═══════════════════════════════════════════════════════════
            _buildChangePasswordButton(),

            const SizedBox(height: 32),

            // ═══════════════════════════════════════════════════════════
            // FOOTER
            // ═══════════════════════════════════════════════════════════
            _buildFooter(),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // SECTION TITLE 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildSectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 5,
          height: 18,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_redMain, _redDark],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(3),
            border: Border.all(color: _borderDark, width: 1.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0xAA000000),
                blurRadius: 0,
                offset: Offset(2, 2),
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: const TextStyle(
            color: _gold,
            fontSize: 11,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
            fontFamily: 'Orbitron',
            shadows: [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 4,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // FOOTER 3D
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          height: 2,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.transparent,
                _redMain.withOpacity(0.5),
                Colors.transparent,
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 30,
              height: 2,
              decoration: BoxDecoration(
                color: _redMain.withOpacity(0.5),
                borderRadius: BorderRadius.circular(1),
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: _gold,
                shape: BoxShape.circle,
                border: Border.all(color: _borderDark, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: _gold.withOpacity(0.6),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 30,
              height: 2,
              decoration: BoxDecoration(
                color: _redMain.withOpacity(0.5),
                borderRadius: BorderRadius.circular(1),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          "ERLAN SOFSPOKEN",
          style: TextStyle(
            color: _gold,
            fontSize: 10,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 3,
            shadows: [
              Shadow(
                color: Color(0xCC000000),
                blurRadius: 4,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          "vLatest  ·  © 2026",
          style: TextStyle(
            color: _bgCream.withOpacity(0.4),
            fontSize: 9,
            fontWeight: FontWeight.w600,
            fontFamily: 'ShareTechMono',
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }
}