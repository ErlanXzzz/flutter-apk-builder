import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../sistem/apiBaseUrl.dart';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with TickerProviderStateMixin {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late PageController _pageController;
  int _currentPage = 0;

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 3D HD RED-BROWN PALETTE
  // ═══════════════════════════════════════════════════════════════════
  static const Color primaryDark = Color(0xFF160A07);
  static const Color deepBlack = Color(0xFF1B0B07);
  static const Color darkCharcoal = Color(0xFF2A140E);
  static const Color warmSlate = Color(0xFF3A1E15);
  static const Color rustDeep = Color(0xFF6B2A1A);
  static const Color rustRed = Color(0xFF9C3B22);
  static const Color rustBright = Color(0xFFC4512C);
  static const Color copperGlow = Color(0xFFE0763F);
  static const Color bronze = Color(0xFFC9913F);
  static const Color goldAccent = Color(0xFFD9A441);
  static const Color platinum = Color(0xFFF3E6DD);
  static const Color successGreen = Color(0xFF35C77A);
  static const Color errorRed = Color(0xFFE7473A);

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.4, end: 0.7).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _pageController = PageController(
      viewportFraction: 0.88,
      initialPage: 0,
    );

    _fetchSenders();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🧊 3D BEVEL BOX (helper kedalaman)
  // ═══════════════════════════════════════════════════════════════════
  Widget _bevelBox({
    required Widget child,
    double radius = 20,
    double borderWidth = 1.4,
    Color? glowColor,
    double glowOpacity = 0.28,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        // Bevel 3D: highlight kiri-atas → gelap kanan-bawah
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0x66F3E6DD),
            Color(0x33C4512C),
            Color(0xBB000000),
          ],
          stops: [0.0, 0.5, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.70),
            blurRadius: 28,
            spreadRadius: -6,
            offset: const Offset(0, 16),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.45),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
          BoxShadow(
            color: (glowColor ?? rustBright).withOpacity(glowOpacity),
            blurRadius: 36,
            spreadRadius: -8,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      padding: EdgeInsets.all(borderWidth),
      child: child,
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // FETCH SENDERS
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http.get(
        Uri.parse("$apiBaseUrl/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          if (mounted) {
            setState(() {
              senderList = data["connections"] ?? [];
            });
          }
        } else {
          if (mounted) {
            setState(() =>
                errorMessage = data["message"] ?? "Failed to fetch senders");
          }
        }
      } else {
        if (mounted) {
          setState(
              () => errorMessage = "Server error: ${response.statusCode}");
        }
      }
    } catch (e) {
      if (mounted) setState(() => errorMessage = "Connection failed: $e");
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
          isRefreshing = false;
        });
      }
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  // ═══════════════════════════════════════════════════════════════════
  // BACKGROUND (deep rust glow + geometric pattern)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildMinimalistBackground() {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(-0.5, -0.8),
          radius: 1.4,
          colors: [
            Color(0xFF43170C),
            Color(0xFF1E0A05),
            Color(0xFF0A0302),
          ],
          stops: [0.0, 0.55, 1.0],
        ),
      ),
      child: Stack(
        children: [
          // Glow bawah kanan (copper)
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(0.7, 1.0),
                radius: 1.0,
                colors: [
                  copperGlow.withOpacity(0.18),
                  Colors.transparent,
                ],
              ),
            ),
          ),
          // Glow atas (rust)
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.8, -1.1),
                radius: 0.9,
                colors: [
                  rustRed.withOpacity(0.22),
                  Colors.transparent,
                ],
              ),
            ),
          ),
          CustomPaint(
            painter: _GeometricPatternPainter(
              color: copperGlow.withOpacity(0.045),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildElegantHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            primaryDark.withOpacity(0.85),
            Colors.transparent,
          ],
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Back button 3D
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF4A2016),
                        Color(0xFF1E0B06),
                      ],
                    ),
                    border: Border.all(
                      color: platinum.withOpacity(0.15),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                      BoxShadow(
                        color: rustBright.withOpacity(0.25),
                        blurRadius: 16,
                        spreadRadius: -4,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: platinum,
                    size: 18,
                  ),
                ),
              ),
              const SizedBox(width: 16),

              // Title
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "SENDER NODES",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: platinum,
                        letterSpacing: 2,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(
                            color: Color(0xAAE0763F),
                            blurRadius: 12,
                            offset: Offset(0, 1),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Device Management System",
                      style: TextStyle(
                        color: copperGlow.withOpacity(0.75),
                        fontSize: 11,
                        fontWeight: FontWeight.w300,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),

              // Sync button 3D
              GestureDetector(
                onTap: isLoading ? null : _refreshSenders,
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF4A2016),
                        Color(0xFF1E0B06),
                      ],
                    ),
                    border: Border.all(
                      color: rustBright.withOpacity(0.35),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                      BoxShadow(
                        color: copperGlow.withOpacity(0.28),
                        blurRadius: 18,
                        spreadRadius: -4,
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.sync_rounded,
                    color: isLoading ? platinum.withOpacity(0.4) : platinum,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Active counter
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFF3A1A0F),
                      Color(0xFF1E0B06),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: copperGlow.withOpacity(0.3),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                    BoxShadow(
                      color: successGreen.withOpacity(0.12),
                      blurRadius: 14,
                      spreadRadius: -3,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: successGreen,
                        boxShadow: [
                          BoxShadow(
                            color: successGreen,
                            blurRadius: 8,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "${senderList.length} ACTIVE NODES",
                      style: TextStyle(
                        color: platinum.withOpacity(0.95),
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Divider
          Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  copperGlow.withOpacity(0.35),
                  Colors.transparent,
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: copperGlow.withOpacity(0.25),
                  blurRadius: 6,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // CAROUSEL
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildCarouselSenderCards() {
    if (senderList.isEmpty) return _buildEmptyState();

    return Column(
      children: [
        SizedBox(
          height: 320,
          child: PageView.builder(
            controller: _pageController,
            itemCount: senderList.length,
            onPageChanged: (index) {
              setState(() => _currentPage = index);
            },
            itemBuilder: (context, index) {
              final sender = Map<String, dynamic>.from(senderList[index]);
              return _buildElegantSenderCard(sender, index);
            },
          ),
        ),
        const SizedBox(height: 24),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(senderList.length, (index) {
            final isActive = index == _currentPage;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isActive ? 26 : 6,
              height: 5,
              decoration: BoxDecoration(
                gradient: isActive
                    ? const LinearGradient(
                        colors: [rustBright, copperGlow],
                      )
                    : null,
                color: isActive ? null : platinum.withOpacity(0.18),
                borderRadius: BorderRadius.circular(3),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                          color: copperGlow.withOpacity(0.6),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ]
                    : null,
              ),
            );
          }),
        ),
        const SizedBox(height: 32),
      ],
    );
  }

  Widget _buildElegantSenderCard(Map<String, dynamic> sender, int index) {
    final name = sender['sessionName'] ?? 'Unnamed Sender';
    final phone = sender['id']?.split(':')[0]?.split('@')[0] ?? 'Unknown';
    final isActive = index == _currentPage;

    return AnimatedBuilder(
      animation: _pageController,
      builder: (context, child) {
        double scale = 1.0;
        double opacity = 1.0;
        if (_pageController.position.haveDimensions) {
          final value = (_pageController.page ?? 0) - index;
          scale = (1 - (value.abs() * 0.15)).clamp(0.85, 1.0);
          opacity = (1 - (value.abs() * 0.3)).clamp(0.7, 1.0);
        }

        return Transform.scale(
          scale: scale,
          child: Opacity(
            opacity: opacity,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
              child: _bevelBox(
                radius: 22,
                glowColor: isActive ? copperGlow : rustDeep,
                glowOpacity: isActive ? 0.35 : 0.15,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(21),
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF3A1A0F),
                        Color(0xFF2A140E),
                        Color(0xFF170805),
                      ],
                      stops: [0.0, 0.5, 1.0],
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Header
                        Row(
                          children: [
                            // Avatar 3D
                            Container(
                              width: 52,
                              height: 52,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    copperGlow,
                                    rustRed,
                                    Color(0xFF4A1A0C),
                                  ],
                                  stops: [0.0, 0.5, 1.0],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.7),
                                    blurRadius: 12,
                                    offset: const Offset(0, 6),
                                  ),
                                  BoxShadow(
                                    color: copperGlow.withOpacity(0.45),
                                    blurRadius: 20,
                                    spreadRadius: -4,
                                  ),
                                ],
                                border: Border.all(
                                  color: platinum.withOpacity(0.25),
                                  width: 1,
                                ),
                              ),
                              child: const Center(
                                child: Icon(
                                  Icons.phone_android_rounded,
                                  color: platinum,
                                  size: 22,
                                ),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    name.toUpperCase(),
                                    style: const TextStyle(
                                      color: platinum,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 0.8,
                                      shadows: [
                                        Shadow(
                                          color: Color(0x88E0763F),
                                          blurRadius: 10,
                                        ),
                                      ],
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    phone,
                                    style: TextStyle(
                                      color: copperGlow.withOpacity(0.75),
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: successGreen.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: successGreen.withOpacity(0.3),
                                  width: 1,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: successGreen.withOpacity(0.25),
                                    blurRadius: 12,
                                    spreadRadius: -3,
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 5,
                                    height: 5,
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: successGreen,
                                      boxShadow: [
                                        BoxShadow(
                                          color: successGreen,
                                          blurRadius: 6,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 5),
                                  const Text(
                                    "ONLINE",
                                    style: TextStyle(
                                      color: successGreen,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 22),
                        Container(
                          height: 1,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                copperGlow.withOpacity(0.35),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 22),

                        // Actions
                        Row(
                          children: [
                            Expanded(
                              child: _buildActionButton(
                                onTap: () => _refreshSenders(),
                                icon: Icons.refresh_rounded,
                                label: "REFRESH",
                                color: platinum,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildActionButton(
                                onTap: () => _deleteSender(sender['id']),
                                icon: Icons.delete_outline_rounded,
                                label: "PURGE",
                                color: errorRed,
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 16),

                        // Info
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Color(0xFF331509),
                                Color(0xFF1C0A05),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: goldAccent.withOpacity(0.18),
                              width: 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.5),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.info_outline_rounded,
                                color: goldAccent,
                                size: 14,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  "Connected to WhatsApp Web",
                                  style: TextStyle(
                                    color: platinum.withOpacity(0.75),
                                    fontSize: 11,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildActionButton({
    required VoidCallback onTap,
    required IconData icon,
    required String label,
    required Color color,
  }) {
    final isDanger = color == errorRed;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isDanger
              ? [
                  errorRed.withOpacity(0.28),
                  errorRed.withOpacity(0.08),
                ]
              : [
                  copperGlow.withOpacity(0.22),
                  const Color(0xFF2A120A),
                ],
        ),
        border: Border.all(
          color: isDanger
              ? errorRed.withOpacity(0.35)
              : copperGlow.withOpacity(0.35),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 10,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: (isDanger ? errorRed : copperGlow).withOpacity(0.22),
            blurRadius: 16,
            spreadRadius: -4,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: color, size: 16),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.8,
                    shadows: [
                      Shadow(
                        color: color.withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // EMPTY / ERROR STATE
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icon bulat 3D
            Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF3E1B0F),
                    Color(0xFF1B0805),
                  ],
                ),
                border: Border.all(
                  color: copperGlow.withOpacity(0.25),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 24,
                    offset: const Offset(0, 14),
                  ),
                  BoxShadow(
                    color: copperGlow.withOpacity(0.28),
                    blurRadius: 40,
                    spreadRadius: -8,
                  ),
                ],
              ),
              child: Icon(
                Icons.phone_iphone_rounded,
                color: copperGlow.withOpacity(0.75),
                size: 42,
              ),
            ),
            const SizedBox(height: 32),
            const Text(
              "NO SENDERS",
              style: TextStyle(
                color: platinum,
                fontSize: 22,
                fontWeight: FontWeight.w500,
                letterSpacing: 2,
                shadows: [
                  Shadow(
                    color: Color(0xAAE0763F),
                    blurRadius: 16,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              width: 150,
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    copperGlow.withOpacity(0.6),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: copperGlow.withOpacity(0.4),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _bevelBox(
              radius: 16,
              glowColor: goldAccent,
              glowOpacity: 0.18,
              child: Container(
                width: 280,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFF32150C),
                      Color(0xFF1B0905),
                    ],
                  ),
                ),
                child: Column(
                  children: [
                    const Icon(
                      Icons.add_circle_outline_rounded,
                      color: goldAccent,
                      size: 28,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "Add your first WhatsApp sender\nto start using premium features",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: platinum.withOpacity(0.75),
                        fontSize: 12,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 40),
            _buildPrimaryButton(
              onTap: _showAddSenderDialog,
              icon: Icons.add_rounded,
              label: "ADD FIRST SENDER",
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF40130C),
                    Color(0xFF1A0605),
                  ],
                ),
                border: Border.all(
                  color: errorRed.withOpacity(0.35),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 22,
                    offset: const Offset(0, 12),
                  ),
                  BoxShadow(
                    color: errorRed.withOpacity(0.35),
                    blurRadius: 34,
                    spreadRadius: -8,
                  ),
                ],
              ),
              child: const Icon(
                Icons.error_outline_rounded,
                color: errorRed,
                size: 34,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              "CONNECTION ERROR",
              style: TextStyle(
                color: platinum,
                fontSize: 18,
                fontWeight: FontWeight.w500,
                letterSpacing: 1,
                shadows: [
                  Shadow(color: Color(0xAAE7473A), blurRadius: 14),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _bevelBox(
              radius: 12,
              glowColor: errorRed,
              glowOpacity: 0.22,
              child: Container(
                width: 280,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(11),
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFF2E0F0A),
                      Color(0xFF180604),
                    ],
                  ),
                ),
                child: Text(
                  errorMessage ?? "Unknown error occurred",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: platinum.withOpacity(0.8),
                    fontSize: 12,
                    height: 1.5,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            _buildOutlineButton(
              onTap: _fetchSenders,
              icon: Icons.refresh_rounded,
              label: "RETRY CONNECTION",
              color: copperGlow,
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUTTONS (3D)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPrimaryButton({
    required VoidCallback onTap,
    required IconData icon,
    required String label,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: const LinearGradient(
          colors: [copperGlow, rustBright, rustRed],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: [0.0, 0.45, 1.0],
        ),
        border: Border.all(
          color: platinum.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: copperGlow.withOpacity(0.5),
            blurRadius: 28,
            spreadRadius: -6,
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: platinum, size: 18),
            const SizedBox(width: 12),
            Text(
              label,
              style: const TextStyle(
                color: platinum,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                shadows: [
                  Shadow(color: Color(0xAA000000), blurRadius: 6),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOutlineButton({
    required VoidCallback onTap,
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            color.withOpacity(0.30),
            const Color(0xFF1E0B06),
          ],
        ),
        border: Border.all(color: color.withOpacity(0.45), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: -5,
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 13),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: platinum, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: platinum,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ADD SENDER DIALOG
  // ═══════════════════════════════════════════════════════════════════
  void _showAddSenderDialog() {
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.78),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: _bevelBox(
          radius: 22,
          glowColor: copperGlow,
          glowOpacity: 0.3,
          child: Container(
            width: MediaQuery.of(context).size.width * 0.85,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(21),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF33170D),
                  Color(0xFF1B0905),
                ],
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF4A2013),
                        Color(0xFF2A110A),
                      ],
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(21),
                      topRight: Radius.circular(21),
                    ),
                    border: Border(
                      bottom: BorderSide(
                        color: copperGlow.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [copperGlow, rustRed],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: copperGlow.withOpacity(0.5),
                              blurRadius: 14,
                              spreadRadius: -2,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.add_rounded,
                            color: platinum, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          "ADD NEW SENDER",
                          style: TextStyle(
                            color: platinum,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Content
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Phone Number",
                          style: TextStyle(
                            color: copperGlow.withOpacity(0.85),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),

                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFF1A0805),
                              Color(0xFF2A120A),
                            ],
                          ),
                          border: Border.all(
                            color: copperGlow.withOpacity(0.3),
                            width: 1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.7),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: TextField(
                          controller: phoneController,
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(
                            color: platinum,
                            fontSize: 14,
                          ),
                          decoration: InputDecoration(
                            hintText: "628123456789",
                            hintStyle: TextStyle(
                              color: platinum.withOpacity(0.35),
                            ),
                            prefixIcon: const Icon(
                              Icons.phone_rounded,
                              color: goldAccent,
                              size: 18,
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 14,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),

                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                gradient: const LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Color(0xFF32170D),
                                    Color(0xFF1A0805),
                                  ],
                                ),
                                border: Border.all(
                                  color: platinum.withOpacity(0.15),
                                  width: 1,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.6),
                                    blurRadius: 8,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Material(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(10),
                                child: InkWell(
                                  onTap: () => Navigator.pop(context),
                                  borderRadius: BorderRadius.circular(10),
                                  child: const Padding(
                                    padding:
                                        EdgeInsets.symmetric(vertical: 14),
                                    child: Center(
                                      child: Text(
                                        "CANCEL",
                                        style: TextStyle(
                                          color: platinum,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 0.8,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                gradient: const LinearGradient(
                                  colors: [copperGlow, rustBright, rustRed],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                border: Border.all(
                                  color: platinum.withOpacity(0.25),
                                  width: 1,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.7),
                                    blurRadius: 12,
                                    offset: const Offset(0, 6),
                                  ),
                                  BoxShadow(
                                    color: copperGlow.withOpacity(0.45),
                                    blurRadius: 18,
                                    spreadRadius: -4,
                                  ),
                                ],
                              ),
                              child: ElevatedButton(
                                onPressed: () async {
                                  final number = phoneController.text.trim();
                                  if (number.isEmpty) {
                                    _showSnackBar(
                                      "Please enter phone number",
                                      isError: true,
                                    );
                                    return;
                                  }
                                  Navigator.pop(context);
                                  await _addSender(number);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: const Text(
                                  "GENERATE",
                                  style: TextStyle(
                                    color: platinum,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.8,
                                    shadows: [
                                      Shadow(
                                        color: Color(0xAA000000),
                                        blurRadius: 6,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ADD SENDER API
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _addSender(String number) async {
    setState(() => isLoading = true);
    try {
      final response = await http.get(Uri.parse(
          "$apiBaseUrl/getPairing?key=${widget.sessionKey}&number=$number"));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode'] ?? '');
          _showSnackBar("Pairing sequence generated!", isError: false);
        } else {
          _showSnackBar(data['message'] ?? "Pairing failed", isError: true);
        }
      } else {
        _showSnackBar("Server Error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection Fault: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // PAIRING CODE DIALOG
  // ═══════════════════════════════════════════════════════════════════
  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.78),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: _bevelBox(
          radius: 22,
          glowColor: goldAccent,
          glowOpacity: 0.32,
          child: Container(
            width: MediaQuery.of(context).size.width * 0.85,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(21),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF33170D),
                  Color(0xFF1B0905),
                ],
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF4A2013),
                        Color(0xFF2A110A),
                      ],
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(21),
                      topRight: Radius.circular(21),
                    ),
                    border: Border(
                      bottom: BorderSide(
                        color: goldAccent.withOpacity(0.35),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [goldAccent, rustBright],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: goldAccent.withOpacity(0.55),
                              blurRadius: 16,
                              spreadRadius: -2,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.qr_code_scanner_rounded,
                          color: platinum,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          "PAIRING REQUIRED",
                          style: TextStyle(
                            color: platinum,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Content
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      // Phone info
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          gradient: const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFF2A120A),
                              Color(0xFF1A0805),
                            ],
                          ),
                          border: Border.all(
                            color: copperGlow.withOpacity(0.25),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 8,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.phone_rounded,
                                color: goldAccent, size: 18),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "PHONE NUMBER",
                                    style: TextStyle(
                                      color: copperGlow.withOpacity(0.8),
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    number,
                                    style: const TextStyle(
                                      color: platinum,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Pairing Code
                      Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 24, horizontal: 16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          gradient: const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFF2A120A),
                              Color(0xFF170703),
                            ],
                          ),
                          border: Border.all(
                            color: goldAccent.withOpacity(0.4),
                            width: 1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.7),
                              blurRadius: 14,
                              offset: const Offset(0, 8),
                            ),
                            BoxShadow(
                              color: goldAccent.withOpacity(0.25),
                              blurRadius: 26,
                              spreadRadius: -6,
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            Text(
                              "PAIRING CODE",
                              style: TextStyle(
                                color: copperGlow.withOpacity(0.85),
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 1.5,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              code,
                              style: const TextStyle(
                                color: goldAccent,
                                fontSize: 32,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 4,
                                shadows: [
                                  Shadow(
                                    color: Color(0xCCE0763F),
                                    blurRadius: 18,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Copy button
                      SizedBox(
                        width: double.infinity,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                copperGlow.withOpacity(0.35),
                                const Color(0xFF1E0B06),
                              ],
                            ),
                            border: Border.all(
                              color: copperGlow.withOpacity(0.5),
                              width: 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.6),
                                blurRadius: 10,
                                offset: const Offset(0, 5),
                              ),
                              BoxShadow(
                                color: copperGlow.withOpacity(0.3),
                                blurRadius: 18,
                                spreadRadius: -4,
                              ),
                            ],
                          ),
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.copy_all,
                                color: platinum, size: 16),
                            label: const Text(
                              "COPY TO CLIPBOARD",
                              style: TextStyle(
                                color: platinum,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.8,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            onPressed: () async {
                              await Clipboard.setData(
                                  ClipboardData(text: code));
                              _showSnackBar("Copied to clipboard!",
                                  isError: false);
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Footer
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF2A110A),
                        Color(0xFF170703),
                      ],
                    ),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(21),
                      bottomRight: Radius.circular(21),
                    ),
                    border: Border(
                      top: BorderSide(
                        color: copperGlow.withOpacity(0.25),
                        width: 1,
                      ),
                    ),
                  ),
                  child: SizedBox(
                    width: double.infinity,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF3A1A0F),
                            Color(0xFF1E0B06),
                          ],
                        ),
                        border: Border.all(
                          color: platinum.withOpacity(0.15),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.6),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Material(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                        child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                            _fetchSenders();
                          },
                          borderRadius: BorderRadius.circular(10),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Center(
                              child: Text(
                                "CLOSE & REFRESH",
                                style: TextStyle(
                                  color: platinum,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // DELETE SENDER
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _deleteSender(String senderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _bevelBox(
          radius: 18,
          glowColor: errorRed,
          glowOpacity: 0.32,
          child: Container(
            width: MediaQuery.of(context).size.width * 0.75,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF33120C),
                  Color(0xFF180604),
                ],
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF4A150D),
                        Color(0xFF2A0A07),
                      ],
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(17),
                      topRight: Radius.circular(17),
                    ),
                    border: Border(
                      bottom: BorderSide(
                        color: errorRed.withOpacity(0.35),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [errorRed, Color(0xFF7A1A12)],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: errorRed.withOpacity(0.55),
                              blurRadius: 14,
                              spreadRadius: -2,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.warning_amber_rounded,
                            color: platinum, size: 18),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          "CONFIRM DELETE",
                          style: TextStyle(
                            color: platinum,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text(
                        "Are you sure you want to delete this sender?\nThis action cannot be undone.",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: platinum.withOpacity(0.85),
                          fontSize: 12,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                gradient: const LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Color(0xFF32170D),
                                    Color(0xFF1A0805),
                                  ],
                                ),
                                border: Border.all(
                                  color: platinum.withOpacity(0.15),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.6),
                                    blurRadius: 8,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Material(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(10),
                                child: InkWell(
                                  onTap: () => Navigator.pop(context, false),
                                  borderRadius: BorderRadius.circular(10),
                                  child: const Padding(
                                    padding:
                                        EdgeInsets.symmetric(vertical: 12),
                                    child: Center(
                                      child: Text(
                                        "CANCEL",
                                        style: TextStyle(
                                          color: platinum,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    errorRed.withOpacity(0.55),
                                    const Color(0xFF5E0F08),
                                  ],
                                ),
                                border: Border.all(
                                  color: errorRed.withOpacity(0.6),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.7),
                                    blurRadius: 12,
                                    offset: const Offset(0, 6),
                                  ),
                                  BoxShadow(
                                    color: errorRed.withOpacity(0.4),
                                    blurRadius: 20,
                                    spreadRadius: -5,
                                  ),
                                ],
                              ),
                              child: ElevatedButton(
                                onPressed: () => Navigator.pop(context, true),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: const Text(
                                  "DELETE",
                                  style: TextStyle(
                                    color: platinum,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);
      try {
        final response = await http.delete(Uri.parse(
            "$apiBaseUrl/deleteSender?key=${widget.sessionKey}&id=$senderId"));
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Node purged successfully.", isError: false);
            _fetchSenders();
          } else {
            _showSnackBar(data["message"] ?? "Failed to purge node",
                isError: true);
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}",
              isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        if (mounted) setState(() => isLoading = false);
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // SNACKBAR
  // ═══════════════════════════════════════════════════════════════════
  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isError
                  ? [
                      errorRed.withOpacity(0.95),
                      const Color(0xFF7A1A12),
                    ]
                  : [
                      successGreen.withOpacity(0.95),
                      const Color(0xFF186B42),
                    ],
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: platinum.withOpacity(0.25),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Icon(
                isError
                    ? Icons.error_outline_rounded
                    : Icons.check_circle_rounded,
                color: platinum,
                size: 16,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  message,
                  style: const TextStyle(
                    color: platinum,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: Stack(
        children: [
          _buildMinimalistBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildElegantHeader(),
                Expanded(
                  child: isLoading && senderList.isEmpty
                      ? Center(
                          child: Container(
                            width: 56,
                            height: 56,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Color(0xFF3E1B0F),
                                  Color(0xFF1B0805),
                                ],
                              ),
                              border: Border.all(
                                color: copperGlow.withOpacity(0.35),
                                width: 1,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.7),
                                  blurRadius: 18,
                                  offset: const Offset(0, 10),
                                ),
                                BoxShadow(
                                  color: copperGlow.withOpacity(0.35),
                                  blurRadius: 28,
                                  spreadRadius: -6,
                                ),
                              ],
                            ),
                            child: const Padding(
                              padding: EdgeInsets.all(14),
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor:
                                    AlwaysStoppedAnimation(copperGlow),
                              ),
                            ),
                          ),
                        )
                      : errorMessage != null && senderList.isEmpty
                          ? _buildErrorState()
                          : _buildCarouselSenderCards(),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [copperGlow, rustBright, rustRed],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            stops: [0.0, 0.5, 1.0],
          ),
          border: Border.all(
            color: platinum.withOpacity(0.35),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.75),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: copperGlow.withOpacity(0.6),
              blurRadius: 32,
              spreadRadius: -4,
            ),
          ],
        ),
        child: FloatingActionButton(
          backgroundColor: Colors.transparent,
          foregroundColor: platinum,
          onPressed: _showAddSenderDialog,
          elevation: 0,
          child: const Icon(Icons.add_rounded, size: 26),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// GEOMETRIC PATTERN PAINTER
// ═══════════════════════════════════════════════════════════════════
class _GeometricPatternPainter extends CustomPainter {
  final Color color;

  _GeometricPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 0.25
      ..style = PaintingStyle.stroke;

    final gridSize = 60.0;

    for (double i = -size.height; i < size.width * 2; i += gridSize) {
      canvas.drawLine(Offset(i, 0), Offset(i + size.height, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GeometricPatternPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}