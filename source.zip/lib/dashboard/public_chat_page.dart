// public_chat_page.dart - 3D HD Merah Kecoklatan + Fix Jam Lokal
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'theme_provider.dart';
import '../sistem/config.dart';
import '../sistem/apiBaseUrl.dart';

// ═══════════════════════════════════════════════════════════
// PALET WARNA — MERAH KECOKLATAN 3D HD
// ═══════════════════════════════════════════════════════════
class AppColors {
  static const Color primary = Color(0xFF8B2500);
  static const Color primaryLight = Color(0xFFB83A1A);
  static const Color accent = Color(0xFFD2691E);
  static const Color accentGold = Color(0xFFE8A33D);

  static const Color bgTop = Color(0xFFF5E6D3);
  static const Color bgMid = Color(0xFFFFF8F0);
  static const Color bgBottom = Color(0xFFE8D5B7);

  static const Color surfaceLight = Color(0xFFFFFBF5);
  static const Color surfaceMid = Color(0xFFF2E4D0);
  static const Color border = Color(0xFFD4A574);

  static const Color textDark = Color(0xFF3D1F10);
  static const Color textMid = Color(0xFF6B4226);
  static const Color textLight = Color(0xFF9B6F52);

  static const Color bubbleMeTop = Color(0xFFB83A1A);
  static const Color bubbleMeBottom = Color(0xFF8B2500);
  static const Color bubbleOther = Color(0xFFFFFFFF);

  static const Color online = Color(0xFF22C55E);
}

class PublicChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const PublicChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  int _onlineCount = 0;
  Timer? _pollingTimer;
  Timer? _onlineTimer;
  String? _lastMessageId;

  bool _isRecording = false;
  AudioRecorder? _audioRecorder;
  String? _audioPath;
  Timer? _recordTimer;
  int _recordDuration = 0;

  final List<String> _stickers = [
    'assets/stickers/1.jpg',
    'assets/stickers/2.jpg',
    'assets/stickers/3.jpg',
    'assets/stickers/4.jpg',
    'assets/stickers/5.jpg',
    'assets/stickers/6.jpg',
    'assets/stickers/7.jpg',
    'assets/stickers/8.jpg',
    'assets/stickers/9.jpg',
    'assets/stickers/10.jpg',
  ];

  OverlayEntry? _stickerOverlay;
  OverlayEntry? _attachmentOverlay;

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _startPolling();
    _fetchOnlineUsers();
    _startOnlinePolling();
    _checkPermissions();
    _audioRecorder = AudioRecorder();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _onlineTimer?.cancel();
    _recordTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    _audioRecorder?.dispose();
    _stickerOverlay?.remove();
    _attachmentOverlay?.remove();
    super.dispose();
  }

  Future<void> _checkPermissions() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _showSnackBar('Izin mikrofon diperlukan untuk voice note', isError: true);
    }
  }

  void _startPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _checkNewMessages();
    });
  }

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _fetchOnlineUsers();
    });
  }

  Future<void> _checkNewMessages() async {
    if (_lastMessageId == null) return;

    try {
      final response = await http.get(
        Uri.parse(
            '$apiBaseUrl/getPublicChat?key=${widget.sessionKey}&lastId=$_lastMessageId'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final newMessages = (data['messages'] as List)
              .map((item) => ChatMessage.fromJson(item))
              .toList();

          if (newMessages.isNotEmpty) {
            setState(() {
              _messages.insertAll(0, newMessages);
              _lastMessageId = _messages.first.id;
            });
          }
        }
      }
    } catch (e) {
      print('Error checking new messages: $e');
    }
  }

  Future<void> _loadMessages() async {
    setState(() => _isLoading = true);

    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/getPublicChat?key=${widget.sessionKey}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _messages = (data['messages'] as List)
                .map((item) => ChatMessage.fromJson(item))
                .toList();
            if (_messages.isNotEmpty) {
              _lastMessageId = _messages.first.id;
            }
          });
        }
      }
    } catch (e) {
      print('Error loading messages: $e');
    } finally {
      setState(() => _isLoading = false);
      _scrollToBottom();
    }
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/getOnlineUsers?key=${widget.sessionKey}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _onlineCount = data['count'] ?? 0;
          });
        }
      }
    } catch (e) {
      print('Error fetching online users: $e');
    }
  }

  Future<void> _sendMessage({String? type, String? content}) async {
    final message = _messageController.text.trim();
    if (message.isEmpty && type == null) return;

    setState(() => _isSending = true);

    try {
      final payload = {
        'key': widget.sessionKey,
        'message': type == 'text' ? message : '',
        // 🕐 Kirim timestamp UTC dari device (agar server simpan waktu akurat)
        'timestamp': DateTime.now().toUtc().toIso8601String(),
      };

      if (type != null) {
        payload['type'] = type;
        if (content != null) payload['content'] = content;
      }

      final response = await http.post(
        Uri.parse('$apiBaseUrl/sendPublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        _messageController.clear();
        final newMessage = ChatMessage.fromJson(data['message']);
        setState(() {
          _messages.insert(0, newMessage);
          _lastMessageId = newMessage.id;
        });
        _scrollToBottom();
      } else {
        _showSnackBar(data['message'] ?? 'Gagal mengirim pesan', isError: true);
      }
    } catch (e) {
      print('Error sending message: $e');
      _showSnackBar('Gagal mengirim pesan', isError: true);
    } finally {
      setState(() => _isSending = false);
    }
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);

    if (picked != null) {
      final bytes = await File(picked.path).readAsBytes();
      final base64Image = base64Encode(bytes);

      try {
        final response = await http.post(
          Uri.parse('$apiBaseUrl/sendPublicChat'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'key': widget.sessionKey,
            'type': 'image',
            'content': base64Image,
            'filename': picked.name,
            'timestamp': DateTime.now().toUtc().toIso8601String(),
          }),
        );

        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final newMessage = ChatMessage.fromJson(data['message']);
          setState(() {
            _messages.insert(0, newMessage);
            _lastMessageId = newMessage.id;
          });
          _scrollToBottom();
        } else {
          _showSnackBar(data['message'] ?? 'Gagal mengirim gambar', isError: true);
        }
      } catch (e) {
        _showSnackBar('Gagal mengirim gambar', isError: true);
      }
    }
  }

  Future<void> _sendSticker(String stickerPath) async {
    try {
      final ByteData data = await rootBundle.load(stickerPath);
      final bytes = data.buffer.asUint8List();
      final base64Sticker = base64Encode(bytes);

      final response = await http.post(
        Uri.parse('$apiBaseUrl/sendPublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'type': 'sticker',
          'content': base64Sticker,
          'filename': stickerPath.split('/').last,
          'timestamp': DateTime.now().toUtc().toIso8601String(),
        }),
      );

      final dataJson = jsonDecode(response.body);
      if (dataJson['valid'] == true) {
        final newMessage = ChatMessage.fromJson(dataJson['message']);
        setState(() {
          _messages.insert(0, newMessage);
          _lastMessageId = newMessage.id;
        });
        _scrollToBottom();
        _closeStickerOverlay();
      } else {
        _showSnackBar(dataJson['message'] ?? 'Gagal mengirim sticker', isError: true);
      }
    } catch (e) {
      print('Error sending sticker: $e');
      _showSnackBar('Gagal mengirim sticker', isError: true);
    }
  }

  Future<void> _startRecording() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _showSnackBar('Izin mikrofon diperlukan', isError: true);
      return;
    }

    try {
      final directory = await getApplicationDocumentsDirectory();
      final path = '${directory.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';

      await _audioRecorder!.start(
        const RecordConfig(),
        path: path,
      );

      setState(() {
        _isRecording = true;
        _recordDuration = 0;
        _audioPath = path;
      });

      _recordTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (mounted) {
          setState(() {
            _recordDuration++;
          });
        }
      });
    } catch (e) {
      print('Recording error: $e');
      _showSnackBar('Gagal memulai rekaman', isError: true);
    }
  }

  Future<void> _stopRecording() async {
    _recordTimer?.cancel();

    if (_audioRecorder != null && _isRecording) {
      try {
        final path = await _audioRecorder!.stop();

        setState(() {
          _isRecording = false;
          _audioPath = path;
        });

        if (path != null && await File(path).exists()) {
          final bytes = await File(path).readAsBytes();
          final base64Audio = base64Encode(bytes);

          try {
            final response = await http.post(
              Uri.parse('$apiBaseUrl/sendPublicChat'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'key': widget.sessionKey,
                'type': 'voice',
                'content': base64Audio,
                'duration': _recordDuration,
                'filename': 'voice_${DateTime.now().millisecondsSinceEpoch}.m4a',
                'timestamp': DateTime.now().toUtc().toIso8601String(),
              }),
            );

            final data = jsonDecode(response.body);
            if (data['valid'] == true) {
              final newMessage = ChatMessage.fromJson(data['message']);
              setState(() {
                _messages.insert(0, newMessage);
                _lastMessageId = newMessage.id;
              });
              _scrollToBottom();
            } else {
              _showSnackBar(data['message'] ?? 'Gagal mengirim voice note', isError: true);
            }
          } catch (e) {
            print('Send voice error: $e');
            _showSnackBar('Gagal mengirim voice note', isError: true);
          }
        }

        setState(() => _audioPath = null);
      } catch (e) {
        print('Stop recording error: $e');
        _showSnackBar('Gagal menghentikan rekaman', isError: true);
      }
    }
  }

  Future<void> _deleteMessage(String messageId, String messageUsername) async {
    final canDelete = widget.role == 'pemula' || widget.username == messageUsername;

    if (!canDelete) {
      _showSnackBar('Tidak bisa menghapus pesan orang lain', isError: true);
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 300),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.surfaceLight, AppColors.surfaceMid],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: AppColors.border.withOpacity(0.6),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.35),
                  blurRadius: 40,
                  spreadRadius: 2,
                  offset: const Offset(0, 20),
                ),
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.25),
                  blurRadius: 30,
                  spreadRadius: 2,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 8,
                  offset: const Offset(-3, -3),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF7043), Color(0xFFD84315)],
                    ),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFD84315).withOpacity(0.55),
                        blurRadius: 22,
                        spreadRadius: 2,
                        offset: const Offset(0, 10),
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.4),
                        blurRadius: 6,
                        offset: const Offset(-3, -3),
                      ),
                    ],
                  ),
                  child: const Icon(Icons.warning_amber_rounded,
                      color: Colors.white, size: 34),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Hapus Pesan",
                  style: TextStyle(
                    color: AppColors.textDark,
                    fontWeight: FontWeight.w900,
                    fontSize: 20,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "Yakin ingin menghapus pesan ini?",
                  style: TextStyle(color: AppColors.textMid, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: _buildDialogButton(
                        label: "BATAL",
                        onTap: () => Navigator.pop(context, false),
                        isPrimary: false,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildDialogButton(
                        label: "HAPUS",
                        onTap: () => Navigator.pop(context, true),
                        isPrimary: true,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (confirm != true) return;

    try {
      final response = await http.delete(
        Uri.parse('$apiBaseUrl/deletePublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'messageId': messageId,
        }),
      );

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        setState(() {
          _messages.removeWhere((m) => m.id == messageId);
        });
        _showSnackBar('Pesan berhasil dihapus', isError: false);
      } else {
        _showSnackBar(data['message'] ?? 'Gagal menghapus pesan', isError: true);
      }
    } catch (e) {
      print('Error deleting message: $e');
      _showSnackBar('Gagal menghapus pesan', isError: true);
    }
  }

  Widget _buildDialogButton({
    required String label,
    required VoidCallback onTap,
    required bool isPrimary,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: isPrimary
              ? const LinearGradient(
                  colors: [Color(0xFFB83A1A), Color(0xFF8B2500)],
                )
              : const LinearGradient(
                  colors: [Colors.white, Color(0xFFF2E4D0)],
                ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isPrimary
                ? AppColors.primary.withOpacity(0.5)
                : AppColors.border.withOpacity(0.5),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: isPrimary
                  ? AppColors.primary.withOpacity(0.45)
                  : Colors.black.withOpacity(0.15),
              blurRadius: 14,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.5),
              blurRadius: 5,
              offset: const Offset(-2, -2),
            ),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isPrimary ? Colors.white : AppColors.textMid,
              fontWeight: FontWeight.w800,
              letterSpacing: 1,
            ),
          ),
        ),
      ),
    );
  }

  void _showSnackBar(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
        backgroundColor: isError
            ? const Color(0xFFD84315).withOpacity(0.95)
            : AppColors.primary.withOpacity(0.95),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'pemula':
        return const Color(0xFFD4A017);
      case 'partner':
        return const Color(0xFF8B4513);
      case 'reseller':
        return const Color(0xFF6B8E23);
      default:
        return AppColors.textMid;
    }
  }

  // ===== OVERLAY =====
  void _showStickerOverlay() {
    _closeAttachmentOverlay();
    if (_stickerOverlay != null) {
      _closeStickerOverlay();
      return;
    }

    final overlay = Overlay.of(context);

    _stickerOverlay = OverlayEntry(
      builder: (context) => Positioned(
        bottom: 80,
        left: 0,
        right: 0,
        child: Material(
          color: Colors.transparent,
          child: Container(
            height: 300,
            margin: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.surfaceLight, AppColors.surfaceMid],
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppColors.border.withOpacity(0.6)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.35),
                  blurRadius: 35,
                  spreadRadius: 2,
                  offset: const Offset(0, 18),
                ),
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.25),
                  blurRadius: 25,
                  spreadRadius: 2,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 6,
                  offset: const Offset(-3, -3),
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: AppColors.border.withOpacity(0.4)),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 4,
                            height: 18,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [AppColors.primaryLight, AppColors.primary],
                              ),
                              borderRadius: BorderRadius.circular(2),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primary.withOpacity(0.5),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 10),
                          const Text(
                            "STICKERS",
                            style: TextStyle(
                              color: AppColors.textDark,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded, color: AppColors.textMid),
                        onPressed: _closeStickerOverlay,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount: _stickers.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () => _sendSticker(_stickers[index]),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: AppColors.border.withOpacity(0.5),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.15),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              ),
                              BoxShadow(
                                color: Colors.white,
                                blurRadius: 4,
                                offset: const Offset(-2, -2),
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Image.asset(
                              _stickers[index],
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Center(
                                child: Icon(
                                  Icons.sticky_note_2_rounded,
                                  color: AppColors.textLight,
                                  size: 32,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    overlay.insert(_stickerOverlay!);
  }

  void _closeStickerOverlay() {
    _stickerOverlay?.remove();
    _stickerOverlay = null;
  }

  void _showAttachmentOverlay() {
    _closeStickerOverlay();
    if (_attachmentOverlay != null) {
      _closeAttachmentOverlay();
      return;
    }

    final overlay = Overlay.of(context);

    _attachmentOverlay = OverlayEntry(
      builder: (context) => Positioned(
        bottom: 80,
        left: 0,
        right: 0,
        child: Material(
          color: Colors.transparent,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.surfaceLight, AppColors.surfaceMid],
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppColors.border.withOpacity(0.6)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.35),
                  blurRadius: 35,
                  spreadRadius: 2,
                  offset: const Offset(0, 18),
                ),
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.25),
                  blurRadius: 25,
                  spreadRadius: 2,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 6,
                  offset: const Offset(-3, -3),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildAttachmentButton(
                      icon: Icons.photo_rounded,
                      label: "Gambar",
                      color: AppColors.primary,
                      onTap: () {
                        _closeAttachmentOverlay();
                        _sendImage();
                      },
                    ),
                    _buildAttachmentButton(
                      icon: Icons.mic_rounded,
                      label: _isRecording ? "Stop" : "Voice",
                      color: _isRecording ? const Color(0xFFD84315) : AppColors.accent,
                      onTap: () {
                        if (_isRecording) {
                          _stopRecording();
                        } else {
                          _startRecording();
                        }
                        _closeAttachmentOverlay();
                      },
                    ),
                    _buildAttachmentButton(
                      icon: Icons.sticky_note_2_rounded,
                      label: "Sticker",
                      color: AppColors.accentGold,
                      onTap: () {
                        _closeAttachmentOverlay();
                        _showStickerOverlay();
                      },
                    ),
                  ],
                ),
                if (_isRecording) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF7043), Color(0xFFD84315)],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFD84315).withOpacity(0.5),
                          blurRadius: 14,
                          spreadRadius: 1,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.circle, color: Colors.white, size: 12),
                        const SizedBox(width: 8),
                        Text(
                          'Merekam... ${_formatDuration(_recordDuration)}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );

    overlay.insert(_attachmentOverlay!);
  }

  void _closeAttachmentOverlay() {
    _attachmentOverlay?.remove();
    _attachmentOverlay = null;
  }

  Widget _buildAttachmentButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  color.withOpacity(0.9),
                  color,
                ],
              ),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.5),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.5),
                  blurRadius: 16,
                  spreadRadius: 1,
                  offset: const Offset(0, 8),
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 5,
                  offset: const Offset(-3, -3),
                ),
              ],
            ),
            child: Icon(icon, color: Colors.white, size: 26),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textDark,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDuration(int seconds) {
    final minutes = seconds ~/ 60;
    final secs = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);

    return Scaffold(
      backgroundColor: AppColors.bgMid,
      appBar: _buildAppBar(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.bgTop, AppColors.bgMid, AppColors.bgBottom],
            stops: [0.0, 0.5, 1.0],
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: AppColors.primary,
                        strokeWidth: 3,
                      ),
                    )
                  : _messages.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          controller: _scrollController,
                          reverse: true,
                          padding: const EdgeInsets.all(12),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final msg = _messages[index];
                            final isMe = msg.username == widget.username;
                            return GestureDetector(
                              onLongPress: () => _deleteMessage(msg.id, msg.username),
                              child: TweenAnimationBuilder(
                                duration: Duration(milliseconds: 200 + (index * 20)),
                                tween: Tween<double>(begin: 0, end: 1),
                                builder: (context, double value, child) {
                                  return Opacity(
                                    opacity: value,
                                    child: Transform.translate(
                                      offset: Offset(0, 20 * (1 - value)),
                                      child: child,
                                    ),
                                  );
                                },
                                child: _buildMessageBubble(msg, isMe),
                              ),
                            );
                          },
                        ),
            ),
            _buildInputBar(),
          ],
        ),
      ),
    );
  }

  // ═══════════════ APPBAR 3D HD ═══════════════
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.primaryLight, AppColors.primary],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.25), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withOpacity(0.55),
              blurRadius: 18,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: AppColors.accentGold.withOpacity(0.35),
              blurRadius: 12,
              spreadRadius: 1,
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.35),
              blurRadius: 4,
              offset: const Offset(-2, -2),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.public_rounded, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            const Text(
              "PUBLIC CHAT",
              style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white, Color(0xFFF2E4D0)],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
              BoxShadow(
                color: Colors.white,
                blurRadius: 4,
                offset: const Offset(-2, -2),
              ),
            ],
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new,
                color: AppColors.primary, size: 16),
            onPressed: () => Navigator.pop(context),
          ),
        ),
      ),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 12),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                AppColors.online.withOpacity(0.25),
                AppColors.online.withOpacity(0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.online.withOpacity(0.4)),
            boxShadow: [
              BoxShadow(
                color: AppColors.online.withOpacity(0.35),
                blurRadius: 12,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: AppColors.online,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.online,
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Text(
                '$_onlineCount Online',
                style: const TextStyle(
                  color: AppColors.online,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════ EMPTY STATE ═══════════════
  Widget _buildEmptyState() {
    return Center(
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 600),
        tween: Tween<double>(begin: 0, end: 1),
        builder: (context, double value, child) {
          return Opacity(
            opacity: value,
            child: Transform.translate(
              offset: Offset(0, 20 * (1 - value)),
              child: child,
            ),
          );
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(34),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.surfaceLight, AppColors.surfaceMid],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.border.withOpacity(0.6)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.25),
                    blurRadius: 30,
                    spreadRadius: 2,
                    offset: const Offset(0, 15),
                  ),
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.2),
                    blurRadius: 25,
                    spreadRadius: 2,
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.7),
                    blurRadius: 8,
                    offset: const Offset(-3, -3),
                  ),
                ],
              ),
              child: const Icon(Icons.chat_bubble_outline,
                  size: 64, color: AppColors.primary),
            ),
            const SizedBox(height: 20),
            const Text(
              'Belum ada pesan',
              style: TextStyle(
                color: AppColors.textDark,
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Jadilah yang pertama mengirim pesan',
              style: TextStyle(color: AppColors.textLight, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════ INPUT BAR 3D HD ═══════════════
  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.surfaceLight, AppColors.surfaceMid],
        ),
        border: Border(
          top: BorderSide(color: AppColors.border.withOpacity(0.5), width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 20,
            offset: const Offset(0, -6),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.7),
            blurRadius: 6,
            offset: const Offset(-3, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: _showAttachmentOverlay,
            child: Container(
              padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.accentGold, AppColors.accent],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(0.4), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.5),
                    blurRadius: 14,
                    spreadRadius: 1,
                    offset: const Offset(0, 7),
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 4,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: const Icon(Icons.attach_file_rounded,
                  color: Colors.white, size: 22),
            ),
          ),
          const SizedBox(width: 10),

          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: AppColors.border.withOpacity(0.5), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                  BoxShadow(
                    color: Colors.white,
                    blurRadius: 4,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: TextField(
                controller: _messageController,
                style: const TextStyle(color: AppColors.textDark),
                maxLines: null,
                decoration: const InputDecoration(
                  hintText: 'Tulis pesan...',
                  hintStyle: TextStyle(color: AppColors.textLight),
                  border: InputBorder.none,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                ),
                onSubmitted: (_) => _sendMessage(type: 'text'),
              ),
            ),
          ),
          const SizedBox(width: 10),

          GestureDetector(
            onTap: _isSending ? null : () => _sendMessage(type: 'text'),
            child: Container(
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.primaryLight, AppColors.primary],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.6),
                    blurRadius: 18,
                    spreadRadius: 1,
                    offset: const Offset(0, 9),
                  ),
                  BoxShadow(
                    color: AppColors.accentGold.withOpacity(0.3),
                    blurRadius: 12,
                    spreadRadius: 2,
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.5),
                    blurRadius: 4,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: _isSending
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.send_rounded,
                      color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════ MESSAGE BUBBLE 3D HD ═══════════════
  Widget _buildMessageBubble(ChatMessage msg, bool isMe) {
    final isImage = msg.type == 'image';
    final isSticker = msg.type == 'sticker';
    final isVoice = msg.type == 'voice';

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isMe) ...[
            Container(
              width: 44,
              height: 44,
              margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.accentGold, AppColors.accent],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(0.4), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.5),
                    blurRadius: 12,
                    spreadRadius: 1,
                    offset: const Offset(0, 6),
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 4,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  msg.username.isNotEmpty ? msg.username[0].toUpperCase() : '?',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.75,
              ),
              padding: isSticker
                  ? EdgeInsets.zero
                  : const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
              decoration: isSticker
                  ? null
                  : BoxDecoration(
                      gradient: isMe
                          ? const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [AppColors.bubbleMeTop, AppColors.bubbleMeBottom],
                            )
                          : const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Colors.white, Color(0xFFFFFBF5)],
                            ),
                      borderRadius: BorderRadius.circular(20).copyWith(
                        bottomRight: isMe
                            ? const Radius.circular(6)
                            : const Radius.circular(20),
                        bottomLeft: isMe
                            ? const Radius.circular(20)
                            : const Radius.circular(6),
                      ),
                      border: Border.all(
                        color: isMe
                            ? AppColors.accentGold.withOpacity(0.4)
                            : AppColors.border.withOpacity(0.4),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: isMe
                              ? AppColors.primary.withOpacity(0.45)
                              : Colors.black.withOpacity(0.2),
                          blurRadius: 16,
                          spreadRadius: 1,
                          offset: const Offset(0, 8),
                        ),
                        BoxShadow(
                          color: Colors.white.withOpacity(isMe ? 0.25 : 0.9),
                          blurRadius: 5,
                          offset: const Offset(-2, -2),
                        ),
                      ],
                    ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isMe && !isSticker)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5),
                      child: Row(
                        children: [
                          Text(
                            msg.username,
                            style: TextStyle(
                              color: _getRoleColor(msg.role),
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.3,
                            ),
                          ),
                          if (msg.role == 'pemula') ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [Color(0xFFE8A33D), Color(0xFFD4A017)],
                                ),
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFD4A017).withOpacity(0.5),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                              child: const Text(
                                "DEV",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 8,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),

                  if (isImage)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.memory(
                        base64Decode(msg.content!),
                        fit: BoxFit.cover,
                        width: 200,
                        height: 200,
                      ),
                    )
                  else if (isSticker)
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.25),
                            blurRadius: 14,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Image.memory(
                          base64Decode(msg.content!),
                          fit: BoxFit.contain,
                          width: 120,
                          height: 120,
                        ),
                      ),
                    )
                  else if (isVoice)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: isMe
                                ? Colors.white.withOpacity(0.2)
                                : AppColors.primary.withOpacity(0.1),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: (isMe ? Colors.white : AppColors.primary)
                                    .withOpacity(0.4),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                          child: Icon(
                            Icons.mic_rounded,
                            color: isMe ? Colors.white : AppColors.primary,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          'Voice (${_formatDuration(msg.duration ?? 0)})',
                          style: TextStyle(
                            color: isMe ? Colors.white : AppColors.textDark,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    )
                  else
                    Text(
                      msg.message,
                      style: TextStyle(
                        color: isMe ? Colors.white : AppColors.textDark,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w500,
                        height: 1.4,
                      ),
                      softWrap: true,
                    ),

                  if (!isSticker) ...[
                    const SizedBox(height: 4),
                    // 🕐 JAM LOKAL DEVICE (bukan dari server)
                    Text(
                      msg.displayTime,
                      style: TextStyle(
                        color: isMe
                            ? Colors.white.withOpacity(0.8)
                            : AppColors.textLight,
                        fontSize: 9,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// MODEL CHAT MESSAGE + FIX JAM LOKAL
// ═══════════════════════════════════════════════════════════
class ChatMessage {
  final String id;
  final String username;
  final String role;
  final String message;
  final String timestamp;
  final String formattedTime; // fallback dari server
  final String? type;
  final String? content;
  final int? duration;

  ChatMessage({
    required this.id,
    required this.username,
    required this.role,
    required this.message,
    required this.timestamp,
    required this.formattedTime,
    this.type,
    this.content,
    this.duration,
  });

  /// 🕐 Jam lokal device (HH:mm), dihitung dari [timestamp].
  /// Otomatis konversi UTC/offset apapun → jam device user.
  String get displayTime {
    try {
      // Handle format "2026-09-11 15:30:00" (spasi → T)
      final raw = timestamp.contains(' ')
          ? timestamp.replaceFirst(' ', 'T')
          : timestamp;

      final dt = DateTime.parse(raw).toLocal();

      final hh = dt.hour.toString().padLeft(2, '0');
      final mm = dt.minute.toString().padLeft(2, '0');
      return '$hh:$mm';
    } catch (_) {
      // Fallback: pakai formattedTime dari server, buang detik kalau ada
      final parts = formattedTime.split(':');
      if (parts.length >= 2) {
        return '${parts[0]}:${parts[1]}';
      }
      return formattedTime;
    }
  }

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'] ?? '',
      username: json['username'] ?? '',
      role: json['role'] ?? 'member',
      message: json['message'] ?? '',
      timestamp: json['timestamp'] ?? DateTime.now().toIso8601String(),
      formattedTime: json['formattedTime'] ?? '',
      type: json['type'],
      content: json['content'],
      duration: json['duration'],
    );
  }
}