import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';

// ═══════════════════════════════════════════════════════════════════
// 🎨 PALET WARNA — SAMA DENGAN LANDING & BUY ACCOUNT
// ═══════════════════════════════════════════════════════════════════
class _Palette {
  static const Color bgCream      = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain      = Color(0xFFB71C1C);
  static const Color redDark      = Color(0xFF7F0000);
  static const Color redDeep      = Color(0xFF4A0000);
  static const Color brownDark    = Color(0xFF2B0E0E);
  static const Color brownMid     = Color(0xFF5D2B1F);
  static const Color gold         = Color(0xFFD4A853);
  static const Color borderDark   = Color(0xFF1A0505);
  static const Color white        = Colors.white;
}

class UpgradePrice {
  final String fromRole;
  final String toRole;
  final int price;

  UpgradePrice({required this.fromRole, required this.toRole, required this.price});
}

class UpgradeRolePage extends StatefulWidget {
  final String sessionKey;
  final String role;
  final String username;

  const UpgradeRolePage({
    super.key,
    required this.sessionKey,
    required this.role,
    required this.username,
  });

  @override
  State<UpgradeRolePage> createState() => _UpgradeRolePageState();
}

class _UpgradeRolePageState extends State<UpgradeRolePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  final String atlasApiKey = "atlas_0ff250e07243c63d";
  final List<String> roleOrder = ["member", "reseller", "partner"];

  final List<UpgradePrice> upgradePrices = [
    UpgradePrice(fromRole: "member", toRole: "reseller", price: 25000),
    UpgradePrice(fromRole: "reseller", toRole: "partner", price: 45000),
  ];

  String? selectedTargetRole;
  int? selectedPrice;
  bool isLoading = false;

  final List<String> consoleLogs = [];

  void addLog(String message) {
    if (!mounted) return;
    setState(() {
      consoleLogs.insert(0, "${DateTime.now().toString().substring(11, 19)} - $message");
      if (consoleLogs.length > 20) consoleLogs.removeLast();
    });
  }

  @override
  void initState() {
    super.initState();
    _initAnimations();

    final currentIndex = roleOrder.indexOf(widget.role.toLowerCase());
    if (currentIndex != -1 && currentIndex < roleOrder.length - 1) {
      final nextRole = roleOrder[currentIndex + 1];
      final priceItem = upgradePrices.firstWhere(
        (item) => item.fromRole == widget.role.toLowerCase() && item.toRole == nextRole,
        orElse: () => UpgradePrice(fromRole: "", toRole: "", price: 0),
      );
      selectedTargetRole = nextRole;
      selectedPrice = priceItem.price;
    }
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..forward();

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  List<String> getAvailableUpgrades() {
    final currentIndex = roleOrder.indexOf(widget.role.toLowerCase());
    if (currentIndex == -1) return [];
    return roleOrder.sublist(currentIndex + 1);
  }

  int? getUpgradePrice(String targetRole) {
    final priceItem = upgradePrices.firstWhere(
      (item) => item.fromRole == widget.role.toLowerCase() && item.toRole == targetRole,
      orElse: () => UpgradePrice(fromRole: "", toRole: "", price: 0),
    );
    return priceItem.price > 0 ? priceItem.price : null;
  }

  void _showSnackBar(String msg, bool isError) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: _Palette.gold,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(
                  color: _Palette.white,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? _Palette.redDeep : _Palette.brownMid,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: _Palette.borderDark, width: 2.5),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> createTopup() async {
    if (selectedTargetRole == null || selectedPrice == null) {
      _showSnackBar("Pilih role tujuan terlebih dahulu", true);
      return;
    }

    setState(() => isLoading = true);
    final int nominal = selectedPrice!;
    final String reference = "UPG-${widget.username}-${DateTime.now().millisecondsSinceEpoch}";

    try {
      final response = await http.get(
        Uri.parse('https://qris.atlas-by-erlan.com/topup?nominal=$nominal&apikey=$atlasApiKey&reference=$reference'),
      );

      final decoded = jsonDecode(response.body);
      setState(() => isLoading = false);

      if (decoded['ok'] == true && decoded['data'] != null) {
        final data = decoded['data'];
        final String orderId = data['id'];
        final String qrisString = data['qris'];
        final int payAmount = data['pay_amount'] ?? nominal;

        addLog("✅ Transaksi dibuat: $orderId");
        _showQrisDialog(
          orderId: orderId,
          qrisString: qrisString,
          total: payAmount,
        );
      } else {
        addLog("❌ Gagal: ${decoded['message'] ?? "Gagal membuat order QRIS."}");
        _showSnackBar(decoded['message'] ?? "Gagal membuat order QRIS.", true);
      }
    } catch (e) {
      setState(() => isLoading = false);
      addLog("⚠️ Error: $e");
      _showSnackBar("Terjadi kesalahan koneksi QRIS Gateway.", true);
    }
  }

  void _showQrisDialog({
    required String orderId,
    required String qrisString,
    required int total,
  }) {
    Timer? timer;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        String paymentStatus = "Menunggu Pembayaran...";

        return StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            timer ??= Timer.periodic(const Duration(seconds: 4), (t) async {
              try {
                final res = await http.get(
                  Uri.parse('https://qris.atlas-by-erlan.com/check-status?id=$orderId'),
                );
                final statusDecoded = jsonDecode(res.body);

                if (statusDecoded['ok'] == true && statusDecoded['data'] != null) {
                  final statusData = statusDecoded['data'];
                  final String status = statusData['status'];

                  if (status == 'paid' || status == 'success') {
                    t.cancel();
                    Navigator.pop(dialogContext);
                    addLog("✅ Pembayaran BERHASIL!");
                    await callUpgradeApi();
                  } else if (status == 'expired' || status == 'failed' || status == 'cancelled') {
                    t.cancel();
                    setDialogState(() {
                      paymentStatus = "Pembayaran Kadaluarsa / Gagal!";
                    });
                    addLog("⏰ Transaksi kadaluarsa / gagal / dibatalkan.");
                  }
                }
              } catch (_) {}
            });

            return Dialog(
              backgroundColor: Colors.transparent,
              child: TweenAnimationBuilder(
                duration: const Duration(milliseconds: 300),
                tween: Tween<double>(begin: 0, end: 1),
                builder: (context, double scale, child) {
                  return Transform.scale(scale: scale, child: child);
                },
                child: Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_Palette.bgCreamLight, _Palette.bgCream],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: _Palette.borderDark, width: 3.5),
                    boxShadow: const [
                      BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(5, 5)),
                      BoxShadow(color: Color(0x88000000), blurRadius: 18, offset: Offset(0, 9)),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              colors: [_Palette.redMain, _Palette.redDark]),
                          shape: BoxShape.circle,
                          border: Border.all(color: _Palette.borderDark, width: 2.5),
                          boxShadow: const [
                            BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                          ],
                        ),
                        child: const Icon(Icons.qr_code_2, color: _Palette.gold, size: 30),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        "Scan QRIS",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: _Palette.redDark,
                          letterSpacing: 1.5,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "ID: $orderId",
                        style: TextStyle(
                          fontSize: 11,
                          color: _Palette.brownMid.withOpacity(0.8),
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              colors: [_Palette.redMain, _Palette.redDark]),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: _Palette.borderDark, width: 2.5),
                          boxShadow: const [
                            BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                          ],
                        ),
                        child: Text(
                          NumberFormat.currency(
                            locale: 'id',
                            symbol: 'Rp ',
                            decimalDigits: 0,
                          ).format(total),
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            color: _Palette.white,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        width: 200,
                        height: 200,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _Palette.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: _Palette.borderDark, width: 3),
                          boxShadow: const [
                            BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(4, 4)),
                          ],
                        ),
                        child: Center(
                          child: QrImageView(
                            data: qrisString,
                            version: QrVersions.auto,
                            size: 180.0,
                            backgroundColor: _Palette.white,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        "Setelah bayar, role otomatis ter-upgrade\nStatus dicek tiap 4 detik",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _Palette.brownMid,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: _Palette.redMain.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _Palette.redMain, width: 2),
                        ),
                        child: Text(
                          paymentStatus,
                          style: const TextStyle(
                            color: _Palette.redDark,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      GestureDetector(
                        onTap: () async {
                          timer?.cancel();
                          try {
                            await http.get(
                              Uri.parse('https://qris.atlas-by-erlan.com/cancel-order?id=$orderId'),
                            );
                            addLog("🚫 Order dibatalkan manual.");
                          } catch (_) {}
                          Navigator.pop(dialogContext);
                        },
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                                colors: [_Palette.redMain, _Palette.redDark]),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: _Palette.borderDark, width: 2.5),
                            boxShadow: const [
                              BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              "CLOSE / BATALKAN",
                              style: TextStyle(
                                color: _Palette.white,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.5,
                                fontSize: 12,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    ).then((_) => timer?.cancel());
  }

  Future<void> callUpgradeApi() async {
    if (selectedTargetRole == null) return;
    final url = Uri.parse("https://app.atlas-by-erlan.com/upRole?key=${widget.sessionKey}&uprole=${selectedTargetRole!.toLowerCase()}");
    addLog("📡 Memanggil API upgrade ke role: ${selectedTargetRole!.toUpperCase()}");
    try {
      final response = await http.get(url);
      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && (data["status"] == true || data["success"] == true)) {
        addLog("🎉 Upgrade role BERHASIL! Role baru: ${selectedTargetRole!.toUpperCase()}");
        _showSnackBar("🎉 Upgrade berhasil! Role Anda sekarang: ${selectedTargetRole!.toUpperCase()}", false);
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) Navigator.pop(context, true);
        });
      } else {
        addLog("❌ Gagal upgrade: ${data["message"] ?? "Unknown error"}");
        _showSnackBar("Upgrade gagal: ${data["message"] ?? "Silakan coba lagi"}", true);
      }
    } catch (e) {
      addLog("⚠️ Error upgrade: $e");
      _showSnackBar("Error upgrade: $e", true);
    }
  }

  // ─── KARTU ROLE SAAT INI ────────────────────────────────────────
  Widget _buildCurrentRoleCard() {
    final currentIndex = roleOrder.indexOf(widget.role.toLowerCase());
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_Palette.bgCreamLight, _Palette.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(4, 4)),
          BoxShadow(color: Color(0x77000000), blurRadius: 12, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [_Palette.redMain, _Palette.redDark]),
                  shape: BoxShape.circle,
                  border: Border.all(color: _Palette.borderDark, width: 2.5),
                  boxShadow: const [
                    BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                  ],
                ),
                child: const Icon(Icons.stars_rounded, color: _Palette.gold, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "ROLE SAAT INI",
                      style: TextStyle(
                        color: _Palette.brownMid,
                        fontSize: 10,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      widget.role.toUpperCase(),
                      style: const TextStyle(
                        color: _Palette.redDark,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(color: Color(0x33000000), blurRadius: 3, offset: Offset(2, 2)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _Palette.redMain,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _Palette.borderDark, width: 2),
                  boxShadow: const [
                    BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(2, 2)),
                  ],
                ),
                child: Text(
                  "${currentIndex + 1}/${roleOrder.length}",
                  style: const TextStyle(
                    color: _Palette.gold,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _Palette.borderDark, width: 2),
              boxShadow: const [
                BoxShadow(color: Color(0x55000000), blurRadius: 0, offset: Offset(2, 2)),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: (currentIndex + 1) / roleOrder.length,
                backgroundColor: _Palette.bgCreamLight,
                valueColor: const AlwaysStoppedAnimation<Color>(_Palette.redMain),
                minHeight: 10,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── PILIHAN ROLE ───────────────────────────────────────────────
  Widget _buildRoleOptions(List<String> availableRoles) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Row(
            children: [
              const Icon(Icons.arrow_circle_up_rounded, color: _Palette.gold, size: 20),
              const SizedBox(width: 8),
              const Text(
                "PILIH ROLE TUJUAN",
                style: TextStyle(
                  color: _Palette.gold,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 2,
                  fontFamily: 'Orbitron',
                  shadows: [
                    Shadow(color: Color(0xCC000000), blurRadius: 4, offset: Offset(1, 1)),
                  ],
                ),
              ),
              const Spacer(),
              Text(
                "${availableRoles.length} Tersedia",
                style: TextStyle(
                  color: _Palette.bgCreamLight.withOpacity(0.8),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 150,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: availableRoles.length,
            itemBuilder: (context, index) {
              final role = availableRoles[index];
              final price = getUpgradePrice(role);
              final isSelected = selectedTargetRole == role;

              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedTargetRole = role;
                    selectedPrice = price;
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 150,
                  margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: isSelected
                        ? const LinearGradient(
                            colors: [_Palette.redMain, _Palette.redDark],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : const LinearGradient(
                            colors: [_Palette.bgCreamLight, _Palette.bgCream],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _Palette.borderDark, width: 3),
                    boxShadow: const [
                      BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(4, 4)),
                      BoxShadow(color: Color(0x77000000), blurRadius: 12, offset: Offset(0, 6)),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: isSelected ? _Palette.gold : _Palette.redMain,
                          shape: BoxShape.circle,
                          border: Border.all(color: _Palette.borderDark, width: 2),
                        ),
                        child: Icon(
                          role == "reseller" ? Icons.storefront : Icons.handshake,
                          color: isSelected ? _Palette.redDark : _Palette.gold,
                          size: 20,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        role.toUpperCase(),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                          color: isSelected ? _Palette.white : _Palette.redDark,
                          fontFamily: 'Orbitron',
                          shadows: const [
                            Shadow(color: Color(0xCC000000), blurRadius: 3, offset: Offset(1, 1)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 6),
                      if (price != null)
                        Text(
                          NumberFormat.currency(
                            locale: 'id',
                            symbol: 'Rp ',
                            decimalDigits: 0,
                          ).format(price),
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            color: isSelected
                                ? _Palette.gold
                                : _Palette.brownMid,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GestureDetector(
            onTap: selectedTargetRole != null && selectedPrice != null && !isLoading
                ? createTopup
                : null,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_Palette.redMain, _Palette.redDark, _Palette.redDeep],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _Palette.borderDark, width: 3),
                boxShadow: const [
                  BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(4, 4)),
                  BoxShadow(color: Color(0x88000000), blurRadius: 14, offset: Offset(0, 7)),
                ],
              ),
              child: Center(
                child: isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: _Palette.gold,
                          strokeWidth: 2,
                        ),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.qr_code_scanner, color: _Palette.gold, size: 20),
                          SizedBox(width: 8),
                          Text(
                            "BAYAR VIA QRIS",
                            style: TextStyle(
                              color: _Palette.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 13,
                              letterSpacing: 2,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ─── ROLE TERTINGGI ─────────────────────────────────────────────
  Widget _buildMaxRoleState() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_Palette.bgCreamLight, _Palette.bgCream],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(4, 4)),
          BoxShadow(color: Color(0x77000000), blurRadius: 12, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [_Palette.redMain, _Palette.redDark]),
              shape: BoxShape.circle,
              border: Border.all(color: _Palette.borderDark, width: 2.5),
              boxShadow: const [
                BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(4, 4)),
              ],
            ),
            child: const Icon(Icons.workspace_premium, color: _Palette.gold, size: 44),
          ),
          const SizedBox(height: 16),
          const Text(
            "ROLE TERTINGGI",
            style: TextStyle(
              color: _Palette.redDark,
              fontSize: 17,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              fontFamily: 'Orbitron',
              shadows: [
                Shadow(color: Color(0x33000000), blurRadius: 3, offset: Offset(2, 2)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Selamat! Anda sudah berada di tingkat role paling tinggi.",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _Palette.brownMid,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  // ─── CONSOLE LOG ────────────────────────────────────────────────
  Widget _buildConsoleLog() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_Palette.brownDark, _Palette.redDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.borderDark, width: 3),
        boxShadow: const [
          BoxShadow(color: Color(0xCC000000), blurRadius: 0, offset: Offset(4, 4)),
          BoxShadow(color: Color(0x77000000), blurRadius: 12, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [_Palette.redMain, _Palette.redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(13),
                topRight: Radius.circular(13),
              ),
            ),
            child: const Row(
              children: [
                Icon(Icons.terminal, color: _Palette.gold, size: 16),
                SizedBox(width: 8),
                Text(
                  "CONSOLE LOGS",
                  style: TextStyle(
                    color: _Palette.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 11,
                    letterSpacing: 2,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 120,
            child: consoleLogs.isEmpty
                ? Center(
                    child: Text(
                      "Belum ada aktivitas transaksi...",
                      style: TextStyle(
                        color: _Palette.gold.withOpacity(0.7),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  )
                : ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.all(12),
                    itemCount: consoleLogs.length,
                    itemBuilder: (context, index) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Text(
                        consoleLogs[index],
                        style: const TextStyle(
                          color: _Palette.gold,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final availableRoles = getAvailableUpgrades();

    return Scaffold(
      backgroundColor: _Palette.brownDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_Palette.brownDark, _Palette.redDeep, _Palette.brownDark],
            stops: [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -100,
              left: 0,
              right: 0,
              child: Container(
                height: 350,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topCenter,
                    radius: 1.0,
                    colors: [
                      _Palette.redMain.withOpacity(0.15),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Positioned.fill(child: CustomPaint(painter: _GridPainter())),
            SafeArea(
              child: Column(
                children: [
                  // ── Header ─────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                  colors: [_Palette.redMain, _Palette.redDark]),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: _Palette.borderDark, width: 2.5),
                              boxShadow: const [
                                BoxShadow(color: Color(0xAA000000), blurRadius: 0, offset: Offset(3, 3)),
                              ],
                            ),
                            child: const Icon(Icons.arrow_back_ios_new_rounded,
                                color: _Palette.gold, size: 16),
                          ),
                        ),
                        const Expanded(
                          child: Text(
                            "UPGRADE ROLE",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _Palette.bgCreamLight,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                              fontFamily: 'Orbitron',
                              shadows: [
                                Shadow(color: Color(0xCC000000), blurRadius: 4, offset: Offset(2, 2)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 42),
                      ],
                    ),
                  ),

                  Expanded(
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Column(
                          children: [
                            _buildCurrentRoleCard(),
                            if (availableRoles.isNotEmpty)
                              _buildRoleOptions(availableRoles)
                            else
                              _buildMaxRoleState(),
                            _buildConsoleLog(),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// GRID PAINTER — titik coklat seperti landing
// ═══════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _Palette.brownMid.withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const double spacing = 36;
    const double radius = 1.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}