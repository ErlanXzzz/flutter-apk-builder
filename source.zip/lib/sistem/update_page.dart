import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class UpdatePage extends StatefulWidget {
  final String? currentVersion;
  final String? latestVersion;
  final String? releaseNotes;

  const UpdatePage({
    super.key,
    this.currentVersion = "1.0.0",
    this.latestVersion = "2.0.0",
    this.releaseNotes =
        "• Perbaikan bug & peningkatan performa\n• Penambahan fitur baru\n• Peningkatan keamanan sistem",
  });

  @override
  State<UpdatePage> createState() => _UpdatePageState();
}

class _UpdatePageState extends State<UpdatePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  bool _isLoading = false;

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 PALET WARNA — SAMA DENGAN LANDING
  // ═══════════════════════════════════════════════════════════════════
  static const Color bgCream      = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain      = Color(0xFFB71C1C);
  static const Color redDark      = Color(0xFF7F0000);
  static const Color redDeep      = Color(0xFF4A0000);
  static const Color brownDark    = Color(0xFF2B0E0E);
  static const Color brownMid     = Color(0xFF5D2B1F);
  static const Color gold         = Color(0xFFD4A853);
  static const Color borderDark   = Color(0xFF1A0505);
  static const Color white        = Colors.white;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _launchUpdateUrl() async {
    setState(() => _isLoading = true);

    final String updateUrl = "https://app.atlas-by-erlan.com/app-reales.app";
    final Uri url = Uri.parse(updateUrl);

    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        _showErrorSnackBar("Gagal membuka tautan pembaruan.");
      }
    } catch (e) {
      _showErrorSnackBar("Terjadi kesalahan: $e");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showErrorSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: white,
            fontWeight: FontWeight.w900,
            fontFamily: 'ShareTechMono',
          ),
        ),
        backgroundColor: redDeep,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: borderDark, width: 2.5),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: brownDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [brownDark, redDeep, brownDark],
            stops: [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // Radial glow atas
            Positioned(
              top: -100,
              left: 0,
              right: 0,
              child: Container(
                height: 350,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topCenter,
                    radius: 1.0,
                    colors: [
                      redMain.withOpacity(0.15),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Positioned.fill(child: CustomPaint(painter: _GridPainter())),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ─── ICON UPDATE 3D PULSE ───
                      AnimatedBuilder(
                        animation: _pulseController,
                        builder: (context, child) {
                          final scale = 1.0 + 0.06 * _pulseController.value;
                          return Transform.scale(
                            scale: scale,
                            child: Container(
                              width: 120,
                              height: 120,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [redMain, redDark],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                shape: BoxShape.circle,
                                border:
                                    Border.all(color: borderDark, width: 3.5),
                                boxShadow: [
                                  const BoxShadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 0,
                                    offset: Offset(5, 5),
                                  ),
                                  BoxShadow(
                                    color: gold.withOpacity(
                                        0.25 + 0.25 * _pulseController.value),
                                    blurRadius: 30,
                                    spreadRadius: 6,
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.system_update_rounded,
                                size: 56,
                                color: gold,
                              ),
                            ),
                          );
                        },
                      ),

                      const SizedBox(height: 32),

                      // ─── JUDUL 3D ───
                      ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          colors: [
                            bgCreamLight,
                            gold,
                            redMain,
                            gold,
                            bgCreamLight,
                          ],
                          stops: [0.0, 0.25, 0.5, 0.75, 1.0],
                        ).createShader(bounds),
                        child: const Text(
                          "PEMBARUAN",
                          style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 6,
                            color: Colors.white,
                            fontFamily: 'Orbitron',
                            height: 0.9,
                            shadows: [
                              Shadow(
                                color: Color(0xCC000000),
                                blurRadius: 8,
                                offset: Offset(2, 2),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        width: 120,
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              gold.withOpacity(0.9),
                              Colors.transparent,
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: gold.withOpacity(0.5),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        "Versi baru aplikasi sudah siap diunduh.",
                        style: TextStyle(
                          color: bgCreamLight.withOpacity(0.8),
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                        textAlign: TextAlign.center,
                      ),

                      const SizedBox(height: 28),

                      // ─── BADGE VERSI 3D ───
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildVersionBadge(
                            "SAAT INI",
                            widget.currentVersion ?? "1.0.0",
                            bgCream,
                            brownMid,
                          ),
                          const SizedBox(width: 10),
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: redMain,
                              shape: BoxShape.circle,
                              border: Border.all(color: borderDark, width: 2.5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xAA000000),
                                  blurRadius: 0,
                                  offset: Offset(2, 2),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.arrow_forward_rounded,
                              color: gold,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 10),
                          _buildVersionBadge(
                            "TERBARU",
                            widget.latestVersion ?? "2.0.0",
                            redMain,
                            gold,
                          ),
                        ],
                      ),

                      const SizedBox(height: 28),

                      // ─── KARTU CATATAN PEMBARUAN ───
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [bgCreamLight, bgCream],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: borderDark, width: 3),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(5, 5),
                            ),
                            BoxShadow(
                              color: Color(0x88000000),
                              blurRadius: 18,
                              offset: Offset(0, 9),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [redMain, redDark],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        color: borderDark, width: 2.5),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xAA000000),
                                        blurRadius: 0,
                                        offset: Offset(2, 2),
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.new_releases_outlined,
                                    color: gold,
                                    size: 18,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                const Text(
                                  "CATATAN PEMBARUAN",
                                  style: TextStyle(
                                    color: redDark,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.5,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            Text(
                              widget.releaseNotes ??
                                  "Perbaikan sistem dan peningkatan kinerja.",
                              style: const TextStyle(
                                color: brownMid,
                                fontSize: 12,
                                height: 1.7,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 36),

                      // ─── TOMBOL UPDATE 3D ───
                      SizedBox(
                        width: double.infinity,
                        height: 58,
                        child: GestureDetector(
                          onTap: _isLoading ? null : _launchUpdateUrl,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [redMain, redDark, redDeep],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(14),
                              border:
                                  Border.all(color: borderDark, width: 3),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(4, 4),
                                ),
                                BoxShadow(
                                  color: Color(0x88000000),
                                  blurRadius: 14,
                                  offset: Offset(0, 7),
                                ),
                              ],
                            ),
                            child: Center(
                              child: _isLoading
                                  ? const SizedBox(
                                      width: 22,
                                      height: 22,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2.5,
                                        color: gold,
                                      ),
                                    )
                                  : const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.download_rounded,
                                            size: 22, color: gold),
                                        SizedBox(width: 10),
                                        Text(
                                          "UPDATE SEKARANG",
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w900,
                                            letterSpacing: 2,
                                            color: white,
                                            fontFamily: 'Orbitron',
                                            shadows: [
                                              Shadow(
                                                color: Color(0xCC000000),
                                                blurRadius: 4,
                                                offset: Offset(1, 1),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 32),

                      Text(
                        '© 2026 ATLAS — All rights reserved',
                        style: TextStyle(
                          color: bgCreamLight.withOpacity(0.4),
                          fontSize: 10,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVersionBadge(
      String label, String version, Color bgColor, Color textColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            bgColor,
            Color.lerp(bgColor, Colors.black, 0.25)!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 9,
              color: textColor.withOpacity(0.8),
              letterSpacing: 2,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(height: 2),
          Text(
            "v$version",
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: textColor,
              fontFamily: 'Orbitron',
              shadows: const [
                Shadow(
                  color: Color(0x33000000),
                  blurRadius: 2,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// GRID PAINTER — titik coklat seperti landing
// ═══════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF5D2B1F).withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const double spacing = 36;
    const double radius = 1.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}