import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../sistem/buy_account.dart';
import 'login_page.dart';

// ═══════════════════════════════════════════════════════════════════
// 🚪 APP ENTRY POINT — LANGSUNG KE LANDING PAGE
// ═══════════════════════════════════════════════════════════════════
class AppEntryPage extends StatelessWidget {
  const AppEntryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const LandingPage();
  }
}

// ═══════════════════════════════════════════════════════════════════
// 🖼️ LANDING PAGE — ATLAS
// ═══════════════════════════════════════════════════════════════════
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;
  late AnimationController _animationController;
  late Animation<double> _logoScale;
  late Animation<Offset> _titleSlide;
  late Animation<double> _cardOpacity;
  late Animation<double> _buttonSlide;

  static const Color bgCream = Color(0xFFF5E6D3);
  static const Color bgCreamLight = Color(0xFFFFF8F0);
  static const Color redMain = Color(0xFFB71C1C);
  static const Color redDark = Color(0xFF7F0000);
  static const Color redDeep = Color(0xFF4A0000);
  static const Color brownDark = Color(0xFF2B0E0E);
  static const Color brownMid = Color(0xFF5D2B1F);
  static const Color gold = Color(0xFFD4A853);
  static const Color borderDark = Color(0xFF1A0505);
  static const Color white = Colors.white;

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset("assets/videos/landing.mp4")
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _isVideoInitialized = true);
        _videoController.setLooping(true);
        _videoController.setVolume(0);
        _videoController.play();
      }).catchError((e) {
        debugPrint("Video error: $e");
      });

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );

    _logoScale = Tween<double>(begin: 0.5, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.1, 0.5, curve: Curves.elasticOut),
      ),
    );

    _titleSlide = Tween<Offset>(begin: const Offset(0, 30), end: Offset.zero)
        .animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.3, 0.7, curve: Curves.easeOut),
      ),
    );

    _cardOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.4, 0.8, curve: Curves.easeInOut),
      ),
    );

    _buttonSlide = Tween<double>(begin: 50, end: 0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.6, 1.0, curve: Curves.easeOutBack),
      ),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _videoController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }
  
  void _goToBuyAccount() {
    Navigator.push(
      context,
      PageRouteBuilder(
       pageBuilder: (_, __, ___) => const BuyAccountPage(),
        transitionDuration: const Duration(milliseconds: 500),
        transitionsBuilder: (_, anim, __, child) {
          return FadeTransition(
            opacity: anim,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.05),
                end: Offset.zero,
              ).animate(
                CurvedAnimation(parent: anim, curve: Curves.easeOutCubic),
              ),
              child: child,
            ),
          );
        },
      ),
    );
  }

  void _goToLogin() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const LoginPage(),
        transitionDuration: const Duration(milliseconds: 500),
        transitionsBuilder: (_, anim, __, child) {
          return FadeTransition(
            opacity: anim,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.05),
                end: Offset.zero,
              ).animate(
                CurvedAnimation(parent: anim, curve: Curves.easeOutCubic),
              ),
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: brownDark,
      body: Container(
        height: screenHeight,
        child: Stack(
          children: [
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [brownDark, redDeep, brownDark],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),
            Positioned(
              top: -100,
              left: 0,
              right: 0,
              child: Container(
                height: 350,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topCenter,
                    radius: 1.0,
                    colors: [
                      redMain.withOpacity(0.15),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Positioned.fill(child: CustomPaint(painter: _GridPainter())),
            SafeArea(
              child: Center(
                child: Container(
                  constraints: BoxConstraints(
                    maxWidth: 600,
                    maxHeight: screenHeight * 0.9,
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ScaleTransition(
                          scale: _logoScale,
                          child: Container(
                            width: 320,
                            height: 180,
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [redMain, redDark],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: borderDark, width: 3),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(5, 5),
                                ),
                                BoxShadow(
                                  color: Color(0x88000000),
                                  blurRadius: 18,
                                  offset: Offset(0, 9),
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: _isVideoInitialized
                                  ? VideoPlayer(_videoController)
                                  : const Center(
                                      child: CircularProgressIndicator(
                                        color: redMain,
                                        strokeWidth: 2,
                                      ),
                                    ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 40),
                        SlideTransition(
                          position: _titleSlide,
                          child: Column(
                            children: [
                              ShaderMask(
                                shaderCallback: (bounds) =>
                                    const LinearGradient(
                                  colors: [
                                    bgCreamLight,
                                    gold,
                                    redMain,
                                    gold,
                                    bgCreamLight,
                                  ],
                                  stops: [0.0, 0.25, 0.5, 0.75, 1.0],
                                ).createShader(bounds),
                                child: const Text(
                                  "ATLAS",
                                  style: TextStyle(
                                    color: white,
                                    fontSize: 46,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 6,
                                    height: 0.9,
                                    fontFamily: 'Orbitron',
                                    shadows: [
                                      Shadow(
                                        color: Color(0xCC000000),
                                        blurRadius: 8,
                                        offset: Offset(2, 2),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Container(
                                width: 120,
                                height: 2,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.transparent,
                                      gold.withOpacity(0.8),
                                      Colors.transparent,
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(1),
                                  boxShadow: [
                                    BoxShadow(
                                      color: gold.withOpacity(0.5),
                                      blurRadius: 10,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 14),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 5),
                                decoration: BoxDecoration(
                                  color: redMain.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                      color: gold.withOpacity(0.5),
                                      width: 1.5),
                                ),
                                child: const Text(
                                  "GACOR · TERUPDATE · STABIL",
                                  style: TextStyle(
                                    color: gold,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 3,
                                    fontFamily: 'Orbitron',
                                    shadows: [
                                      Shadow(
                                        color: Color(0xCC000000),
                                        blurRadius: 4,
                                        offset: Offset(1, 1),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 40),
                        FadeTransition(
                          opacity: _cardOpacity,
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(22),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [bgCreamLight, bgCream],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(18),
                              border:
                                  Border.all(color: borderDark, width: 3.5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(5, 5),
                                ),
                                BoxShadow(
                                  color: Color(0x88000000),
                                  blurRadius: 18,
                                  offset: Offset(0, 9),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [redMain, redDark],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                        color: borderDark, width: 2.5),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xAA000000),
                                        blurRadius: 0,
                                        offset: Offset(3, 3),
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.shield_outlined,
                                    color: white,
                                    size: 24,
                                  ),
                                ),
                                const SizedBox(height: 14),
                                const Text(
                                  "ATLAS PROJECT",
                                  style: TextStyle(
                                    color: redDark,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 2,
                                    fontFamily: 'Orbitron',
                                    shadows: [
                                      Shadow(
                                        color: Color(0x33000000),
                                        blurRadius: 3,
                                        offset: Offset(2, 2),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  "Aplikasi dengan design 3D elegant dan fitur terbaru. Pengembangan langsung oleh erlan",
                                  style: TextStyle(
                                    color: brownMid,
                                    fontSize: 12,
                                    height: 1.7,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 40),
                        AnimatedBuilder(
                          animation: _buttonSlide,
                          builder: (context, child) {
                            return Transform.translate(
                              offset: Offset(0, _buttonSlide.value),
                              child: child,
                            );
                          },
                          child: Column(
                            children: [
                              _ElevatedButton(
                                onPressed: _goToLogin,
                                label: "LOGIN TO APPS",
                                icon: Icons.rocket_launch_rounded,
                              ),
                              const SizedBox(height: 14),
                              _OutlinedButton(
                                onPressed: _goToBuyAccount,
                                label: "BUY ACCOUNT",
                                icon: Icons.shopping_cart_rounded,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 40),
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [bgCreamLight, bgCream],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(16),
                            border:
                                Border.all(color: borderDark, width: 3),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xCC000000),
                                blurRadius: 0,
                                offset: Offset(4, 4),
                              ),
                              BoxShadow(
                                color: Color(0x77000000),
                                blurRadius: 12,
                                offset: Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 20,
                                    height: 2,
                                    color: redMain.withOpacity(0.6),
                                  ),
                                  const SizedBox(width: 10),
                                  const Text(
                                    "HUBUNGI KAMI",
                                    style: TextStyle(
                                      color: redDark,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 3,
                                      fontFamily: 'Orbitron',
                                      shadows: [
                                        Shadow(
                                          color: Color(0x33000000),
                                          blurRadius: 2,
                                          offset: Offset(1, 1),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Container(
                                    width: 20,
                                    height: 2,
                                    color: redMain.withOpacity(0.6),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  _SocialButton(
                                    icon: Icons.telegram,
                                    color: const Color(0xFF29B6F6),
                                    url: "https://t.me/bllackmatchaa",
                                    label: "Telegram",
                                  ),
                                  const SizedBox(width: 20),
                                  _SocialButton(
                                    icon: FontAwesomeIcons.youtube,
                                    color: const Color(0xFF00BCD4),
                                    url: "https://www.youtube.com/@ErlanOfficial-ID",
                                    label: "YouTube",
                                  ),
                                  const SizedBox(width: 20),
                                  _SocialButton(
                                    icon: Icons.music_note_rounded,
                                    color: gold,
                                    url: "https://www.tiktok.com/@LanxyzMods",
                                    label: "TikTok",
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),
                              Container(
                                height: 2,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.transparent,
                                      redMain.withOpacity(0.4),
                                      Colors.transparent,
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(height: 14),
                              Text(
                                "© 2026 ATLAS. By Erlan",
                                style: TextStyle(
                                  color: redDark.withOpacity(0.7),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// GRID PAINTER
// ═══════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF5D2B1F).withOpacity(0.35)
      ..style = PaintingStyle.fill;

    const double spacing = 36;
    const double radius = 1.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════════
// TOMBOL 3D MERAH
// ═══════════════════════════════════════════════════════════════════
class _ElevatedButton extends StatefulWidget {
  final VoidCallback onPressed;
  final String label;
  final IconData icon;

  const _ElevatedButton({
    required this.onPressed,
    required this.label,
    required this.icon,
  });

  @override
  State<_ElevatedButton> createState() => _ElevatedButtonState();
}

class _ElevatedButtonState extends State<_ElevatedButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _scale = Tween<double>(begin: 1, end: 0.97).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.reverse(),
      onTapUp: (_) {
        _controller.forward();
        widget.onPressed();
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scale.value,
            child: Container(
              height: 56,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFFB71C1C),
                    Color(0xFF7F0000),
                    Color(0xFF4A0000),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF1A0505), width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                  BoxShadow(
                    color: Color(0x88000000),
                    blurRadius: 14,
                    offset: Offset(0, 7),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: const Color(0xFF1A0505), width: 1.5),
                    ),
                    child: Icon(widget.icon,
                        color: const Color(0xFFD4A853), size: 14),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    widget.label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.5,
                      fontFamily: 'Orbitron',
                      shadows: [
                        Shadow(
                          color: Color(0xCC000000),
                          blurRadius: 3,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// TOMBOL OUTLINE 3D
// ═══════════════════════════════════════════════════════════════════
class _OutlinedButton extends StatefulWidget {
  final VoidCallback onPressed;
  final String label;
  final IconData icon;

  const _OutlinedButton({
    required this.onPressed,
    required this.label,
    required this.icon,
  });

  @override
  State<_OutlinedButton> createState() => _OutlinedButtonState();
}

class _OutlinedButtonState extends State<_OutlinedButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _scale = Tween<double>(begin: 1, end: 0.97).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.reverse(),
      onTapUp: (_) {
        _controller.forward();
        widget.onPressed();
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scale.value,
            child: Container(
              height: 56,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFFF8F0), Color(0xFFF5E6D3)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF1A0505), width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(widget.icon,
                      color: const Color(0xFF7F0000), size: 18),
                  const SizedBox(width: 12),
                  Text(
                    widget.label,
                    style: const TextStyle(
                      color: Color(0xFF7F0000),
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      fontFamily: 'Orbitron',
                      shadows: [
                        Shadow(
                          color: Color(0x22000000),
                          blurRadius: 2,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// TOMBOL SOSIAL 3D
// ═══════════════════════════════════════════════════════════════════
class _SocialButton extends StatefulWidget {
  final IconData icon;
  final Color color;
  final String url;
  final String label;

  const _SocialButton({
    required this.icon,
    required this.color,
    required this.url,
    required this.label,
  });

  @override
  State<_SocialButton> createState() => _SocialButtonState();
}

class _SocialButtonState extends State<_SocialButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _scale = Tween<double>(begin: 1, end: 1.1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _launchURL() async {
    final Uri uri = Uri.parse(widget.url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch ${widget.url}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _launchURL,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scale.value,
            child: Column(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        widget.color,
                        Color.lerp(widget.color, Colors.black, 0.4)!,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(
                      color: const Color(0xFF1A0505),
                      width: 3,
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xCC000000),
                        blurRadius: 0,
                        offset: Offset(3, 3),
                      ),
                      BoxShadow(
                        color: Color(0x66000000),
                        blurRadius: 10,
                        offset: Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Icon(widget.icon, color: Colors.white, size: 22),
                ),
                const SizedBox(height: 8),
                Text(
                  widget.label,
                  style: const TextStyle(
                    color: Color(0xFF7F0000),
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                    shadows: [
                      Shadow(
                        color: Color(0x22000000),
                        blurRadius: 2,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}