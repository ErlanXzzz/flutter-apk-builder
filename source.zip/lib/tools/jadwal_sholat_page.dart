import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════════════════════════════════
// 🔔 NOTIFICATION SERVICE
// ═══════════════════════════════════════════════════════════════════
class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(settings);

    // Minta izin notifikasi (Android 13+)
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static Future<void> showSholatNotification({
    required int id,
    required String title,
    required String body,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'sholat_channel',
      'Jadwal Sholat',
      channelDescription: 'Notifikasi waktu sholat',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _plugin.show(id, title, body, details);
  }
}

// ═══════════════════════════════════════════════════════════════════
// 🕌 JADWAL SHOLAT PAGE
// ═══════════════════════════════════════════════════════════════════
class JadwalSholatPage extends StatefulWidget {
  const JadwalSholatPage({super.key});

  @override
  State<JadwalSholatPage> createState() => _JadwalSholatPageState();
}

class _JadwalSholatPageState extends State<JadwalSholatPage> {
  // ─── STATE ───
  Map<String, String> jadwal = {};
  String nextSholat = "";
  Duration countdown = Duration.zero;
  bool loading = true;
  String idKota = "1301";
  String namaKota = "Surabaya";

  Timer? _countdownTimer;
  Timer? _notifTimer;
  final Set<String> _notifiedToday = {};

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 COLOR PALETTE
  // ═══════════════════════════════════════════════════════════════════
  static const Color bgDeep = Color(0xFF0A0E1A);
  static const Color bgPanel = Color(0xFF131829);
  static const Color bgCard = Color(0xFF1A2036);
  static const Color textMain = Color(0xFFF5F5F7);
  static const Color textSub = Color(0xFF8A93B0);
  static const Color goldAccent = Color(0xFFD4A853);
  static const Color greenAccent = Color(0xFF4CAF50);

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await NotificationService.init();
    await _loadSavedKota();
    await loadJadwal();
    _startCountdown();
    _scheduleNotifications();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _notifTimer?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // 💾 LOAD & SAVE KOTA
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _loadSavedKota() async {
    final prefs = await SharedPreferences.getInstance();
    idKota = prefs.getString('sholat_idKota') ?? '1301';
    namaKota = prefs.getString('sholat_namaKota') ?? 'Surabaya';
  }

  Future<void> _saveKota() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('sholat_idKota', idKota);
    await prefs.setString('sholat_namaKota', namaKota);
  }

  // ═══════════════════════════════════════════════════════════════════
  // 📡 LOAD JADWAL DARI API
  // ═══════════════════════════════════════════════════════════════════
  Future<void> loadJadwal() async {
    setState(() => loading = true);
    final now = DateTime.now();

    try {
      final url = Uri.parse(
        "https://api.myquran.com/v2/sholat/jadwal/$idKota/${now.year}/${now.month}/${now.day}",
      );
      final response = await http.get(url);
      final data = jsonDecode(response.body);
      final j = data["data"]["jadwal"];

      setState(() {
        jadwal = {
          "Subuh": j["subuh"],
          "Dzuhur": j["dzuhur"],
          "Ashar": j["ashar"],
          "Maghrib": j["maghrib"],
          "Isya": j["isya"],
        };
        nextSholat = getNextPrayer(jadwal);
        loading = false;
        _notifiedToday.clear();
      });
      await _saveKota();
    } catch (e) {
      debugPrint("Error: $e");
      setState(() => loading = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🕐 CARI SHOLAT BERIKUTNYA
  // ═══════════════════════════════════════════════════════════════════
  String getNextPrayer(Map<String, String> jadwal) {
    final now = TimeOfDay.now();
    for (var entry in jadwal.entries) {
      final parts = entry.value.split(":");
      final prayerTime = TimeOfDay(
        hour: int.parse(parts[0]),
        minute: int.parse(parts[1]),
      );
      if (prayerTime.hour > now.hour ||
          (prayerTime.hour == now.hour && prayerTime.minute > now.minute)) {
        return entry.key;
      }
    }
    return "Subuh";
  }

  // ═══════════════════════════════════════════════════════════════════
  // ⏱️ COUNTDOWN TIMER
  // ═══════════════════════════════════════════════════════════════════
  void _startCountdown() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;

      // Refresh kalau lewat tengah malam
      final now = DateTime.now();
      if (now.hour == 0 && now.minute == 0 && now.second == 0) {
        loadJadwal();
        _notifiedToday.clear();
      }

      setState(() {
        countdown = _hitungCountdown();
      });
    });
  }

  Duration _hitungCountdown() {
    if (jadwal.isEmpty || nextSholat.isEmpty) return Duration.zero;

    final now = DateTime.now();
    final timeStr = jadwal[nextSholat] ?? '';
    if (timeStr.isEmpty) return Duration.zero;

    final parts = timeStr.split(":");
    final target = DateTime(
      now.year,
      now.month,
      now.day,
      int.parse(parts[0]),
      int.parse(parts[1]),
    );

    // Kalau sudah lewat → besok
    if (target.isBefore(now)) {
      return target.add(const Duration(days: 1)).difference(now);
    }

    return target.difference(now);
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🔔 JADWALKAN NOTIFIKASI OTOMATIS
  // ═══════════════════════════════════════════════════════════════════
  void _scheduleNotifications() {
    _notifTimer?.cancel();
    _notifTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      final now = TimeOfDay.now();

      for (final entry in jadwal.entries) {
        final parts = entry.value.split(":");
        final sholatTime = TimeOfDay(
          hour: int.parse(parts[0]),
          minute: int.parse(parts[1]),
        );

        // Cek kalau sekarang tepat waktu sholat & belum dinotif
        final isTime =
            sholatTime.hour == now.hour && sholatTime.minute == now.minute;
        final key = "${entry.key}_${entry.value}";

        if (isTime && !_notifiedToday.contains(key)) {
          _notifiedToday.add(key);
          NotificationService.showSholatNotification(
            id: entry.key.hashCode,
            title: "🕌 Waktu ${entry.key}",
            body: "Sudah masuk waktu ${entry.key} untuk $namaKota",
          );
        }
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // 📍 MODAL CARI LOKASI
  // ═══════════════════════════════════════════════════════════════════
  void _showSearchLocation() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: bgPanel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) {
        String query = "";
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.75,
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    style: const TextStyle(color: textMain),
                    decoration: InputDecoration(
                      hintText: "Cari Kota/Kabupaten...",
                      hintStyle: const TextStyle(color: textSub),
                      prefixIcon:
                          const Icon(Icons.search, color: goldAccent),
                      filled: true,
                      fillColor: bgCard,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onChanged: (val) => setModalState(() => query = val),
                  ),
                  const SizedBox(height: 15),
                  Expanded(
                    child: FutureBuilder<List<dynamic>>(
                      future: _searchKota(query),
                      builder: (context, snapshot) {
                        if (query.length < 3) {
                          return const Center(
                            child: Text(
                              "Ketik minimal 3 huruf",
                              style: TextStyle(color: textSub),
                            ),
                          );
                        }
                        if (!snapshot.hasData) {
                          return const Center(
                            child: CircularProgressIndicator(
                                color: goldAccent),
                          );
                        }
                        if (snapshot.data!.isEmpty) {
                          return const Center(
                            child: Text(
                              "Kota tidak ditemukan",
                              style: TextStyle(color: textSub),
                            ),
                          );
                        }
                        return ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            final item = snapshot.data![index];
                            return ListTile(
                              leading: const Icon(
                                Icons.location_on,
                                color: goldAccent,
                              ),
                              title: Text(
                                item['lokasi'],
                                style: const TextStyle(color: textMain),
                              ),
                              onTap: () {
                                setState(() {
                                  idKota = item['id'];
                                  namaKota = item['lokasi'];
                                });
                                loadJadwal();
                                Navigator.pop(context);
                              },
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<List<dynamic>> _searchKota(String q) async {
    if (q.length < 3) return [];
    try {
      final res = await http.get(
        Uri.parse("https://api.myquran.com/v2/sholat/kota/cari/$q"),
      );
      return jsonDecode(res.body)['data'] ?? [];
    } catch (e) {
      return [];
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(
        child: CircularProgressIndicator(color: goldAccent),
      );
    }

    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -0.7),
          radius: 1.5,
          colors: [Color(0xFF1B2344), bgDeep, Color(0xFF05070E)],
          stops: [0.0, 0.6, 1.0],
        ),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildHeaderCard(),
            const SizedBox(height: 16),
            _buildCountdownCard(),
            const SizedBox(height: 16),
            _buildJadwalGrid(),
            const SizedBox(height: 16),
            _buildInfoCard(),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎯 HEADER CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeaderCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [bgPanel, bgCard],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: goldAccent.withOpacity(0.3), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: goldAccent.withOpacity(0.15),
            blurRadius: 30,
            spreadRadius: -5,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [goldAccent, Color(0xFFB8923A)],
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: goldAccent.withOpacity(0.5),
                  blurRadius: 16,
                  spreadRadius: -3,
                ),
              ],
            ),
            child: const Icon(Icons.mosque, color: bgDeep, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Jadwal Sholat",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.location_on,
                        color: goldAccent, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      namaKota,
                      style: const TextStyle(
                        color: textSub,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _showSearchLocation,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [goldAccent, Color(0xFFB8923A)],
                ),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: goldAccent.withOpacity(0.4),
                    blurRadius: 12,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: const Row(
                children: [
                  Icon(Icons.edit_location_alt,
                      color: bgDeep, size: 14),
                  SizedBox(width: 4),
                  Text(
                    "GANTI",
                    style: TextStyle(
                      color: bgDeep,
                      fontWeight: FontWeight.w900,
                      fontSize: 11,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ⏱️ COUNTDOWN CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildCountdownCard() {
    final h = countdown.inHours;
    final m = countdown.inMinutes % 60;
    final s = countdown.inSeconds % 60;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1E2742), Color(0xFF131829)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: greenAccent.withOpacity(0.4), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: greenAccent.withOpacity(0.2),
            blurRadius: 30,
            spreadRadius: -5,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: greenAccent,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: greenAccent,
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                "MENUJU ${nextSholat.toUpperCase()}",
                style: const TextStyle(
                  color: textSub,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildTimeBox(h.toString().padLeft(2, '0'), "JAM"),
              const SizedBox(width: 8),
              _buildTimeBox(m.toString().padLeft(2, '0'), "MENIT"),
              const SizedBox(width: 8),
              _buildTimeBox(s.toString().padLeft(2, '0'), "DETIK"),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            "Pukul ${jadwal[nextSholat] ?? '--:--'} WIB",
            style: const TextStyle(
              color: goldAccent,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimeBox(String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [bgCard, Color(0xFF0E1424)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: goldAccent.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              color: textMain,
              fontSize: 32,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
              shadows: [
                Shadow(color: Color(0xAAFFD700), blurRadius: 12),
              ],
            ),
          ),
          Text(
            label,
            style: const TextStyle(
              color: textSub,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 📅 JADWAL GRID
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildJadwalGrid() {
    final gradients = {
      "Subuh": [const Color(0xFF1A237E), const Color(0xFF283593)],
      "Dzuhur": [const Color(0xFFE65100), const Color(0xFFFF6F00)],
      "Ashar": [const Color(0xFFB71C1C), const Color(0xFFC62828)],
      "Maghrib": [const Color(0xFF4A148C), const Color(0xFF6A1B9A)],
      "Isya": [const Color(0xFF263238), const Color(0xFF37474F)],
    };

    final icons = {
      "Subuh": Icons.wb_twilight,
      "Dzuhur": Icons.wb_sunny,
      "Ashar": Icons.wb_sunny_outlined,
      "Maghrib": Icons.wb_twilight,
      "Isya": Icons.nights_stay,
    };

    return Column(
      children: jadwal.entries.map((entry) {
        final isNext = entry.key == nextSholat;
        final colors = gradients[entry.key]!;
        final icon = icons[entry.key]!;

        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isNext
                  ? [goldAccent, const Color(0xFFB8923A)]
                  : colors,
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: isNext
                  ? goldAccent
                  : Colors.white.withOpacity(0.1),
              width: isNext ? 2 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: isNext
                    ? goldAccent.withOpacity(0.5)
                    : Colors.black.withOpacity(0.4),
                blurRadius: isNext ? 24 : 12,
                spreadRadius: isNext ? -2 : -3,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: isNext
                      ? bgDeep.withOpacity(0.25)
                      : Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  color: isNext ? bgDeep : textMain,
                  size: 22,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          entry.key.toUpperCase(),
                          style: TextStyle(
                            color: isNext ? bgDeep : textMain,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                          ),
                        ),
                        if (isNext) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: bgDeep,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              "NEXT",
                              style: TextStyle(
                                color: goldAccent,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      isNext ? "Segera masuk waktu sholat" : "—",
                      style: TextStyle(
                        color: isNext
                            ? bgDeep.withOpacity(0.7)
                            : textMain.withOpacity(0.5),
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                entry.value,
                style: TextStyle(
                  color: isNext ? bgDeep : textMain,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                  shadows: isNext
                      ? null
                      : [
                          Shadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 6,
                          ),
                        ],
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ℹ️ INFO CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgPanel.withOpacity(0.6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: textSub.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: goldAccent, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "Jadwal akan otomatis diperbarui setiap hari.\nNotifikasi aktif saat masuk waktu sholat.",
              style: TextStyle(
                color: textSub,
                fontSize: 11,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}