// lib/tools_gateway.dart
import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'FreeFireLagServer.dart';
import 'hentai_page.dart' as hentai;
import 'alquran_page.dart';
import 'erlantrader_trader.dart';
import 'jadwal_sholat_page.dart';
import 'kamus_jepang_page.dart';
import 'iqc.dart';
import 'testfunc.dart';
import 'japanese_quiz_page.dart'; // ⭐ KUIS JEPANG

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;
  final String expiredDate;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.username,
    required this.expiredDate,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  VideoPlayerController? _videoController;
  bool _videoReady = false;
  bool _muted = false;

  static const Color _redMain      = Color(0xFFB71C1C);
  static const Color _redDark      = Color(0xFF7F0000);
  static const Color _redDeep      = Color(0xFF4A0000);
  static const Color _brownDark    = Color(0xFF2B0E0E);
  static const Color _brownMid     = Color(0xFF5D2B1F);
  static const Color _cream        = Color(0xFFF5E6D3);
  static const Color _creamLight   = Color(0xFFFFF8F0);
  static const Color _gold         = Color(0xFFD4A853);
  static const Color _textDark     = Color(0xFF1A0A0A);
  static const Color _borderDark   = Color(0xFF1A0505);
  static const Color _white        = Colors.white;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  Future<void> _initVideo() async {
    try {
      _videoController = VideoPlayerController.asset(
        'assets/videos/tools_bg.mp4',
      );
      await _videoController!.initialize();
      if (!mounted) return;
      setState(() => _videoReady = true);
      _videoController!.setLooping(true);
      _videoController!.setVolume(0.6);
      _videoController!.play();
    } catch (e) {
      debugPrint("Video bg error: $e");
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }

  void _toggleMute() {
    if (_videoController == null || !_videoController!.value.isInitialized) {
      return;
    }
    setState(() {
      _muted = !_muted;
      _videoController!.setVolume(_muted ? 0.0 : 0.6);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _brownDark,
      body: Stack(
        children: [
          if (_videoReady && _videoController != null)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              ),
            )
          else
            Positioned.fill(child: Container(color: _brownDark)),

          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _brownDark.withOpacity(0.75),
                    _redDeep.withOpacity(0.70),
                    _brownDark.withOpacity(0.85),
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ),
              ),
            ),
          ),

          SafeArea(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              children: [
                Row(
                  children: [
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [_redMain, _redDark],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _borderDark, width: 2.5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 0,
                                  offset: Offset(3, 3),
                                ),
                                BoxShadow(
                                  color: Color(0x88000000),
                                  blurRadius: 12,
                                  offset: Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Text(
                              "TOOLS DASHBOARD",
                              style: TextStyle(
                                color: _white,
                                fontSize: 18,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                                shadows: [
                                  Shadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 4,
                                    offset: Offset(2, 2),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Advanced Security & OSINT Tools",
                            style: TextStyle(
                              color: _gold.withOpacity(0.9),
                              fontSize: 12,
                              fontFamily: 'ShareTechMono',
                              fontWeight: FontWeight.w600,
                              shadows: const [
                                Shadow(
                                  color: Color(0xCC000000),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: _toggleMute,
                      child: Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [_redMain, _redDark],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          shape: BoxShape.circle,
                          border: Border.all(color: _borderDark, width: 2.5),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0xCC000000),
                              blurRadius: 0,
                              offset: Offset(2, 3),
                            ),
                            BoxShadow(
                              color: Color(0x66000000),
                              blurRadius: 10,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Icon(
                          _muted
                              ? Icons.volume_off_rounded
                              : Icons.volume_up_rounded,
                          color: _white,
                          size: 22,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 30),

                // ═══════════════════════════════════════════════════
                // CREATIVE
                // ═══════════════════════════════════════════════════
                _buildCategoryTile(
                  context: context,
                  icon: Icons.auto_awesome_rounded,
                  title: "Creative",
                  subtitle: "Design & Generator",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.phone_iphone_rounded,
                      label: "iPhone Quote Chat",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const IQCScreen(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // ═══════════════════════════════════════════════════
                // DEVELOPER
                // ═══════════════════════════════════════════════════
                _buildCategoryTile(
                  context: context,
                  icon: Icons.terminal_rounded,
                  title: "Developer",
                  subtitle: "Testing & Debug",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.code_rounded,
                      label: "Test Function",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => TestFunctionPage(
                              sessionKey: widget.sessionKey,
                              username: widget.username,
                              role: widget.userRole,
                              expiredDate: widget.expiredDate,
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                _buildCategoryTile(
                  context: context,
                  icon: Icons.flash_on,
                  title: "DDoS Tools",
                  subtitle: "Attack & Server",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: FontAwesomeIcons.fire,
                      label: "Lag Free Fire",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const FreeFireLagServerPage(),
                          ),
                        );
                      },
                    ),
                    _buildToolItem(
                      context: context,
                      icon: Icons.flash_on,
                      label: "Attack Panel",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AttackPanel(
                              sessionKey: widget.sessionKey,
                              listDoos: widget.listDoos,
                            ),
                          ),
                        );
                      },
                    ),
                    _buildToolItem(
                      context: context,
                      icon: Icons.dns,
                      label: "Manage Server",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ManageServerPage(
                                keyToken: widget.sessionKey),
                          ),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                _buildCategoryTile(
                  context: context,
                  icon: Icons.wifi,
                  title: "Network",
                  subtitle: "WiFi & Ddos",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.newspaper_outlined,
                      label: "Spam NGL",
                      onTap: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => NglPage()));
                      },
                    ),
                    _buildToolItem(
                      context: context,
                      icon: Icons.wifi_off,
                      label: "WiFi Killer (Internal)",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => WifiKillerPage()),
                        );
                      },
                    ),
                    if (widget.userRole == "partner" ||
                        widget.userRole == "pemula")
                      _buildToolItem(
                        context: context,
                        icon: Icons.router,
                        label: "WiFi Killer (External)",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => WifiInternalPage(
                                  sessionKey: widget.sessionKey),
                            ),
                          );
                        },
                      ),
                  ],
                ),
                const SizedBox(height: 14),

                _buildCategoryTile(
                  context: context,
                  icon: Icons.search,
                  title: "OSINT",
                  subtitle: "Investigation",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.badge,
                      label: "NIK Detail",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const NikCheckerPage()),
                        );
                      },
                    ),
                    _buildToolItem(
                      context: context,
                      icon: Icons.domain,
                      label: "Domain OSINT",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const DomainOsintPage()),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                _buildCategoryTile(
                  context: context,
                  icon: Icons.download,
                  title: "Downloader",
                  subtitle: "Social Media",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.video_library,
                      label: "TikTok Downloader",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  const TiktokDownloaderPage()),
                        );
                      },
                    ),
                    _buildToolItem(
                      context: context,
                      icon: Icons.camera_alt,
                      label: "Instagram Downloader",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  const InstagramDownloaderPage()),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                _buildCategoryTile(
                  context: context,
                  icon: Icons.build,
                  title: "Utilities",
                  subtitle: "Extra Tools",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.qr_code,
                      label: "QR Generator",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const QrGeneratorPage()),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                _buildCategoryTile(
                  context: context,
                  icon: Icons.candlestick_chart,
                  title: "Trading",
                  subtitle: "Market Simulation",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.show_chart,
                      label: "Atlas Trader (MT5-Style)",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const NoMercyTraderApp(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                _buildCategoryTile(
                  context: context,
                  icon: Icons.movie_filter,
                  title: "Watch",
                  subtitle: "Entertainment & Media",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.live_tv,
                      label: "Anime Streaming",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const HomeAnimePage()),
                        );
                      },
                    ),
                    _buildToolItem(
                      context: context,
                      icon: Icons.local_fire_department,
                      label: "Hentai Media",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const hentai.HomeScreen()),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                _buildCategoryTile(
                  context: context,
                  icon: Icons.mosque,
                  title: "Islamic",
                  subtitle: "Religious & Spiritual",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.menu_book,
                      label: "Al-Qur'an Digital",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AlquranPage(),
                          ),
                        );
                      },
                    ),
                    _buildToolItem(
                      context: context,
                      icon: Icons.access_time,
                      label: "Jadwal Sholat",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const JadwalSholatPage(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // ═══════════════════════════════════════════════════
                // ⭐ LEARNING — KAMUS + KUIS JEPANG (FIX BUILD ERROR) ⭐
                // ═══════════════════════════════════════════════════
                _buildCategoryTile(
                  context: context,
                  icon: Icons.translate,
                  title: "Learning",
                  subtitle: "Language & Education",
                  children: [
                    _buildToolItem(
                      context: context,
                      icon: Icons.menu_book,
                      label: "Kamus Bahasa Jepang",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const KamusJepangPage(),
                          ),
                        );
                      },
                    ),
                    // ⭐ KUIS JEPANG — PAKAI QuizMenuPage (nama class asli) ⭐
                    _buildToolItem(
                      context: context,
                      icon: Icons.quiz_rounded,
                      label: "Kuis Hiragana & Katakana",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const QuizMenuPage(),
                          ),
                        );
                      },
                    ),
                    // ⭐ END ⭐
                  ],
                ),

                const SizedBox(height: 40),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryTile({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _cream,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderDark, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xCC000000),
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: Color(0x88000000),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () =>
              _showCategoryDialog(context, icon, title, subtitle, children),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_redMain, _redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _borderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xAA000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Icon(icon, color: _white, size: 22),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: _redDark,
                          fontSize: 16,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                          shadows: [
                            Shadow(
                              color: Color(0x22000000),
                              blurRadius: 2,
                              offset: Offset(1, 1),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: _brownMid.withOpacity(0.9),
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: _redMain,
                    shape: BoxShape.circle,
                    border: Border.all(color: _borderDark, width: 1.5),
                  ),
                  child: const Icon(
                    Icons.arrow_forward_ios,
                    color: _white,
                    size: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showCategoryDialog(
    BuildContext context,
    IconData icon,
    String title,
    String subtitle,
    List<Widget> children,
  ) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (BuildContext ctx) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: _cream,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _borderDark, width: 3.5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xCC000000),
                    blurRadius: 0,
                    offset: Offset(6, 6),
                  ),
                  BoxShadow(
                    color: Color(0xAA000000),
                    blurRadius: 24,
                    offset: Offset(0, 12),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [_redMain, _redDark],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(color: _borderDark, width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xAA000000),
                          blurRadius: 0,
                          offset: Offset(3, 3),
                        ),
                        BoxShadow(
                          color: Color(0x66000000),
                          blurRadius: 12,
                          offset: Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Icon(icon, color: _white, size: 34),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    title,
                    style: const TextStyle(
                      color: _redDark,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                      shadows: [
                        Shadow(
                          color: Color(0x33000000),
                          blurRadius: 3,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: _brownMid.withOpacity(0.85),
                      fontSize: 13,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 22),
                  ...children,
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildToolItem({
    required BuildContext context,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _creamLight,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _borderDark, width: 2.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0xAA000000),
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_redMain, _redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _borderDark, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x99000000),
                        blurRadius: 0,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Icon(icon, color: _white, size: 16),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    label,
                    style: const TextStyle(
                      color: _textDark,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: _redMain.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _redMain.withOpacity(0.4),
                      width: 1.2,
                    ),
                  ),
                  child: const Icon(
                    Icons.arrow_forward_ios,
                    color: _redMain,
                    size: 10,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}