import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════════════════════════════════
// 🎨 DARK NAVY + PINK THEME
// ═══════════════════════════════════════════════════════════════════
const Color bgDeep = Color(0xFF0A0E1A);
const Color bgPanel = Color(0xFF131829);
const Color bgCard = Color(0xFF1A2036);
const Color bgOption = Color(0xFF1E2742);
const Color textMain = Color(0xFFF5F5F7);
const Color textSub = Color(0xFF8A93B0);
const Color pinkAccent = Color(0xFFE91E63);
const Color blueAccent = Color(0xFF29B6F6);
const Color successColor = Color(0xFF35C77A);
const Color errorColor = Color(0xFFE7473A);
const Color heartColor = Color(0xFFFF4D8D);
const Color purpleAccent = Color(0xFFAB47BC);

// ═══════════════════════════════════════════════════════════════════
// 📚 DATA MODEL
// ═══════════════════════════════════════════════════════════════════
class KanaItem {
  final String kana;
  final String romaji;
  final String type; // 'hiragana' / 'katakana'
  const KanaItem(this.kana, this.romaji, this.type);
}

// ═══════════════════════════════════════════════════════════════════
// 🎴 HIRAGANA (104 karakter)
// ═══════════════════════════════════════════════════════════════════
const List<KanaItem> hiraganaList = [
  // Basic (46)
  KanaItem('あ', 'a', 'hiragana'),
  KanaItem('い', 'i', 'hiragana'),
  KanaItem('う', 'u', 'hiragana'),
  KanaItem('え', 'e', 'hiragana'),
  KanaItem('お', 'o', 'hiragana'),
  KanaItem('か', 'ka', 'hiragana'),
  KanaItem('き', 'ki', 'hiragana'),
  KanaItem('く', 'ku', 'hiragana'),
  KanaItem('け', 'ke', 'hiragana'),
  KanaItem('こ', 'ko', 'hiragana'),
  KanaItem('さ', 'sa', 'hiragana'),
  KanaItem('し', 'shi', 'hiragana'),
  KanaItem('す', 'su', 'hiragana'),
  KanaItem('せ', 'se', 'hiragana'),
  KanaItem('そ', 'so', 'hiragana'),
  KanaItem('た', 'ta', 'hiragana'),
  KanaItem('ち', 'chi', 'hiragana'),
  KanaItem('つ', 'tsu', 'hiragana'),
  KanaItem('て', 'te', 'hiragana'),
  KanaItem('と', 'to', 'hiragana'),
  KanaItem('な', 'na', 'hiragana'),
  KanaItem('に', 'ni', 'hiragana'),
  KanaItem('ぬ', 'nu', 'hiragana'),
  KanaItem('ね', 'ne', 'hiragana'),
  KanaItem('の', 'no', 'hiragana'),
  KanaItem('は', 'ha', 'hiragana'),
  KanaItem('ひ', 'hi', 'hiragana'),
  KanaItem('ふ', 'fu', 'hiragana'),
  KanaItem('へ', 'he', 'hiragana'),
  KanaItem('ほ', 'ho', 'hiragana'),
  KanaItem('ま', 'ma', 'hiragana'),
  KanaItem('み', 'mi', 'hiragana'),
  KanaItem('む', 'mu', 'hiragana'),
  KanaItem('め', 'me', 'hiragana'),
  KanaItem('も', 'mo', 'hiragana'),
  KanaItem('や', 'ya', 'hiragana'),
  KanaItem('ゆ', 'yu', 'hiragana'),
  KanaItem('よ', 'yo', 'hiragana'),
  KanaItem('ら', 'ra', 'hiragana'),
  KanaItem('り', 'ri', 'hiragana'),
  KanaItem('る', 'ru', 'hiragana'),
  KanaItem('れ', 're', 'hiragana'),
  KanaItem('ろ', 'ro', 'hiragana'),
  KanaItem('わ', 'wa', 'hiragana'),
  KanaItem('を', 'wo', 'hiragana'),
  KanaItem('ん', 'n', 'hiragana'),
  // Dakuten (20)
  KanaItem('が', 'ga', 'hiragana'),
  KanaItem('ぎ', 'gi', 'hiragana'),
  KanaItem('ぐ', 'gu', 'hiragana'),
  KanaItem('げ', 'ge', 'hiragana'),
  KanaItem('ご', 'go', 'hiragana'),
  KanaItem('ざ', 'za', 'hiragana'),
  KanaItem('じ', 'ji', 'hiragana'),
  KanaItem('ず', 'zu', 'hiragana'),
  KanaItem('ぜ', 'ze', 'hiragana'),
  KanaItem('ぞ', 'zo', 'hiragana'),
  KanaItem('だ', 'da', 'hiragana'),
  KanaItem('ぢ', 'ji', 'hiragana'),
  KanaItem('づ', 'zu', 'hiragana'),
  KanaItem('で', 'de', 'hiragana'),
  KanaItem('ど', 'do', 'hiragana'),
  KanaItem('ば', 'ba', 'hiragana'),
  KanaItem('び', 'bi', 'hiragana'),
  KanaItem('ぶ', 'bu', 'hiragana'),
  KanaItem('べ', 'be', 'hiragana'),
  KanaItem('ぼ', 'bo', 'hiragana'),
  // Handakuten (5)
  KanaItem('ぱ', 'pa', 'hiragana'),
  KanaItem('ぴ', 'pi', 'hiragana'),
  KanaItem('ぷ', 'pu', 'hiragana'),
  KanaItem('ぺ', 'pe', 'hiragana'),
  KanaItem('ぽ', 'po', 'hiragana'),
  // Youon (33)
  KanaItem('きゃ', 'kya', 'hiragana'),
  KanaItem('きゅ', 'kyu', 'hiragana'),
  KanaItem('きょ', 'kyo', 'hiragana'),
  KanaItem('しゃ', 'sha', 'hiragana'),
  KanaItem('しゅ', 'shu', 'hiragana'),
  KanaItem('しょ', 'sho', 'hiragana'),
  KanaItem('ちゃ', 'cha', 'hiragana'),
  KanaItem('ちゅ', 'chu', 'hiragana'),
  KanaItem('ちょ', 'cho', 'hiragana'),
  KanaItem('にゃ', 'nya', 'hiragana'),
  KanaItem('にゅ', 'nyu', 'hiragana'),
  KanaItem('にょ', 'nyo', 'hiragana'),
  KanaItem('ひゃ', 'hya', 'hiragana'),
  KanaItem('ひゅ', 'hyu', 'hiragana'),
  KanaItem('ひょ', 'hyo', 'hiragana'),
  KanaItem('みゃ', 'mya', 'hiragana'),
  KanaItem('みゅ', 'myu', 'hiragana'),
  KanaItem('みょ', 'myo', 'hiragana'),
  KanaItem('りゃ', 'rya', 'hiragana'),
  KanaItem('りゅ', 'ryu', 'hiragana'),
  KanaItem('りょ', 'ryo', 'hiragana'),
  KanaItem('ぎゃ', 'gya', 'hiragana'),
  KanaItem('ぎゅ', 'gyu', 'hiragana'),
  KanaItem('ぎょ', 'gyo', 'hiragana'),
  KanaItem('じゃ', 'ja', 'hiragana'),
  KanaItem('じゅ', 'ju', 'hiragana'),
  KanaItem('じょ', 'jo', 'hiragana'),
  KanaItem('びゃ', 'bya', 'hiragana'),
  KanaItem('びゅ', 'byu', 'hiragana'),
  KanaItem('びょ', 'byo', 'hiragana'),
  KanaItem('ぴゃ', 'pya', 'hiragana'),
  KanaItem('ぴゅ', 'pyu', 'hiragana'),
  KanaItem('ぴょ', 'pyo', 'hiragana'),
];

// ═══════════════════════════════════════════════════════════════════
// 🎴 KATAKANA (104 karakter)
// ═══════════════════════════════════════════════════════════════════
const List<KanaItem> katakanaList = [
  // Basic (46)
  KanaItem('ア', 'a', 'katakana'),
  KanaItem('イ', 'i', 'katakana'),
  KanaItem('ウ', 'u', 'katakana'),
  KanaItem('エ', 'e', 'katakana'),
  KanaItem('オ', 'o', 'katakana'),
  KanaItem('カ', 'ka', 'katakana'),
  KanaItem('キ', 'ki', 'katakana'),
  KanaItem('ク', 'ku', 'katakana'),
  KanaItem('ケ', 'ke', 'katakana'),
  KanaItem('コ', 'ko', 'katakana'),
  KanaItem('サ', 'sa', 'katakana'),
  KanaItem('シ', 'shi', 'katakana'),
  KanaItem('ス', 'su', 'katakana'),
  KanaItem('セ', 'se', 'katakana'),
  KanaItem('ソ', 'so', 'katakana'),
  KanaItem('タ', 'ta', 'katakana'),
  KanaItem('チ', 'chi', 'katakana'),
  KanaItem('ツ', 'tsu', 'katakana'),
  KanaItem('テ', 'te', 'katakana'),
  KanaItem('ト', 'to', 'katakana'),
  KanaItem('ナ', 'na', 'katakana'),
  KanaItem('ニ', 'ni', 'katakana'),
  KanaItem('ヌ', 'nu', 'katakana'),
  KanaItem('ネ', 'ne', 'katakana'),
  KanaItem('ノ', 'no', 'katakana'),
  KanaItem('ハ', 'ha', 'katakana'),
  KanaItem('ヒ', 'hi', 'katakana'),
  KanaItem('フ', 'fu', 'katakana'),
  KanaItem('ヘ', 'he', 'katakana'),
  KanaItem('ホ', 'ho', 'katakana'),
  KanaItem('マ', 'ma', 'katakana'),
  KanaItem('ミ', 'mi', 'katakana'),
  KanaItem('ム', 'mu', 'katakana'),
  KanaItem('メ', 'me', 'katakana'),
  KanaItem('モ', 'mo', 'katakana'),
  KanaItem('ヤ', 'ya', 'katakana'),
  KanaItem('ユ', 'yu', 'katakana'),
  KanaItem('ヨ', 'yo', 'katakana'),
  KanaItem('ラ', 'ra', 'katakana'),
  KanaItem('リ', 'ri', 'katakana'),
  KanaItem('ル', 'ru', 'katakana'),
  KanaItem('レ', 're', 'katakana'),
  KanaItem('ロ', 'ro', 'katakana'),
  KanaItem('ワ', 'wa', 'katakana'),
  KanaItem('ヲ', 'wo', 'katakana'),
  KanaItem('ン', 'n', 'katakana'),
  // Dakuten (20)
  KanaItem('ガ', 'ga', 'katakana'),
  KanaItem('ギ', 'gi', 'katakana'),
  KanaItem('グ', 'gu', 'katakana'),
  KanaItem('ゲ', 'ge', 'katakana'),
  KanaItem('ゴ', 'go', 'katakana'),
  KanaItem('ザ', 'za', 'katakana'),
  KanaItem('ジ', 'ji', 'katakana'),
  KanaItem('ズ', 'zu', 'katakana'),
  KanaItem('ゼ', 'ze', 'katakana'),
  KanaItem('ゾ', 'zo', 'katakana'),
  KanaItem('ダ', 'da', 'katakana'),
  KanaItem('ヂ', 'ji', 'katakana'),
  KanaItem('ヅ', 'zu', 'katakana'),
  KanaItem('デ', 'de', 'katakana'),
  KanaItem('ド', 'do', 'katakana'),
  KanaItem('バ', 'ba', 'katakana'),
  KanaItem('ビ', 'bi', 'katakana'),
  KanaItem('ブ', 'bu', 'katakana'),
  KanaItem('ベ', 'be', 'katakana'),
  KanaItem('ボ', 'bo', 'katakana'),
  // Handakuten (5)
  KanaItem('パ', 'pa', 'katakana'),
  KanaItem('ピ', 'pi', 'katakana'),
  KanaItem('プ', 'pu', 'katakana'),
  KanaItem('ペ', 'pe', 'katakana'),
  KanaItem('ポ', 'po', 'katakana'),
  // Youon (33)
  KanaItem('キャ', 'kya', 'katakana'),
  KanaItem('キュ', 'kyu', 'katakana'),
  KanaItem('キョ', 'kyo', 'katakana'),
  KanaItem('シャ', 'sha', 'katakana'),
  KanaItem('シュ', 'shu', 'katakana'),
  KanaItem('ショ', 'sho', 'katakana'),
  KanaItem('チャ', 'cha', 'katakana'),
  KanaItem('チュ', 'chu', 'katakana'),
  KanaItem('チョ', 'cho', 'katakana'),
  KanaItem('ニャ', 'nya', 'katakana'),
  KanaItem('ニュ', 'nyu', 'katakana'),
  KanaItem('ニョ', 'nyo', 'katakana'),
  KanaItem('ヒャ', 'hya', 'katakana'),
  KanaItem('ヒュ', 'hyu', 'katakana'),
  KanaItem('ヒョ', 'hyo', 'katakana'),
  KanaItem('ミャ', 'mya', 'katakana'),
  KanaItem('ミュ', 'myu', 'katakana'),
  KanaItem('ミョ', 'myo', 'katakana'),
  KanaItem('リャ', 'rya', 'katakana'),
  KanaItem('リュ', 'ryu', 'katakana'),
  KanaItem('リョ', 'ryo', 'katakana'),
  KanaItem('ギャ', 'gya', 'katakana'),
  KanaItem('ギュ', 'gyu', 'katakana'),
  KanaItem('ギョ', 'gyo', 'katakana'),
  KanaItem('ジャ', 'ja', 'katakana'),
  KanaItem('ジュ', 'ju', 'katakana'),
  KanaItem('ジョ', 'jo', 'katakana'),
  KanaItem('ビャ', 'bya', 'katakana'),
  KanaItem('ビュ', 'byu', 'katakana'),
  KanaItem('ビョ', 'byo', 'katakana'),
  KanaItem('ピャ', 'pya', 'katakana'),
  KanaItem('ピュ', 'pyu', 'katakana'),
  KanaItem('ピョ', 'pyo', 'katakana'),
];

// ═══════════════════════════════════════════════════════════════════
// 🎮 ENUM MODE
// ═══════════════════════════════════════════════════════════════════
enum QuizMode { hiragana, katakana, mixed }

// ═══════════════════════════════════════════════════════════════════
// 🚪 MODE SELECTION SCREEN
// ═══════════════════════════════════════════════════════════════════
class QuizMenuPage extends StatefulWidget {
  const QuizMenuPage({super.key});

  @override
  State<QuizMenuPage> createState() => _QuizMenuPageState();
}

class _QuizMenuPageState extends State<QuizMenuPage> {
  int _highScoreHiragana = 0;
  int _highScoreKatakana = 0;
  int _highScoreMixed = 0;

  @override
  void initState() {
    super.initState();
    _loadHighScores();
  }

  Future<void> _loadHighScores() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _highScoreHiragana = prefs.getInt('hs_hiragana') ?? 0;
      _highScoreKatakana = prefs.getInt('hs_katakana') ?? 0;
      _highScoreMixed = prefs.getInt('hs_mixed') ?? 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDeep,
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.7),
            radius: 1.5,
            colors: [Color(0xFF1B2344), bgDeep, Color(0xFF05070E)],
            stops: [0.0, 0.6, 1.0],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const SizedBox(height: 20),

                // ─── TITLE ───
                Text(
                  "あ ア か カ",
                  style: TextStyle(
                    color: pinkAccent.withOpacity(0.9),
                    fontSize: 28,
                    fontWeight: FontWeight.w300,
                    letterSpacing: 8,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "KUIS JEPANG",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Hiragana • Katakana",
                  style: TextStyle(
                    color: textSub,
                    fontSize: 13,
                    letterSpacing: 2,
                  ),
                ),

                const SizedBox(height: 40),

                // ─── MODE CARDS ───
                _buildModeCard(
                  title: "HIRAGANA",
                  subtitle: "ひらがな",
                  description: "104 karakter dasar Jepang",
                  emoji: "🌸",
                  color: pinkAccent,
                  highScore: _highScoreHiragana,
                  onTap: () => _openQuiz(QuizMode.hiragana),
                ),
                const SizedBox(height: 16),
                _buildModeCard(
                  title: "KATAKANA",
                  subtitle: "カタカナ",
                  description: "104 karakter untuk kata serapan",
                  emoji: "⚡",
                  color: blueAccent,
                  highScore: _highScoreKatakana,
                  onTap: () => _openQuiz(QuizMode.katakana),
                ),
                const SizedBox(height: 16),
                _buildModeCard(
                  title: "CAMPURAN",
                  subtitle: "ミックス",
                  description: "Hiragana + Katakana sekaligus",
                  emoji: "🎯",
                  color: purpleAccent,
                  highScore: _highScoreMixed,
                  onTap: () => _openQuiz(QuizMode.mixed),
                ),

                const SizedBox(height: 32),

                // ─── STATS ───
                _buildStatsCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _openQuiz(QuizMode mode) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => JapaneseQuizPage(mode: mode),
      ),
    );
    _loadHighScores();
  }

  Widget _buildModeCard({
    required String title,
    required String subtitle,
    required String description,
    required String emoji,
    required Color color,
    required int highScore,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [bgPanel, bgCard],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: color.withOpacity(0.25),
              blurRadius: 24,
              spreadRadius: -4,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [color.withOpacity(0.35), color.withOpacity(0.1)],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: color.withOpacity(0.6)),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.4),
                    blurRadius: 16,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: Center(
                child: Text(emoji, style: const TextStyle(fontSize: 28)),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: color,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: color.withOpacity(0.7),
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: TextStyle(color: textSub, fontSize: 11),
                  ),
                  if (highScore > 0) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.emoji_events, color: Color(0xFFFFD54F), size: 14),
                        const SizedBox(width: 4),
                        Text(
                          "High Score: $highScore",
                          style: TextStyle(
                            color: const Color(0xFFFFD54F),
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: color, size: 28),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsCard() {
    final total = hiraganaList.length + katakanaList.length;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgPanel,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: textSub.withOpacity(0.15)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _statItem("📖", "${hiraganaList.length}", "Hiragana"),
          Container(width: 1, height: 30, color: textSub.withOpacity(0.2)),
          _statItem("📕", "${katakanaList.length}", "Katakana"),
          Container(width: 1, height: 30, color: textSub.withOpacity(0.2)),
          _statItem("📚", "$total", "Total"),
        ],
      ),
    );
  }

  Widget _statItem(String emoji, String value, String label) {
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: textMain,
            fontSize: 16,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
          ),
        ),
        Text(label, style: TextStyle(color: textSub, fontSize: 10)),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// 🎮 MAIN QUIZ PAGE
// ═══════════════════════════════════════════════════════════════════
class JapaneseQuizPage extends StatefulWidget {
  final QuizMode mode;
  final int totalQuestions;
  final int secondsPerQuestion;
  final int maxLives;

  const JapaneseQuizPage({
    super.key,
    required this.mode,
    this.totalQuestions = 10,
    this.secondsPerQuestion = 10,
    this.maxLives = 3,
  });

  @override
  State<JapaneseQuizPage> createState() => _JapaneseQuizPageState();
}

class _JapaneseQuizPageState extends State<JapaneseQuizPage> {
  // ─── STATE ───
  late List<KanaItem> _quizPool;
  late List<List<String>> _options;
  late List<String> _correctAnswer;

  int _currentIndex = 0;
  int _score = 0;
  int _lives = 3;
  int _secondsLeft = 10;
  int _comboCount = 0;
  int _bestCombo = 0;

  Timer? _timer;

  int? _selectedIndex;
  bool _isAnswered = false;
  bool _isGameOver = false;
  bool _isWon = false;

  // ─── MODE HELPER ───
  List<KanaItem> get _sourceList {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return hiraganaList;
      case QuizMode.katakana:
        return katakanaList;
      case QuizMode.mixed:
        return [...hiraganaList, ...katakanaList];
    }
  }

  Color get _accentColor {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return pinkAccent;
      case QuizMode.katakana:
        return blueAccent;
      case QuizMode.mixed:
        return purpleAccent;
    }
  }

  String get _modeLabel {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return "HIRAGANA";
      case QuizMode.katakana:
        return "KATAKANA";
      case QuizMode.mixed:
        return "CAMPURAN";
    }
  }

  String get _modeSub {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return "ひらがな";
      case QuizMode.katakana:
        return "カタカナ";
      case QuizMode.mixed:
        return "ミックス";
    }
  }

  String get _prefsKey {
    switch (widget.mode) {
      case QuizMode.hiragana:
        return 'hs_hiragana';
      case QuizMode.katakana:
        return 'hs_katakana';
      case QuizMode.mixed:
        return 'hs_mixed';
    }
  }

  @override
  void initState() {
    super.initState();
    _lives = widget.maxLives;
    _secondsLeft = widget.secondsPerQuestion;
    _startNewGame();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎲 GAME LOGIC
  // ═══════════════════════════════════════════════════════════════════
  void _startNewGame() {
    final random = Random();
    final source = _sourceList;

    // Pilih soal random
    final shuffled = List<KanaItem>.from(source)..shuffle(random);
    _quizPool = shuffled.take(widget.totalQuestions).toList();

    // Generate opsi
    _options = [];
    _correctAnswer = [];

    for (final item in _quizPool) {
      final wrongs = <String>{};
      int tries = 0;
      while (wrongs.length < 3 && tries < 100) {
        final candidate = source[random.nextInt(source.length)];
        if (candidate.romaji != item.romaji) {
          wrongs.add(candidate.romaji);
        }
        tries++;
      }

      final opts = [item.romaji, ...wrongs]..shuffle(random);
      _options.add(opts);
      _correctAnswer.add(item.romaji);
    }

    _currentIndex = 0;
    _score = 0;
    _comboCount = 0;
    _bestCombo = 0;
    _lives = widget.maxLives;
    _isGameOver = false;
    _isWon = false;
    _resetQuestionState();
    _startTimer();
  }

  void _resetQuestionState() {
    _selectedIndex = null;
    _isAnswered = false;
    _secondsLeft = widget.secondsPerQuestion;
  }

  void _startTimer() {
    _timer?.cancel();
    _secondsLeft = widget.secondsPerQuestion;
    setState(() {});

    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_isAnswered || _isGameOver) return;

      setState(() => _secondsLeft--);

      if (_secondsLeft <= 0) {
        t.cancel();
        _handleTimeout();
      }
    });
  }

  void _handleTimeout() {
    if (_isAnswered || _isGameOver) return;
    setState(() {
      _isAnswered = true;
      _selectedIndex = -1;
      _lives--;
      _comboCount = 0;
    });
    _checkGameState();
    Future.delayed(const Duration(milliseconds: 1200), _nextQuestion);
  }

  void _handleAnswer(int index) {
    if (_isAnswered || _isGameOver) return;

    _timer?.cancel();
    final isRight = _options[_currentIndex][index] == _correctAnswer[_currentIndex];

    setState(() {
      _selectedIndex = index;
      _isAnswered = true;

      if (isRight) {
        _comboCount++;
        if (_comboCount > _bestCombo) _bestCombo = _comboCount;

        // Bonus combo: +10 base, +5 per 3 combo (max 25)
        final bonus = min(_comboCount * 2, 15);
        _score += 10 + bonus;
      } else {
        _lives--;
        _comboCount = 0;
      }
    });

    _checkGameState();
    Future.delayed(const Duration(milliseconds: 900), _nextQuestion);
  }

  void _checkGameState() {
    if (_lives <= 0) {
      _isGameOver = true;
      _timer?.cancel();
      Future.delayed(const Duration(milliseconds: 800), _showGameOver);
    }
  }

  void _nextQuestion() {
    if (!mounted || _isGameOver) return;

    if (_currentIndex >= widget.totalQuestions - 1) {
      _isWon = true;
      _isGameOver = true;
      _showGameOver();
      return;
    }

    setState(() {
      _currentIndex++;
      _resetQuestionState();
    });
    _startTimer();
  }

  Future<void> _saveHighScore() async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getInt(_prefsKey) ?? 0;
    if (_score > current) {
      await prefs.setInt(_prefsKey, _score);
    }
  }

  void _showGameOver() async {
    if (!mounted) return;
    await _saveHighScore();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _buildGameOverDialog(),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🏁 GAME OVER DIALOG
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGameOverDialog() {
    final totalPossible = widget.totalQuestions * 10;
    final percentage = totalPossible > 0 ? (_score / totalPossible * 100).round() : 0;

    String title, emoji, message;
    Color color;

    if (!_isWon && _lives <= 0) {
      title = "GAME OVER";
      emoji = "💔";
      color = errorColor;
      message = "Nyawa kamu habis!";
    } else if (percentage >= 90) {
      title = "SUGOI! 🎌";
      emoji = "🏆";
      color = successColor;
      message = "Luar biasa! Master $_modeLabel!";
    } else if (percentage >= 70) {
      title = "YOKATTA! ✨";
      emoji = "🎉";
      color = blueAccent;
      message = "Bagus! Terus berlatih!";
    } else if (percentage >= 50) {
      title = "GANBATTE! 💪";
      emoji = "👍";
      color = pinkAccent;
      message = "Lumayan! Coba lagi ya!";
    } else {
      title = "TRY AGAIN";
      emoji = "📚";
      color = errorColor;
      message = "Belajar lagi $_modeLabel-nya!";
    }

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(24),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgPanel, bgDeep],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: color.withOpacity(0.4), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.3),
              blurRadius: 30,
              spreadRadius: -4,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 64)),
            const SizedBox(height: 12),
            Text(
              title,
              style: TextStyle(
                color: color,
                fontSize: 26,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
                shadows: [Shadow(color: color.withOpacity(0.6), blurRadius: 16)],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: textSub, fontSize: 13),
            ),
            const SizedBox(height: 20),

            // Score box
            Container(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [bgCard, Color(0xFF0E1424)],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Text(
                    "TOTAL SCORE",
                    style: TextStyle(
                      color: textSub,
                      fontSize: 11,
                      letterSpacing: 2,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "$_score",
                    style: TextStyle(
                      color: color,
                      fontSize: 44,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      shadows: [Shadow(color: color.withOpacity(0.8), blurRadius: 20)],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "dari $totalPossible poin ($percentage%)",
                    style: TextStyle(color: textSub, fontSize: 11),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // Extra stats
            Row(
              children: [
                Expanded(
                  child: _miniStat("🔥", "Best Combo", "$_bestCombo"),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _miniStat("✅", "Benar", "$_currentIndex"),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Buttons
            Row(
              children: [
                Expanded(
                  child: _dialogBtn(
                    icon: Icons.home_rounded,
                    label: "MENU",
                    color: textSub,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pop(context);
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _dialogBtn(
                    icon: Icons.refresh_rounded,
                    label: "ULANG",
                    color: _accentColor,
                    onTap: () {
                      Navigator.pop(context);
                      setState(() => _startNewGame());
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _miniStat(String emoji, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: textSub.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(color: textSub, fontSize: 10)),
          Text(
            value,
            style: const TextStyle(
              color: textMain,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
            ),
          ),
        ],
      ),
    );
  }

  Widget _dialogBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color.withOpacity(0.3), color.withOpacity(0.1)],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.3), blurRadius: 12, spreadRadius: -3),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎨 BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDeep,
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.7),
            radius: 1.5,
            colors: [Color(0xFF1B2344), bgDeep, Color(0xFF05070E)],
            stops: [0.0, 0.6, 1.0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildProgressBar(),
              _buildTopBar(),
              const SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      _buildQuestionCard(),
                      const SizedBox(height: 24),
                      _buildOptions(),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🎯 HEADER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: bgPanel,
                shape: BoxShape.circle,
                border: Border.all(color: _accentColor.withOpacity(0.4)),
                boxShadow: [
                  BoxShadow(
                    color: _accentColor.withOpacity(0.3),
                    blurRadius: 12,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: const Icon(Icons.close, color: textMain, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Kuis $_modeLabel",
                  style: const TextStyle(
                    color: textMain,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  _modeSub,
                  style: TextStyle(
                    color: _accentColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          if (_comboCount >= 3)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF6B35), Color(0xFFE91E63)],
                ),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF6B35).withOpacity(0.5),
                    blurRadius: 14,
                    spreadRadius: -3,
                  ),
                ],
              ),
              child: Row(
                children: [
                  const Text("🔥", style: TextStyle(fontSize: 14)),
                  const SizedBox(width: 4),
                  Text(
                    "x$_comboCount",
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 📊 PROGRESS BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildProgressBar() {
    final progress = (_currentIndex + 1) / widget.totalQuestions;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: Stack(
          children: [
            Container(height: 6, color: bgPanel),
            AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              height: 6,
              width: MediaQuery.of(context).size.width * progress * 0.9,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_accentColor.withOpacity(0.8), _accentColor],
                ),
                boxShadow: [
                  BoxShadow(color: _accentColor.withOpacity(0.6), blurRadius: 10),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ❤️ TOP BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Hearts
          Row(
            children: List.generate(widget.maxLives, (i) {
              return Padding(
                padding: const EdgeInsets.only(right: 2),
                child: Icon(
                  i < _lives ? Icons.favorite : Icons.favorite_border,
                  color: i < _lives ? heartColor : textSub.withOpacity(0.3),
                  size: 22,
                  shadows: i < _lives
                      ? [Shadow(color: heartColor.withOpacity(0.8), blurRadius: 10)]
                      : null,
                ),
              );
            }),
          ),

          // Timer
          Expanded(
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: bgPanel,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: _secondsLeft <= 3 ? errorColor : _accentColor.withOpacity(0.5),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: (_secondsLeft <= 3 ? errorColor : _accentColor).withOpacity(0.35),
                      blurRadius: 16,
                      spreadRadius: -3,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.hourglass_bottom,
                      color: _secondsLeft <= 3 ? errorColor : _accentColor,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "${_secondsLeft}s",
                      style: TextStyle(
                        color: _secondsLeft <= 3 ? errorColor : textMain,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Score
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                "Skor:",
                style: TextStyle(color: textSub, fontSize: 11),
              ),
              Text(
                "$_score",
                style: const TextStyle(
                  color: textMain,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ❓ QUESTION CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildQuestionCard() {
    final item = _quizPool[_currentIndex];
    final isKatakana = item.type == 'katakana';

    return Column(
      children: [
        Text(
          "${_currentIndex + 1} / ${widget.totalQuestions}",
          style: TextStyle(
            color: textSub,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 16),

        // Type badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: (isKatakana ? blueAccent : pinkAccent).withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: (isKatakana ? blueAccent : pinkAccent).withOpacity(0.5),
            ),
          ),
          child: Text(
            isKatakana ? "カタカナ" : "ひらがな",
            style: TextStyle(
              color: isKatakana ? blueAccent : pinkAccent,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ),
        const SizedBox(height: 16),

        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [bgPanel, bgCard],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _accentColor.withOpacity(0.35), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
              BoxShadow(
                color: _accentColor.withOpacity(0.15),
                blurRadius: 30,
                spreadRadius: -5,
              ),
            ],
          ),
          child: Column(
            children: [
              Text(
                "Romaji dari huruf/kata ini?",
                style: TextStyle(
                  color: textSub,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                item.kana,
                style: const TextStyle(
                  color: textMain,
                  fontSize: 96,
                  fontWeight: FontWeight.w600,
                  height: 1.1,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // 🔘 OPTIONS
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildOptions() {
    final opts = _options[_currentIndex];
    final correct = _correctAnswer[_currentIndex];

    return Column(
      children: List.generate(opts.length, (index) {
        final option = opts[index];
        final isSelected = _selectedIndex == index;

        Color borderColor = _accentColor.withOpacity(0.3);
        Color bgColor = bgOption;
        Color textColor = textMain;
        IconData? trailingIcon;

        if (_isAnswered) {
          if (option == correct) {
            borderColor = successColor;
            bgColor = successColor.withOpacity(0.15);
            textColor = successColor;
            trailingIcon = Icons.check_circle;
          } else if (isSelected) {
            borderColor = errorColor;
            bgColor = errorColor.withOpacity(0.15);
            textColor = errorColor;
            trailingIcon = Icons.cancel;
          }
        }

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: GestureDetector(
            onTap: _isAnswered ? null : () => _handleAnswer(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: borderColor, width: 1.5),
                boxShadow: _isAnswered && (option == correct || isSelected)
                    ? [
                        BoxShadow(
                          color: borderColor.withOpacity(0.4),
                          blurRadius: 16,
                          spreadRadius: -3,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      option,
                      style: TextStyle(
                        color: textColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  if (trailingIcon != null)
                    Icon(trailingIcon, color: textColor, size: 24),
                ],
              ),
            ),
          ),
        );
      }),
    );
  }
}