// lib/kamus_jepang_page.dart
// ============================================================
// KAMUS BAHASA JEPANG - OFFLINE
// Fix: HomePage → KamusHomePage (hindari konflik nama)
// ============================================================

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ============================================================
// ENTRY POINT
// ============================================================
class KamusJepangPage extends StatelessWidget {
  const KamusJepangPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const KamusHomePage();   // ⭐ diubah
  }
}

// ============================================================
// 1. MODEL DATA
// ============================================================
class Kosakata {
  final String romaji;
  final String hiragana;
  final String katakana;
  final String kanji;
  final String arti;
  final String kategori;

  const Kosakata({
    required this.romaji,
    required this.hiragana,
    required this.katakana,
    required this.kanji,
    required this.arti,
    required this.kategori,
  });
}

// ============================================================
// 2. DATA KAMUS (LOKAL)
// ============================================================
const List<Kosakata> dataKamus = [
  // ═══════════ SALAM ═══════════
  Kosakata(romaji: "ohayou gozaimasu", hiragana: "おはようございます", katakana: "オハヨウゴザイマス", kanji: "お早うございます", arti: "Selamat pagi (formal)", kategori: "Salam"),
  Kosakata(romaji: "ohayou", hiragana: "おはよう", katakana: "オハヨウ", kanji: "お早う", arti: "Selamat pagi (kasual)", kategori: "Salam"),
  Kosakata(romaji: "konnichiwa", hiragana: "こんにちは", katakana: "コンニチハ", kanji: "今日は", arti: "Selamat siang", kategori: "Salam"),
  Kosakata(romaji: "konbanwa", hiragana: "こんばんは", katakana: "コンバンハ", kanji: "今晩は", arti: "Selamat malam", kategori: "Salam"),
  Kosakata(romaji: "oyasuminasai", hiragana: "おやすみなさい", katakana: "オヤスミナサイ", kanji: "お休みなさい", arti: "Selamat tidur", kategori: "Salam"),
  Kosakata(romaji: "sayounara", hiragana: "さようなら", katakana: "サヨウナラ", kanji: "左様なら", arti: "Selamat tinggal", kategori: "Salam"),
  Kosakata(romaji: "jaa ne", hiragana: "じゃあね", katakana: "ジャアネ", kanji: "じゃあね", arti: "Sampai jumpa (kasual)", kategori: "Salam"),
  Kosakata(romaji: "arigatou gozaimasu", hiragana: "ありがとうございます", katakana: "アリガトウゴザイマス", kanji: "有難うございます", arti: "Terima kasih (formal)", kategori: "Salam"),
  Kosakata(romaji: "arigatou", hiragana: "ありがとう", katakana: "アリガトウ", kanji: "有難う", arti: "Terima kasih", kategori: "Salam"),
  Kosakata(romaji: "sumimasen", hiragana: "すみません", katakana: "スミマセン", kanji: "済みません", arti: "Maaf / Permisi", kategori: "Salam"),
  Kosakata(romaji: "gomennasai", hiragana: "ごめんなさい", katakana: "ゴメンナサイ", kanji: "御免なさい", arti: "Maaf", kategori: "Salam"),
  Kosakata(romaji: "hai", hiragana: "はい", katakana: "ハイ", kanji: "拝", arti: "Ya", kategori: "Salam"),
  Kosakata(romaji: "iie", hiragana: "いいえ", katakana: "イイエ", kanji: "否", arti: "Tidak", kategori: "Salam"),
  Kosakata(romaji: "onegaishimasu", hiragana: "おねがいします", katakana: "オネガイシマス", kanji: "お願いします", arti: "Tolong / Mohon", kategori: "Salam"),
  Kosakata(romaji: "itadakimasu", hiragana: "いただきます", katakana: "イタダキマス", kanji: "頂きます", arti: "Selamat makan (sebelum makan)", kategori: "Salam"),
  Kosakata(romaji: "gochisousama", hiragana: "ごちそうさま", katakana: "ゴチソウサマ", kanji: "ご馳走様", arti: "Terima kasih atas makanannya", kategori: "Salam"),
  Kosakata(romaji: "okaeri", hiragana: "おかえり", katakana: "オカエリ", kanji: "お帰り", arti: "Selamat datang kembali", kategori: "Salam"),
  Kosakata(romaji: "ittekimasu", hiragana: "いってきます", katakana: "イッテキマス", kanji: "行ってきます", arti: "Saya pergi dulu", kategori: "Salam"),
  Kosakata(romaji: "tadaima", hiragana: "ただいま", katakana: "タダイマ", kanji: "只今", arti: "Saya pulang", kategori: "Salam"),

  // ═══════════ ANGKA ═══════════
  Kosakata(romaji: "ichi", hiragana: "いち", katakana: "イチ", kanji: "一", arti: "Satu (1)", kategori: "Angka"),
  Kosakata(romaji: "ni", hiragana: "に", katakana: "ニ", kanji: "二", arti: "Dua (2)", kategori: "Angka"),
  Kosakata(romaji: "san", hiragana: "さん", katakana: "サン", kanji: "三", arti: "Tiga (3)", kategori: "Angka"),
  Kosakata(romaji: "yon / shi", hiragana: "よん / し", katakana: "ヨン / シ", kanji: "四", arti: "Empat (4)", kategori: "Angka"),
  Kosakata(romaji: "go", hiragana: "ご", katakana: "ゴ", kanji: "五", arti: "Lima (5)", kategori: "Angka"),
  Kosakata(romaji: "roku", hiragana: "ろく", katakana: "ロク", kanji: "六", arti: "Enam (6)", kategori: "Angka"),
  Kosakata(romaji: "nana / shichi", hiragana: "なな / しち", katakana: "ナナ / シチ", kanji: "七", arti: "Tujuh (7)", kategori: "Angka"),
  Kosakata(romaji: "hachi", hiragana: "はち", katakana: "ハチ", kanji: "八", arti: "Delapan (8)", kategori: "Angka"),
  Kosakata(romaji: "kyuu / ku", hiragana: "きゅう / く", katakana: "キュウ / ク", kanji: "九", arti: "Sembilan (9)", kategori: "Angka"),
  Kosakata(romaji: "juu", hiragana: "じゅう", katakana: "ジュウ", kanji: "十", arti: "Sepuluh (10)", kategori: "Angka"),
  Kosakata(romaji: "hyaku", hiragana: "ひゃく", katakana: "ヒャク", kanji: "百", arti: "Seratus (100)", kategori: "Angka"),
  Kosakata(romaji: "sen", hiragana: "せん", katakana: "セン", kanji: "千", arti: "Seribu (1.000)", kategori: "Angka"),
  Kosakata(romaji: "man", hiragana: "まん", katakana: "マン", kanji: "万", arti: "Sepuluh ribu (10.000)", kategori: "Angka"),

  // ═══════════ HARI ═══════════
  Kosakata(romaji: "getsuyoubi", hiragana: "げつようび", katakana: "ゲツヨウビ", kanji: "月曜日", arti: "Hari Senin", kategori: "Hari"),
  Kosakata(romaji: "kayoubi", hiragana: "かようび", katakana: "カヨウビ", kanji: "火曜日", arti: "Hari Selasa", kategori: "Hari"),
  Kosakata(romaji: "suiyoubi", hiragana: "すいようび", katakana: "スイヨウビ", kanji: "水曜日", arti: "Hari Rabu", kategori: "Hari"),
  Kosakata(romaji: "mokuyoubi", hiragana: "もくようび", katakana: "モクヨウビ", kanji: "木曜日", arti: "Hari Kamis", kategori: "Hari"),
  Kosakata(romaji: "kinyoubi", hiragana: "きんようび", katakana: "キンヨウビ", kanji: "金曜日", arti: "Hari Jumat", kategori: "Hari"),
  Kosakata(romaji: "doyoubi", hiragana: "どようび", katakana: "ドヨウビ", kanji: "土曜日", arti: "Hari Sabtu", kategori: "Hari"),
  Kosakata(romaji: "nichiyoubi", hiragana: "にちようび", katakana: "ニチヨウビ", kanji: "日曜日", arti: "Hari Minggu", kategori: "Hari"),

  // ═══════════ KELUARGA ═══════════
  Kosakata(romaji: "otousan", hiragana: "おとうさん", katakana: "オトウサン", kanji: "お父さん", arti: "Ayah", kategori: "Keluarga"),
  Kosakata(romaji: "okaasan", hiragana: "おかあさん", katakana: "オカアサン", kanji: "お母さん", arti: "Ibu", kategori: "Keluarga"),
  Kosakata(romaji: "oniisan", hiragana: "おにいさん", katakana: "オニイサン", kanji: "お兄さん", arti: "Kakak laki-laki", kategori: "Keluarga"),
  Kosakata(romaji: "oneesan", hiragana: "おねえさん", katakana: "オネエサン", kanji: "お姉さん", arti: "Kakak perempuan", kategori: "Keluarga"),
  Kosakata(romaji: "otouto", hiragana: "おとうと", katakana: "オトウト", kanji: "弟", arti: "Adik laki-laki", kategori: "Keluarga"),
  Kosakata(romaji: "imouto", hiragana: "いもうと", katakana: "イモウト", kanji: "妹", arti: "Adik perempuan", kategori: "Keluarga"),
  Kosakata(romaji: "ojiisan", hiragana: "おじいさん", katakana: "オジイサン", kanji: "お祖父さん", arti: "Kakek", kategori: "Keluarga"),
  Kosakata(romaji: "obaasan", hiragana: "おばあさん", katakana: "オバアサン", kanji: "お祖母さん", arti: "Nenek", kategori: "Keluarga"),
  Kosakata(romaji: "kazoku", hiragana: "かぞく", katakana: "カゾク", kanji: "家族", arti: "Keluarga", kategori: "Keluarga"),
  Kosakata(romaji: "otto", hiragana: "おっと", katakana: "オット", kanji: "夫", arti: "Suami", kategori: "Keluarga"),
  Kosakata(romaji: "tsuma", hiragana: "つま", katakana: "ツマ", kanji: "妻", arti: "Istri", kategori: "Keluarga"),
  Kosakata(romaji: "kodomo", hiragana: "こども", katakana: "コドモ", kanji: "子供", arti: "Anak", kategori: "Keluarga"),

  // ═══════════ KATA KERJA ═══════════
  Kosakata(romaji: "taberu", hiragana: "たべる", katakana: "タベル", kanji: "食べる", arti: "Makan", kategori: "Kata Kerja"),
  Kosakata(romaji: "nomu", hiragana: "のむ", katakana: "ノム", kanji: "飲む", arti: "Minum", kategori: "Kata Kerja"),
  Kosakata(romaji: "iku", hiragana: "いく", katakana: "イク", kanji: "行く", arti: "Pergi", kategori: "Kata Kerja"),
  Kosakata(romaji: "kuru", hiragana: "くる", katakana: "クル", kanji: "来る", arti: "Datang", kategori: "Kata Kerja"),
  Kosakata(romaji: "kaeru", hiragana: "かえる", katakana: "カエル", kanji: "帰る", arti: "Pulang", kategori: "Kata Kerja"),
  Kosakata(romaji: "miru", hiragana: "みる", katakana: "ミル", kanji: "見る", arti: "Melihat", kategori: "Kata Kerja"),
  Kosakata(romaji: "kiku", hiragana: "きく", katakana: "キク", kanji: "聞く", arti: "Mendengar / Bertanya", kategori: "Kata Kerja"),
  Kosakata(romaji: "hanasu", hiragana: "はなす", katakana: "ハナス", kanji: "話す", arti: "Berbicara", kategori: "Kata Kerja"),
  Kosakata(romaji: "yomu", hiragana: "よむ", katakana: "ヨム", kanji: "読む", arti: "Membaca", kategori: "Kata Kerja"),
  Kosakata(romaji: "kaku", hiragana: "かく", katakana: "カク", kanji: "書く", arti: "Menulis", kategori: "Kata Kerja"),
  Kosakata(romaji: "suru", hiragana: "する", katakana: "スル", kanji: "為る", arti: "Melakukan", kategori: "Kata Kerja"),
  Kosakata(romaji: "matsu", hiragana: "まつ", katakana: "マツ", kanji: "待つ", arti: "Menunggu", kategori: "Kata Kerja"),
  Kosakata(romaji: "wakaru", hiragana: "わかる", katakana: "ワカル", kanji: "分かる", arti: "Mengerti / Paham", kategori: "Kata Kerja"),
  Kosakata(romaji: "shiru", hiragana: "しる", katakana: "シル", kanji: "知る", arti: "Tahu / Mengetahui", kategori: "Kata Kerja"),
  Kosakata(romaji: "neru", hiragana: "ねる", katakana: "ネル", kanji: "寝る", arti: "Tidur", kategori: "Kata Kerja"),
  Kosakata(romaji: "okiru", hiragana: "おきる", katakana: "オキル", kanji: "起きる", arti: "Bangun", kategori: "Kata Kerja"),
  Kosakata(romaji: "hataraku", hiragana: "はたらく", katakana: "ハタラク", kanji: "働く", arti: "Bekerja", kategori: "Kata Kerja"),
  Kosakata(romaji: "benkyou suru", hiragana: "べんきょうする", katakana: "ベンキョウスル", kanji: "勉強する", arti: "Belajar", kategori: "Kata Kerja"),
  Kosakata(romaji: "asobu", hiragana: "あそぶ", katakana: "アソブ", kanji: "遊ぶ", arti: "Bermain", kategori: "Kata Kerja"),
  Kosakata(romaji: "kau", hiragana: "かう", katakana: "カウ", kanji: "買う", arti: "Membeli", kategori: "Kata Kerja"),

  // ═══════════ BENDA ═══════════
  Kosakata(romaji: "hon", hiragana: "ほん", katakana: "ホン", kanji: "本", arti: "Buku", kategori: "Benda"),
  Kosakata(romaji: "tsukue", hiragana: "つくえ", katakana: "ツクエ", kanji: "机", arti: "Meja", kategori: "Benda"),
  Kosakata(romaji: "isu", hiragana: "いす", katakana: "イス", kanji: "椅子", arti: "Kursi", kategori: "Benda"),
  Kosakata(romaji: "kuruma", hiragana: "くるま", katakana: "クルマ", kanji: "車", arti: "Mobil", kategori: "Benda"),
  Kosakata(romaji: "jitensha", hiragana: "じてんしゃ", katakana: "ジテンシャ", kanji: "自転車", arti: "Sepeda", kategori: "Benda"),
  Kosakata(romaji: "ie", hiragana: "いえ", katakana: "イエ", kanji: "家", arti: "Rumah", kategori: "Benda"),
  Kosakata(romaji: "mizu", hiragana: "みず", katakana: "ミズ", kanji: "水", arti: "Air", kategori: "Benda"),
  Kosakata(romaji: "gohan", hiragana: "ごはん", katakana: "ゴハン", kanji: "ご飯", arti: "Nasi / Makanan", kategori: "Benda"),
  Kosakata(romaji: "denwa", hiragana: "でんわ", katakana: "デンワ", kanji: "電話", arti: "Telepon", kategori: "Benda"),
  Kosakata(romaji: "tokei", hiragana: "とけい", katakana: "トケイ", kanji: "時計", arti: "Jam", kategori: "Benda"),
  Kosakata(romaji: "kaban", hiragana: "かばん", katakana: "カバン", kanji: "鞄", arti: "Tas", kategori: "Benda"),
  Kosakata(romaji: "kutsu", hiragana: "くつ", katakana: "クツ", kanji: "靴", arti: "Sepatu", kategori: "Benda"),
  Kosakata(romaji: "fuku", hiragana: "ふく", katakana: "フク", kanji: "服", arti: "Pakaian", kategori: "Benda"),
  Kosakata(romaji: "tamago", hiragana: "たまご", katakana: "タマゴ", kanji: "卵", arti: "Telur", kategori: "Benda"),
  Kosakata(romaji: "sakana", hiragana: "さかな", katakana: "サカナ", kanji: "魚", arti: "Ikan", kategori: "Benda"),
  Kosakata(romaji: "niku", hiragana: "にく", katakana: "ニク", kanji: "肉", arti: "Daging", kategori: "Benda"),
  Kosakata(romaji: "kudamono", hiragana: "くだもの", katakana: "クダモノ", kanji: "果物", arti: "Buah", kategori: "Benda"),
  Kosakata(romaji: "yasai", hiragana: "やさい", katakana: "ヤサイ", kanji: "野菜", arti: "Sayur", kategori: "Benda"),

  // ═══════════ WARNA ═══════════
  Kosakata(romaji: "aka", hiragana: "あか", katakana: "アカ", kanji: "赤", arti: "Merah", kategori: "Warna"),
  Kosakata(romaji: "ao", hiragana: "あお", katakana: "アオ", kanji: "青", arti: "Biru", kategori: "Warna"),
  Kosakata(romaji: "kiiro", hiragana: "きいろ", katakana: "キイロ", kanji: "黄色", arti: "Kuning", kategori: "Warna"),
  Kosakata(romaji: "midori", hiragana: "みどり", katakana: "ミドリ", kanji: "緑", arti: "Hijau", kategori: "Warna"),
  Kosakata(romaji: "kuro", hiragana: "くろ", katakana: "クロ", kanji: "黒", arti: "Hitam", kategori: "Warna"),
  Kosakata(romaji: "shiro", hiragana: "しろ", katakana: "シロ", kanji: "白", arti: "Putih", kategori: "Warna"),
  Kosakata(romaji: "murasaki", hiragana: "むらさき", katakana: "ムラサキ", kanji: "紫", arti: "Ungu", kategori: "Warna"),
  Kosakata(romaji: "chairo", hiragana: "ちゃいろ", katakana: "チャイロ", kanji: "茶色", arti: "Cokelat", kategori: "Warna"),
  Kosakata(romaji: "pinku", hiragana: "ぴんく", katakana: "ピンク", kanji: "桃色", arti: "Merah muda / Pink", kategori: "Warna"),
  Kosakata(romaji: "orenji", hiragana: "おれんじ", katakana: "オレンジ", kanji: "橙色", arti: "Oranye", kategori: "Warna"),

  // ═══════════ SIFAT ═══════════
  Kosakata(romaji: "ookii", hiragana: "おおきい", katakana: "オオキイ", kanji: "大きい", arti: "Besar", kategori: "Sifat"),
  Kosakata(romaji: "chiisai", hiragana: "ちいさい", katakana: "チイサイ", kanji: "小さい", arti: "Kecil", kategori: "Sifat"),
  Kosakata(romaji: "takai", hiragana: "たかい", katakana: "タカイ", kanji: "高い", arti: "Tinggi / Mahal", kategori: "Sifat"),
  Kosakata(romaji: "hikui", hiragana: "ひくい", katakana: "ヒクイ", kanji: "低い", arti: "Rendah", kategori: "Sifat"),
  Kosakata(romaji: "yasui", hiragana: "やすい", katakana: "ヤスイ", kanji: "安い", arti: "Murah", kategori: "Sifat"),
  Kosakata(romaji: "atarashii", hiragana: "あたらしい", katakana: "アタラシイ", kanji: "新しい", arti: "Baru", kategori: "Sifat"),
  Kosakata(romaji: "furui", hiragana: "ふるい", katakana: "フルイ", kanji: "古い", arti: "Lama / Tua", kategori: "Sifat"),
  Kosakata(romaji: "ii", hiragana: "いい", katakana: "イイ", kanji: "良い", arti: "Baik", kategori: "Sifat"),
  Kosakata(romaji: "warui", hiragana: "わるい", katakana: "ワルイ", kanji: "悪い", arti: "Buruk / Jahat", kategori: "Sifat"),
  Kosakata(romaji: "atsui", hiragana: "あつい", katakana: "アツイ", kanji: "暑い", arti: "Panas (cuaca)", kategori: "Sifat"),
  Kosakata(romaji: "samui", hiragana: "さむい", katakana: "サムイ", kanji: "寒い", arti: "Dingin (cuaca)", kategori: "Sifat"),
  Kosakata(romaji: "oishii", hiragana: "おいしい", katakana: "オイシイ", kanji: "美味しい", arti: "Lezat / Enak", kategori: "Sifat"),
  Kosakata(romaji: "kawaii", hiragana: "かわいい", katakana: "カワイイ", kanji: "可愛い", arti: "Lucu / Imut", kategori: "Sifat"),
  Kosakata(romaji: "utsukushii", hiragana: "うつくしい", katakana: "ウツクシイ", kanji: "美しい", arti: "Indah / Cantik", kategori: "Sifat"),
  Kosakata(romaji: "muzukashii", hiragana: "むずかしい", katakana: "ムズカシイ", kanji: "難しい", arti: "Sulit", kategori: "Sifat"),
  Kosakata(romaji: "kantan", hiragana: "かんたん", katakana: "カンタン", kanji: "簡単", arti: "Mudah / Sederhana", kategori: "Sifat"),

  // ═══════════ TEMPAT ═══════════
  Kosakata(romaji: "gakkou", hiragana: "がっこう", katakana: "ガッコウ", kanji: "学校", arti: "Sekolah", kategori: "Tempat"),
  Kosakata(romaji: "byouin", hiragana: "びょういん", katakana: "ビョウイン", kanji: "病院", arti: "Rumah sakit", kategori: "Tempat"),
  Kosakata(romaji: "eki", hiragana: "えき", katakana: "エキ", kanji: "駅", arti: "Stasiun", kategori: "Tempat"),
  Kosakata(romaji: "mise", hiragana: "みせ", katakana: "ミセ", kanji: "店", arti: "Toko", kategori: "Tempat"),
  Kosakata(romaji: "kouen", hiragana: "こうえん", katakana: "コウエン", kanji: "公園", arti: "Taman", kategori: "Tempat"),
  Kosakata(romaji: "toshokan", hiragana: "としょかん", katakana: "トショカン", kanji: "図書館", arti: "Perpustakaan", kategori: "Tempat"),
  Kosakata(romaji: "resutoran", hiragana: "れすとらん", katakana: "レストラン", kanji: "料理店", arti: "Restoran", kategori: "Tempat"),
  Kosakata(romaji: "kuni", hiragana: "くに", katakana: "クニ", kanji: "国", arti: "Negara", kategori: "Tempat"),
  Kosakata(romaji: "nihon", hiragana: "にほん", katakana: "ニホン", kanji: "日本", arti: "Jepang", kategori: "Tempat"),
  Kosakata(romaji: "indoneshia", hiragana: "いんどねしあ", katakana: "インドネシア", kanji: "印度尼西亜", arti: "Indonesia", kategori: "Tempat"),

  // ═══════════ ALAM ═══════════
  Kosakata(romaji: "sakura", hiragana: "さくら", katakana: "サクラ", kanji: "桜", arti: "Bunga sakura", kategori: "Alam"),
  Kosakata(romaji: "yama", hiragana: "やま", katakana: "ヤマ", kanji: "山", arti: "Gunung", kategori: "Alam"),
  Kosakata(romaji: "kawa", hiragana: "かわ", katakana: "カワ", kanji: "川", arti: "Sungai", kategori: "Alam"),
  Kosakata(romaji: "umi", hiragana: "うみ", katakana: "ウミ", kanji: "海", arti: "Laut", kategori: "Alam"),
  Kosakata(romaji: "sora", hiragana: "そら", katakana: "ソラ", kanji: "空", arti: "Langit", kategori: "Alam"),
  Kosakata(romaji: "tsuki", hiragana: "つき", katakana: "ツキ", kanji: "月", arti: "Bulan", kategori: "Alam"),
  Kosakata(romaji: "hoshi", hiragana: "ほし", katakana: "ホシ", kanji: "星", arti: "Bintang", kategori: "Alam"),
  Kosakata(romaji: "taiyou", hiragana: "たいよう", katakana: "タイヨウ", kanji: "太陽", arti: "Matahari", kategori: "Alam"),
  Kosakata(romaji: "ame", hiragana: "あめ", katakana: "アメ", kanji: "雨", arti: "Hujan", kategori: "Alam"),
  Kosakata(romaji: "yuki", hiragana: "ゆき", katakana: "ユキ", kanji: "雪", arti: "Salju", kategori: "Alam"),
  Kosakata(romaji: "kaze", hiragana: "かぜ", katakana: "カゼ", kanji: "風", arti: "Angin", kategori: "Alam"),
  Kosakata(romaji: "ki", hiragana: "き", katakana: "キ", kanji: "木", arti: "Pohon", kategori: "Alam"),
  Kosakata(romaji: "hana", hiragana: "はな", katakana: "ハナ", kanji: "花", arti: "Bunga", kategori: "Alam"),

  // ═══════════ JLPT N5 ═══════════
  Kosakata(romaji: "watashi", hiragana: "わたし", katakana: "ワタシ", kanji: "私", arti: "Saya / Aku", kategori: "JLPT N5"),
  Kosakata(romaji: "anata", hiragana: "あなた", katakana: "アナタ", kanji: "貴方", arti: "Kamu / Anda", kategori: "JLPT N5"),
  Kosakata(romaji: "kare", hiragana: "かれ", katakana: "カレ", kanji: "彼", arti: "Dia (laki-laki)", kategori: "JLPT N5"),
  Kosakata(romaji: "kanojo", hiragana: "かのじょ", katakana: "カノジョ", kanji: "彼女", arti: "Dia (perempuan)", kategori: "JLPT N5"),
  Kosakata(romaji: "tomodachi", hiragana: "ともだち", katakana: "トモダチ", kanji: "友達", arti: "Teman", kategori: "JLPT N5"),
  Kosakata(romaji: "sensei", hiragana: "せんせい", katakana: "センセイ", kanji: "先生", arti: "Guru / Dosen", kategori: "JLPT N5"),
  Kosakata(romaji: "gakusei", hiragana: "がくせい", katakana: "ガクセイ", kanji: "学生", arti: "Pelajar / Mahasiswa", kategori: "JLPT N5"),
  Kosakata(romaji: "kaisha", hiragana: "かいしゃ", katakana: "カイシャ", kanji: "会社", arti: "Perusahaan", kategori: "JLPT N5"),
  Kosakata(romaji: "shigoto", hiragana: "しごと", katakana: "シゴト", kanji: "仕事", arti: "Pekerjaan", kategori: "JLPT N5"),
  Kosakata(romaji: "ima", hiragana: "いま", katakana: "イマ", kanji: "今", arti: "Sekarang", kategori: "JLPT N5"),
  Kosakata(romaji: "ato", hiragana: "あと", katakana: "アト", kanji: "後", arti: "Setelah / Nanti", kategori: "JLPT N5"),
  Kosakata(romaji: "mae", hiragana: "まえ", katakana: "マエ", kanji: "前", arti: "Sebelum / Depan", kategori: "JLPT N5"),
  Kosakata(romaji: "ushiro", hiragana: "うしろ", katakana: "ウシロ", kanji: "後ろ", arti: "Belakang", kategori: "JLPT N5"),
  Kosakata(romaji: "ue", hiragana: "うえ", katakana: "ウエ", kanji: "上", arti: "Atas", kategori: "JLPT N5"),
  Kosakata(romaji: "shita", hiragana: "した", katakana: "シタ", kanji: "下", arti: "Bawah", kategori: "JLPT N5"),
  Kosakata(romaji: "migi", hiragana: "みぎ", katakana: "ミギ", kanji: "右", arti: "Kanan", kategori: "JLPT N5"),
  Kosakata(romaji: "hidari", hiragana: "ひだり", katakana: "ヒダリ", kanji: "左", arti: "Kiri", kategori: "JLPT N5"),
  Kosakata(romaji: "naka", hiragana: "なか", katakana: "ナカ", kanji: "中", arti: "Dalam / Tengah", kategori: "JLPT N5"),
  Kosakata(romaji: "soto", hiragana: "そと", katakana: "ソト", kanji: "外", arti: "Luar", kategori: "JLPT N5"),
  Kosakata(romaji: "tonari", hiragana: "となり", katakana: "トナリ", kanji: "隣", arti: "Sebelah", kategori: "JLPT N5"),
  Kosakata(romaji: "chikai", hiragana: "ちかい", katakana: "チカイ", kanji: "近い", arti: "Dekat", kategori: "JLPT N5"),
  Kosakata(romaji: "tooi", hiragana: "とおい", katakana: "トオイ", kanji: "遠い", arti: "Jauh", kategori: "JLPT N5"),
  Kosakata(romaji: "kaimono", hiragana: "かいもの", katakana: "カイモノ", kanji: "買い物", arti: "Belanja", kategori: "JLPT N5"),
  Kosakata(romaji: "ryokou", hiragana: "りょこう", katakana: "リョコウ", kanji: "旅行", arti: "Jalan-jalan / Traveling", kategori: "JLPT N5"),
  Kosakata(romaji: "yasumi", hiragana: "やすみ", katakana: "ヤスミ", kanji: "休み", arti: "Libur / Istirahat", kategori: "JLPT N5"),
  Kosakata(romaji: "sumu", hiragana: "すむ", katakana: "スム", kanji: "住む", arti: "Tinggal / Menetap", kategori: "JLPT N5"),
  Kosakata(romaji: "tsukuru", hiragana: "つくる", katakana: "ツクル", kanji: "作る", arti: "Membuat", kategori: "JLPT N5"),
  Kosakata(romaji: "tsukau", hiragana: "つかう", katakana: "ツカウ", kanji: "使う", arti: "Menggunakan", kategori: "JLPT N5"),
  Kosakata(romaji: "au", hiragana: "あう", katakana: "アウ", kanji: "会う", arti: "Bertemu", kategori: "JLPT N5"),
  Kosakata(romaji: "hajimaru", hiragana: "はじまる", katakana: "ハジマル", kanji: "始まる", arti: "Dimulai", kategori: "JLPT N5"),
  Kosakata(romaji: "owaru", hiragana: "おわる", katakana: "オワル", kanji: "終わる", arti: "Selesai / Berakhir", kategori: "JLPT N5"),
  Kosakata(romaji: "aruku", hiragana: "あるく", katakana: "アルク", kanji: "歩く", arti: "Berjalan", kategori: "JLPT N5"),
  Kosakata(romaji: "hashiru", hiragana: "はしる", katakana: "ハシル", kanji: "走る", arti: "Berlari", kategori: "JLPT N5"),

  // ═══════════ JLPT N4 ═══════════
  Kosakata(romaji: "keiken", hiragana: "けいけん", katakana: "ケイケン", kanji: "経験", arti: "Pengalaman", kategori: "JLPT N4"),
  Kosakata(romaji: "junbi", hiragana: "じゅんび", katakana: "ジュンビ", kanji: "準備", arti: "Persiapan", kategori: "JLPT N4"),
  Kosakata(romaji: "annai", hiragana: "あんない", katakana: "アンナイ", kanji: "案内", arti: "Pemanduan / Pengenalan", kategori: "JLPT N4"),
  Kosakata(romaji: "hikkosu", hiragana: "ひっこす", katakana: "ヒッコス", kanji: "引っ越す", arti: "Pindah rumah", kategori: "JLPT N4"),
  Kosakata(romaji: "kekkon", hiragana: "けっこん", katakana: "ケッコン", kanji: "結婚", arti: "Pernikahan", kategori: "JLPT N4"),
  Kosakata(romaji: "shokuji", hiragana: "しょくじ", katakana: "ショクジ", kanji: "食事", arti: "Makan (formal)", kategori: "JLPT N4"),
  Kosakata(romaji: "jidou", hiragana: "じどう", katakana: "ジドウ", kanji: "自動", arti: "Otomatis", kategori: "JLPT N4"),
  Kosakata(romaji: "anzen", hiragana: "あんぜん", katakana: "アンゼン", kanji: "安全", arti: "Aman / Keselamatan", kategori: "JLPT N4"),
  Kosakata(romaji: "kiken", hiragana: "きけん", katakana: "キケン", kanji: "危険", arti: "Bahaya", kategori: "JLPT N4"),
  Kosakata(romaji: "boueki", hiragana: "ぼうえき", katakana: "ボウエキ", kanji: "貿易", arti: "Perdagangan", kategori: "JLPT N4"),
  Kosakata(romaji: "keizai", hiragana: "けいざい", katakana: "ケイザイ", kanji: "経済", arti: "Ekonomi", kategori: "JLPT N4"),
  Kosakata(romaji: "seiji", hiragana: "せいじ", katakana: "セイジ", kanji: "政治", arti: "Politik", kategori: "JLPT N4"),
  Kosakata(romaji: "bunka", hiragana: "ぶんか", katakana: "ブンカ", kanji: "文化", arti: "Budaya", kategori: "JLPT N4"),
  Kosakata(romaji: "shakai", hiragana: "しゃかい", katakana: "シャカイ", kanji: "社会", arti: "Masyarakat", kategori: "JLPT N4"),
  Kosakata(romaji: "houhou", hiragana: "ほうほう", katakana: "ホウホウ", kanji: "方法", arti: "Metode / Cara", kategori: "JLPT N4"),
  Kosakata(romaji: "baai", hiragana: "ばあい", katakana: "バアイ", kanji: "場合", arti: "Situasi / Kasus", kategori: "JLPT N4"),
  Kosakata(romaji: "gen'in", hiragana: "げんいん", katakana: "ゲンイン", kanji: "原因", arti: "Penyebab", kategori: "JLPT N4"),
  Kosakata(romaji: "kekka", hiragana: "けっか", katakana: "ケッカ", kanji: "結果", arti: "Hasil", kategori: "JLPT N4"),
  Kosakata(romaji: "imi", hiragana: "いみ", katakana: "イミ", kanji: "意味", arti: "Arti", kategori: "JLPT N4"),
  Kosakata(romaji: "riyuu", hiragana: "りゆう", katakana: "リユウ", kanji: "理由", arti: "Alasan", kategori: "JLPT N4"),
  Kosakata(romaji: "mokuteki", hiragana: "もくてき", katakana: "モクテキ", kanji: "目的", arti: "Tujuan", kategori: "JLPT N4"),
  Kosakata(romaji: "yotei", hiragana: "よてい", katakana: "ヨテイ", kanji: "予定", arti: "Rencana / Jadwal", kategori: "JLPT N4"),
  Kosakata(romaji: "yakusoku", hiragana: "やくそく", katakana: "ヤクソク", kanji: "約束", arti: "Janji", kategori: "JLPT N4"),
  Kosakata(romaji: "renshuu", hiragana: "れんしゅう", katakana: "レンシュウ", kanji: "練習", arti: "Latihan", kategori: "JLPT N4"),
  Kosakata(romaji: "shiken", hiragana: "しけん", katakana: "シケン", kanji: "試験", arti: "Ujian", kategori: "JLPT N4"),
  Kosakata(romaji: "seikou", hiragana: "せいこう", katakana: "セイコウ", kanji: "成功", arti: "Sukses / Keberhasilan", kategori: "JLPT N4"),
  Kosakata(romaji: "shippai", hiragana: "しっぱい", katakana: "シッパイ", kanji: "失敗", arti: "Kegagalan", kategori: "JLPT N4"),
  Kosakata(romaji: "ganbaru", hiragana: "がんばる", katakana: "ガンバル", kanji: "頑張る", arti: "Berusaha / Semangat", kategori: "JLPT N4"),
  Kosakata(romaji: "tasukeru", hiragana: "たすける", katakana: "タスケル", kanji: "助ける", arti: "Menolong", kategori: "JLPT N4"),
  Kosakata(romaji: "suteru", hiragana: "すてる", katakana: "ステル", kanji: "捨てる", arti: "Membuang", kategori: "JLPT N4"),
  Kosakata(romaji: "haku", hiragana: "はく", katakana: "ハク", kanji: "履く", arti: "Memakai (sepatu/celana)", kategori: "JLPT N4"),
  Kosakata(romaji: "kiru", hiragana: "きる", katakana: "キル", kanji: "着る", arti: "Memakai (baju)", kategori: "JLPT N4"),
  Kosakata(romaji: "nugu", hiragana: "ぬぐ", katakana: "ヌグ", kanji: "脱ぐ", arti: "Melepas (pakaian)", kategori: "JLPT N4"),
  Kosakata(romaji: "naru", hiragana: "なる", katakana: "ナル", kanji: "成る", arti: "Menjadi", kategori: "JLPT N4"),
  Kosakata(romaji: "mieru", hiragana: "みえる", katakana: "ミエル", kanji: "見える", arti: "Terlihat / Bisa dilihat", kategori: "JLPT N4"),
  Kosakata(romaji: "kikoeru", hiragana: "きこえる", katakana: "キコエル", kanji: "聞こえる", arti: "Terdengar / Bisa didengar", kategori: "JLPT N4"),
  Kosakata(romaji: "kangaeru", hiragana: "かんがえる", katakana: "カンガエル", kanji: "考える", arti: "Berpikir", kategori: "JLPT N4"),
  Kosakata(romaji: "oboeru", hiragana: "おぼえる", katakana: "オボエル", kanji: "覚える", arti: "Mengingat / Menghafal", kategori: "JLPT N4"),
];

// ============================================================
// 3. HALAMAN UTAMA KAMUS
// ============================================================
class KamusHomePage extends StatefulWidget {   // ⭐ DIUBAH
  const KamusHomePage({super.key});

  @override
  State<KamusHomePage> createState() => _KamusHomePageState();   // ⭐ DIUBAH
}

class _KamusHomePageState extends State<KamusHomePage> {   // ⭐ DIUBAH
  final TextEditingController _searchController = TextEditingController();
  List<Kosakata> hasil = List.from(dataKamus);
  String kategoriTerpilih = "Semua";
  final Set<Kosakata> favorit = {};

  final List<String> kategoriList = [
    "Semua",
    "Salam",
    "Angka",
    "Hari",
    "Keluarga",
    "Kata Kerja",
    "Benda",
    "Warna",
    "Sifat",
    "Tempat",
    "Alam",
    "JLPT N5",
    "JLPT N4",
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void cari(String query) {
    setState(() {
      hasil = dataKamus.where((k) {
        final cocokKategori =
            kategoriTerpilih == "Semua" || k.kategori == kategoriTerpilih;
        final q = query.toLowerCase().trim();
        final cocokQuery = q.isEmpty ||
            k.romaji.toLowerCase().contains(q) ||
            k.hiragana.contains(q) ||
            k.katakana.contains(q) ||
            k.kanji.contains(q) ||
            k.arti.toLowerCase().contains(q);
        return cocokKategori && cocokQuery;
      }).toList();
    });
  }

  void toggleFavorit(Kosakata k) {
    setState(() {
      if (favorit.contains(k)) {
        favorit.remove(k);
      } else {
        favorit.add(k);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF6F6),
      appBar: AppBar(
        title: const Text('🌸 Kamus Bahasa Jepang'),
        centerTitle: true,
        backgroundColor: const Color(0xFFC62828),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite),
            tooltip: 'Favorit',
            onPressed: () {
              if (favorit.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Belum ada kosakata favorit')),
                );
                return;
              }
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => FavoritPage(
                    favorit: favorit.toList(),
                    onToggle: toggleFavorit,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              onChanged: cari,
              decoration: InputDecoration(
                hintText: 'Cari (romaji / hiragana / kanji / arti)...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          cari('');
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
          ),
          SizedBox(
            height: 45,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: kategoriList.length,
              itemBuilder: (context, i) {
                final kat = kategoriList[i];
                final aktif = kat == kategoriTerpilih;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(kat),
                    selected: aktif,
                    selectedColor: Colors.red[300],
                    labelStyle: TextStyle(
                      color: aktif ? Colors.white : Colors.black87,
                      fontWeight: aktif ? FontWeight.bold : FontWeight.normal,
                    ),
                    onSelected: (_) {
                      setState(() {
                        kategoriTerpilih = kat;
                        cari(_searchController.text);
                      });
                    },
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Text(
                  '${hasil.length} kosakata ditemukan',
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 13,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: hasil.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.search_off, size: 80, color: Colors.grey),
                        SizedBox(height: 10),
                        Text('Tidak ditemukan 😢',
                            style: TextStyle(fontSize: 16)),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: hasil.length,
                    padding: const EdgeInsets.only(bottom: 12),
                    itemBuilder: (context, i) {
                      final k = hasil[i];
                      final isFav = favorit.contains(k);
                      return Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          onTap: () => _showDetail(context, k),
                          leading: CircleAvatar(
                            backgroundColor: Colors.red[100],
                            child: Text(
                              k.kanji.isNotEmpty ? k.kanji[0] : '?',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                                color: Color(0xFFC62828),
                              ),
                            ),
                          ),
                          title: Text(
                            '${k.kanji}  •  ${k.hiragana}',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 2),
                              Text('${k.romaji}  |  ${k.katakana}',
                                  style: const TextStyle(fontSize: 13)),
                              const SizedBox(height: 2),
                              Text(
                                k.arti,
                                style: const TextStyle(
                                  color: Color(0xFFC62828),
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                icon: Icon(
                                  isFav
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  color: Colors.red,
                                  size: 20,
                                ),
                                onPressed: () => toggleFavorit(k),
                              ),
                              Text(
                                k.kategori,
                                style: TextStyle(
                                    fontSize: 10, color: Colors.grey[600]),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _showDetail(BuildContext context, Kosakata k) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: Text(
                  k.kanji,
                  style: const TextStyle(
                      fontSize: 56,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFC62828)),
                ),
              ),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  k.hiragana,
                  style: const TextStyle(fontSize: 22, color: Colors.black87),
                ),
              ),
              const SizedBox(height: 20),
              const Divider(),
              const SizedBox(height: 10),
              _rowDetail('Romaji', k.romaji),
              _rowDetail('Hiragana', k.hiragana),
              _rowDetail('Katakana', k.katakana),
              _rowDetail('Kanji', k.kanji),
              _rowDetail('Arti', k.arti),
              _rowDetail('Kategori', k.kategori),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.copy),
                  label: const Text('Copy ke Clipboard'),
                  onPressed: () {
                    Clipboard.setData(ClipboardData(
                      text:
                          '${k.kanji} (${k.hiragana}) - ${k.romaji} = ${k.arti}',
                    ));
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Tersalin ke clipboard')),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _rowDetail(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: const TextStyle(
                  fontWeight: FontWeight.bold, color: Colors.grey),
            ),
          ),
          const Text(': '),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// 4. HALAMAN FAVORIT
// ============================================================
class FavoritPage extends StatefulWidget {
  final List<Kosakata> favorit;
  final Function(Kosakata) onToggle;

  const FavoritPage({
    super.key,
    required this.favorit,
    required this.onToggle,
  });

  @override
  State<FavoritPage> createState() => _FavoritPageState();
}

class _FavoritPageState extends State<FavoritPage> {
  late List<Kosakata> items;

  @override
  void initState() {
    super.initState();
    items = List.from(widget.favorit);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('❤️ Kosakata Favorit'),
        backgroundColor: const Color(0xFFC62828),
        foregroundColor: Colors.white,
      ),
      body: items.isEmpty
          ? const Center(child: Text('Belum ada favorit'))
          : ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, i) {
                final k = items[i];
                return ListTile(
                  title: Text('${k.kanji} (${k.hiragana})'),
                  subtitle: Text('${k.romaji} - ${k.arti}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      setState(() {
                        widget.onToggle(k);
                        items.removeAt(i);
                      });
                    },
                  ),
                );
              },
            ),
    );
  }
}